// سرویس‌ورکر «حساب HD»: همه‌ی فایل‌های برنامه را کش می‌کند تا بدون اینترنت کامل کار کند.
// نسخه و فهرست فایل‌ها هنگام build جایگزین می‌شوند.
const VERSION = '__VERSION__';
const CACHE = `hesab-hd-${VERSION}`;
const ASSETS = __ASSETS__;

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(ASSETS)));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => k.startsWith('hesab-hd-') && k !== CACHE).map((k) => caches.delete(k)));
      await self.clients.claim();
    })(),
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // درخواست نرخ دلار و… همیشه مستقیم به شبکه می‌رود
  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE);
      const hit = await cache.match(req, { ignoreSearch: true });
      if (hit) return hit;
      if (req.mode === 'navigate') {
        const shell = await cache.match('./index.html');
        if (shell) return shell;
      }
      try {
        return await fetch(req);
      } catch {
        return new Response('آفلاین', { status: 503, headers: { 'content-type': 'text/plain; charset=utf-8' } });
      }
    })(),
  );
});
