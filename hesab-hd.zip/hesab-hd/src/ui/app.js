// کنترل‌کننده‌ی برنامه: مسیریابی، رندر، رویدادها، همگام‌سازی نرخ و قفل.
// همه‌ی وابستگی‌های محیطی تزریق می‌شوند تا در مرورگر واقعی و در تست‌ها یکسان کار کند.
import { h, esc } from './dom.js';
import { header, bottomNav, notice } from './components.js';
import { openStore, StorageError, requestPersistence, storageEstimate } from '../core/storage.js';
import { ValidationError } from '../core/ledger.js';
import { fetchLiveRate, isFresh, processPending, pendingTransactions } from '../core/fx.js';
import { iranMarketAdapter } from '../core/rate-source.js';
import { todayJalali } from '../core/jalali.js';
import * as J from '../core/jalali.js';
import * as M from '../core/money.js';
import { createPrefs } from './prefs.js';
import { verifyPin, lockoutMs } from './lock.js';
import { resolveRoute } from './routes.js';
import { coreActions } from './actions-core.js';
import { moreActions } from './actions-more.js';
import { backupActions } from './actions-backup.js';

const AUTO_SYNC_MIN_GAP_MS = 2 * 60 * 1000;

export async function startApp({ root, overlay, adapter, fetchFn = globalThis.fetch?.bind(globalThis), rateAdapter = iranMarketAdapter, win = window, doc = document, now = () => new Date(), prefs = createPrefs() }) {
  const store = await openStore({ adapter, validateOnCommit: true, now: () => now().toISOString() });
  const ui = { recoveredNote: null, form: null, toast: null, reconcile: null, lastSyncAt: 0, syncing: false, locked: false, hiddenAt: 0, storageInfo: null, persisted: null, sheet: null, route: '' };
  let online = win.navigator?.onLine !== false;
  let toastTimer = null;

  const c = {
    store,
    ui,
    prefs,
    doc,
    win,
    get state() {
      return store.state;
    },
    get online() {
      return online;
    },
    now,
    nowIso: () => now().toISOString(),
    today: () => todayJalali(now(), 'Asia/Tehran'),
    adapter,
    rateAdapter,
  };

  // ---------- رندر ----------
  function viewContext() {
    const state = store.state;
    const q = parseRoute(win.location.hash).query;
    return {
      state,
      today: c.today(),
      nowMs: now().getTime(),
      online,
      query: q,
      ui,
      prefs: prefs.get(),
      pendingCount: pendingTransactions(state).length,
      storageInfo: ui.storageInfo,
      persisted: ui.persisted,
      form: ui.form,
      corrupt: store.status === 'corrupt',
      formErrors: ui.form?.errors ?? [],
      values: ui.form?.values ?? null,
    };
  }

  function render({ keepScroll = false, focus = true } = {}) {
    if (ui.locked) return;
    const hash = win.location.hash;
    const ctx = viewContext();
    let view;
    try {
      view = resolveRoute(parseRoute(hash), ctx);
    } catch (e) {
      view = { tab: 'home', title: 'خطا', html: notice(`نمایش این صفحه با خطا روبه‌رو شد: ${e.message}`, 'error') };
      console.error(e);
    }
    const active = doc.activeElement;
    const activeId = active?.id || active?.getAttribute?.('name') || null;
    const scrollY = win.scrollY;
    const sel = active && typeof active.selectionStart === 'number' ? [active.selectionStart, active.selectionEnd] : null;
    const showTabs = view.tabs !== false;
    const banner = !online ? h`<div class="net" role="status">آفلاین هستید؛ همه‌چیز کار می‌کند. نرخ دلار بعد از اتصال خودکار محاسبه می‌شود.</div>` : '';
    const recovered = ui.recoveredNote ? h`<div class="notice warn" role="alert"><div>${ui.recoveredNote}<div class="actions two" style="margin-top:8px"><a class="btn" href="#/backup">گرفتن پشتیبان</a><button class="btn" data-action="dismiss-recovered">متوجه شدم</button></div></div></div>` : '';
    root.className = showTabs ? '' : 'no-tabs';
    root.innerHTML = String(h`${banner}${view.hideHeader ? '' : header(view.title, { back: view.back ?? null, actions: view.actions ?? [] })}<main id="main" tabindex="-1">${recovered}${view.html}</main>${showTabs ? bottomNav(view.tab) : ''}`);
    doc.title = `${view.title} · حساب HD`;
    initWidgets(root);
    if (keepScroll) {
      win.scrollTo(0, scrollY);
      const el = activeId ? root.querySelector(`#${CSS.escape(activeId)}, [name="${CSS.escape(activeId)}"]`) : null;
      if (el && focus) {
        el.focus({ preventScroll: true });
        if (sel && typeof el.setSelectionRange === 'function') {
          try {
            el.setSelectionRange(sel[0], sel[1]);
          } catch {
            /* نوع ورودی انتخاب متن ندارد */
          }
        }
      }
    } else {
      win.scrollTo(0, 0);
      if (focus) root.querySelector('#main')?.focus({ preventScroll: true });
    }
  }
  c.render = render;
  // رندر دوباره‌ی «پس‌زمینه‌ای» (پایان همگام‌سازی، تغییر وضعیت اینترنت، تغییر state):
  // مقدارهای نیمه‌واردشده‌ی فرم باز حفظ می‌شود تا هنگام تایپ، چیزی پاک نشود.
  function softRender() {
    if (ui.locked) return;
    const form = root.querySelector('main form[data-action]:not([data-autosubmit])');
    if (form) ui.form = { ...(ui.form ?? {}), values: formValues(form), route: ui.route };
    render({ keepScroll: true, focus: true });
  }
  c.softRender = softRender;

  function initWidgets(scope) {
    scope.querySelectorAll('[data-amount]').forEach((i) => updatePreview(i));
  }

  function updatePreview(input) {
    const prev = input.closest('.field')?.querySelector('[data-preview]');
    if (!prev) return;
    const text = input.value.trim();
    if (!text) {
      prev.textContent = '';
      prev.classList.remove('bad');
      return;
    }
    const r = M.parseAmount(input.dataset.currency || 'IRT', text, { allowZero: true, allowNegative: true });
    prev.classList.toggle('bad', !r.ok);
    prev.textContent = r.ok ? M.formatAmount(input.dataset.currency || 'IRT', r.value) : r.error;
  }

  // ---------- ابزارهای کنترل‌کننده ----------
  c.go = (hash) => {
    if (win.location.hash === hash) render();
    else win.location.hash = hash;
  };
  c.setForm = (form, opts) => {
    ui.form = form;
    render({ keepScroll: true, ...opts });
  };
  c.toast = (msg, ms = 3200) => {
    ui.toast = msg;
    let el = doc.getElementById('toast');
    if (!el) {
      el = doc.createElement('div');
      el.id = 'toast';
      el.className = 'toast';
      el.setAttribute('role', 'status');
      doc.body.appendChild(el);
    }
    el.textContent = msg;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.remove(), ms);
  };
  c.commit = async (updater) => {
    const out = await store.commit(updater);
    return out;
  };
  // اجرای عملیات و تبدیل خطاها به پیام قابل‌فهم
  c.errorsFrom = (e) => {
    if (e instanceof ValidationError) return e.errors;
    if (e instanceof StorageError) return [{ field: '_', message: e.message }];
    if (e instanceof M.MoneyError) return [{ field: '_', message: e.message }];
    console.error(e);
    return [{ field: '_', message: 'خطای پیش‌بینی‌نشده رخ داد؛ تغییری ذخیره نشد.' }];
  };
  c.fail = (e) => {
    const errs = c.errorsFrom(e);
    c.toast(errs[0]?.message ?? 'انجام نشد.', 5000);
  };

  // پنجره‌ی پایینی
  function closeSheet(result) {
    const s = ui.sheet;
    if (!s) return;
    ui.sheet = null;
    overlay.innerHTML = '';
    s.opener?.focus?.();
    s.resolve(result);
  }
  c.sheet = (html, { onMount } = {}) =>
    new Promise((resolve) => {
      ui.sheet = { resolve, opener: doc.activeElement };
      overlay.innerHTML = String(h`<div class="sheet-back" data-action="sheet-backdrop"><div class="sheet" role="dialog" aria-modal="true">${html}</div></div>`);
      const first = overlay.querySelector('input:not([type=hidden]), select, textarea, button');
      first?.focus();
      onMount?.(overlay);
      initWidgets(overlay);
    });
  c.closeSheet = closeSheet;
  c.confirm = ({ title, text = '', confirmLabel = 'تأیید', danger = false }) =>
    c.sheet(h`<h2>${title}</h2>${text ? h`<p class="muted">${text}</p>` : ''}<div class="actions two"><button class="btn ${danger ? 'danger' : 'primary'}" data-action="sheet-yes">${confirmLabel}</button><button class="btn" data-action="sheet-no">انصراف</button></div>`);

  // ---------- همگام‌سازی نرخ دلار ----------
  c.syncRate = async ({ force = false, silent = false } = {}) => {
    if (ui.syncing) return { status: 'busy' };
    if (!online) {
      if (!silent) c.toast('اینترنت وصل نیست؛ بعد از اتصال خودکار انجام می‌شود.');
      return { status: 'offline' };
    }
    const pending = pendingTransactions(store.state).length;
    if (!pending && !force) return { status: 'nothing_pending' };
    ui.syncing = true;
    ui.lastSyncAt = now().getTime();
    try {
      const maxAgeMs = (store.state.fx.maxAgeMinutes ?? 30) * 60000;
      const nowIso = c.nowIso();
      const lastRate = store.state.fx.lastRate;
      let rate = null;
      let error = null;
      if (!force && lastRate && isFresh(lastRate, now().getTime(), maxAgeMs)) rate = lastRate;
      else {
        const res = await fetchLiveRate(rateAdapter, { fetchFn, nowIso: c.nowIso(), timeoutMs: 8000 });
        if (res.ok) rate = res.rate;
        else error = res.error;
      }
      const result = await store.commit((s) => {
        const fx = s.fx;
        if (!rate) return { state: { ...s, fx: { ...fx, lastError: { at: nowIso, message: error } } }, status: 'fetch_failed', updated: 0, message: error };
        const p = processPending({ ...s, fx: { ...fx, lastRate: rate, lastError: null } }, rate, nowIso, { maxAgeMs });
        return { state: p.state, status: p.reason, updated: p.updated, rate };
      });
      if (!silent || result.updated > 0 || result.status === 'fetch_failed') {
        if (result.status === 'fetch_failed') {
          if (!silent) c.toast(`نرخ دریافت نشد: ${result.message}`, 5000);
        } else if (result.updated > 0) c.toast(`معادل دلاری ${M.toPersianDigits(String(result.updated))} تراکنش محاسبه شد.`);
        else if (force) c.toast('نرخ به‌روز شد.');
      }
      return result;
    } catch (e) {
      if (!silent) c.fail(e);
      return { status: 'error' };
    } finally {
      ui.syncing = false;
      softRender();
    }
  };
  c.maybeAutoSync = () => {
    if (!online || ui.locked) return;
    if (pendingTransactions(store.state).length === 0) return;
    if (now().getTime() - ui.lastSyncAt < AUTO_SYNC_MIN_GAP_MS) return;
    c.syncRate({ silent: true });
  };

  // ---------- قفل ----------
  function showLock(message = '') {
    ui.locked = true;
    root.innerHTML = '';
    const p = prefs.get();
    const wait = Math.max(0, p.lockedUntil - now().getTime());
    overlay.innerHTML = String(h`<div class="lock" role="dialog" aria-modal="true" aria-label="قفل برنامه"><form class="lock-box" data-action="unlock" novalidate><div style="font-size:3rem" aria-hidden="true">🔒</div><h1>حساب HD</h1><p class="muted">برای ورود، PIN را وارد کنید.</p><label class="sr" for="pin">PIN</label><input type="password" id="pin" name="pin" inputmode="numeric" autocomplete="off" maxlength="8" dir="ltr" ${wait > 0 ? 'disabled' : ''}><div class="err" id="lockmsg" role="alert">${wait > 0 ? `تلاش‌های ناموفق زیاد بود؛ ${M.toPersianDigits(String(Math.ceil(wait / 1000)))} ثانیه صبر کنید.` : message}</div><button class="btn primary block" type="submit" ${wait > 0 ? 'disabled' : ''}>ورود</button></form></div>`);
    overlay.querySelector('#pin')?.focus();
    if (wait > 0) setTimeout(() => ui.locked && showLock(), Math.min(wait, 1000));
  }
  c.lockNow = () => {
    if (prefs.get().pin) showLock();
  };
  c.unlock = async (pin) => {
    const p = prefs.get();
    if (p.lockedUntil > now().getTime()) return showLock();
    if (await verifyPin(pin, p.pin)) {
      prefs.set({ failCount: 0, lockedUntil: 0 });
      ui.locked = false;
      overlay.innerHTML = '';
      render();
      c.maybeAutoSync();
    } else {
      const failCount = p.failCount + 1;
      const wait = lockoutMs(failCount);
      prefs.set({ failCount, lockedUntil: wait ? now().getTime() + wait : 0 });
      showLock('PIN نادرست است.');
    }
  };

  // ---------- رویدادها ----------
  const actions = { ...coreActions, ...moreActions, ...backupActions, 'dismiss-recovered': () => { ui.recoveredNote = null; render({ keepScroll: true, focus: false }); } };

  const formValues = (form) => {
    const fd = new FormData(form);
    const v = {};
    for (const [k, val] of fd.entries()) if (typeof val === 'string') v[k] = val;
    form.querySelectorAll('.date3[data-date]').forEach((d) => {
      const name = d.dataset.date;
      const y = fd.get(`${name}_y`);
      const m = fd.get(`${name}_m`);
      const dd = fd.get(`${name}_d`);
      v[name] = y && m && dd ? J.formatDate({ jy: Number(y), jm: Number(m), jd: Number(dd) }) : !y && !m && !dd ? '' : 'ناقص';
    });
    return v;
  };
  c.formValues = formValues;

  doc.addEventListener('click', async (ev) => {
    const el = ev.target.closest?.('[data-action]');
    if (!el || el.tagName === 'FORM') return;
    const name = el.dataset.action;
    if (name === 'sheet-yes') {
      const vals = {};
      overlay.querySelectorAll('select[name], input[name]').forEach((i) => {
        vals[i.name] = i.value;
      });
      ui.sheetValues = vals;
      ui.sheetChoice = el.dataset.choice ?? null;
      return closeSheet(true);
    }
    if (name === 'sheet-no') return closeSheet(false);
    if (name === 'sheet-backdrop') {
      if (ev.target === el) closeSheet(false);
      return;
    }
    const fn = actions[name];
    if (!fn) return;
    ev.preventDefault();
    try {
      await fn(c, el, ev);
    } catch (e) {
      c.fail(e);
    }
  });

  doc.addEventListener('submit', async (ev) => {
    const form = ev.target;
    const name = form.dataset?.action;
    if (!name) return;
    ev.preventDefault();
    if (name === 'unlock') return c.unlock(new FormData(form).get('pin'));
    const fn = actions[name];
    if (!fn) return;
    try {
      await fn(c, form, ev, formValues(form), ev.submitter);
    } catch (e) {
      c.fail(e);
    }
  });

  doc.addEventListener('change', (ev) => {
    const t = ev.target;
    const form = t.closest?.('form');
    if (t.matches?.('input[type=file][data-file-action]')) {
      const fn = actions[t.dataset.fileAction];
      const file = t.files?.[0];
      if (fn && file) fn(c, t, null, file).catch((e) => c.fail(e));
      return;
    }
    if (t.closest?.('.date3')) syncDays(t.closest('.date3'));
    const rr = t.closest?.('[data-rerender]');
    if (rr && form) {
      ui.form = { ...(ui.form ?? {}), values: formValues(form), errors: [], dup: null, route: ui.route };
      render({ keepScroll: true });
      return;
    }
    if (form?.hasAttribute('data-autosubmit')) form.requestSubmit();
  });

  let searchTimer = null;
  doc.addEventListener('input', (ev) => {
    const t = ev.target;
    if (t.matches?.('[data-amount]')) updatePreview(t);
    const form = t.closest?.('form[data-autosubmit]');
    if (form && t.type === 'search') {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => form.requestSubmit(), 350);
    }
  });

  doc.addEventListener('keydown', (ev) => {
    if (ev.key === 'Escape' && ui.sheet) closeSheet(false);
  });

  function syncDays(group) {
    const y = group.querySelector('[name$="_y"]');
    const m = group.querySelector('[name$="_m"]');
    const d = group.querySelector('[name$="_d"]');
    if (!y || !m || !d || !y.value || !m.value) return;
    const len = J.monthLength(Number(y.value), Number(m.value));
    const cur = d.value;
    const optional = group.dataset.optional === '1';
    d.innerHTML = (optional ? '<option value="">—</option>' : '') + Array.from({ length: len }, (_, i) => `<option value="${i + 1}">${M.toPersianDigits(String(i + 1))}</option>`).join('');
    d.value = cur && Number(cur) <= len ? cur : String(len);
  }

  win.addEventListener('hashchange', () => {
    const route = win.location.hash;
    if (route !== ui.route) ui.form = null;
    ui.route = route;
    render();
  });
  win.addEventListener('online', () => {
    online = true;
    softRender();
    c.syncRate({ silent: true });
  });
  win.addEventListener('offline', () => {
    online = false;
    softRender();
  });
  doc.addEventListener('visibilitychange', () => {
    if (doc.visibilityState === 'hidden') ui.hiddenAt = now().getTime();
    else {
      const p = prefs.get();
      if (p.pin && !ui.locked && ui.hiddenAt && now().getTime() - ui.hiddenAt > p.lockAfterSec * 1000) showLock();
      else c.maybeAutoSync();
    }
  });
  const timer = win.setInterval?.(() => c.maybeAutoSync(), 5 * 60 * 1000);

  c.applyTheme = () => {
    const t = prefs.get().theme;
    if (t === 'light' || t === 'dark') doc.documentElement.setAttribute('data-theme', t);
    else doc.documentElement.removeAttribute('data-theme');
  };
  c.refreshStorageInfo = async () => {
    const [est, per] = await Promise.all([storageEstimate(win.navigator), requestPersistence(win.navigator)]);
    ui.persisted = per;
    ui.storageInfo = est?.usage != null ? `${M.toPersianDigits(String(Math.max(1, Math.round(est.usage / 1024))))} کیلوبایت` : null;
  };

  // هر تغییر ذخیره‌شده‌ی state (از هر مسیری) صفحه را تازه می‌کند
  store.subscribe(() => queueMicrotask(softRender));

  // ---------- شروع ----------
  c.applyTheme();
  ui.route = win.location.hash;
  ui.recoveredNote = store.status === 'recovered' ? store.recoveredNote : null;
  if (prefs.get().pin) showLock();
  else {
    if (!win.location.hash) win.location.hash = '#/home';
    render();
  }
  c.refreshStorageInfo().then(() => {
    if (win.location.hash.startsWith('#/settings')) render({ keepScroll: true, focus: false });
  });
  c.maybeAutoSync();
  return { ...c, stop: () => win.clearInterval?.(timer) };
}

export function parseRoute(hash) {
  const raw = String(hash ?? '').replace(/^#\/?/, '');
  const [path, qs = ''] = raw.split('?');
  const query = {};
  for (const part of qs.split('&')) {
    if (!part) continue;
    const [k, v = ''] = part.split('=');
    try {
      query[decodeURIComponent(k)] = decodeURIComponent(v.replace(/\+/g, ' '));
    } catch {
      /* پارامتر خراب نادیده گرفته می‌شود */
    }
  }
  return { parts: path.split('/').filter(Boolean), query, path };
}
