// عملیات اصلی: تراکنش، حساب، نرخ، تنظیمات
import * as L from '../core/ledger.js';
import * as M from '../core/money.js';
import { applyManualRate } from '../core/fx.js';
import { createPinRecord, validatePinFormat, verifyPin } from './lock.js';
import { h } from './dom.js';
import { formErrors } from './components.js';

const blank = (s) => s === undefined || s === null || String(s).trim() === '';
const err = (field, message) => ({ field, message });

function parseMoney(currency, text, field, errors, opts) {
  const r = M.parseAmount(currency, text, opts);
  if (!r.ok) {
    errors.push(err(field, r.error));
    return null;
  }
  return r.value;
}

// ورودی خام فرم تراکنش → ورودی ledger (یا خطاهای فرم)
export function buildTxInput(state, v) {
  const errors = [];
  const type = v.type;
  const input = { type, date: v.date === 'ناقص' ? null : v.date, note: v.note ?? '' };
  if (v.date === 'ناقص' || !v.date) errors.push(err('date', 'تاریخ را کامل انتخاب کنید.'));
  if (v.requestId) input.requestId = v.requestId;
  const acc = (id) => state.accounts.find((a) => a.id === id);
  if (type === 'transfer') {
    input.fromAccountId = v.fromAccountId;
    input.toAccountId = v.toAccountId || null;
    const from = acc(v.fromAccountId);
    const to = acc(v.toAccountId);
    if (!to) errors.push(err('toAccountId', 'حساب مقصد را انتخاب کنید.'));
    if (from) input.amount = parseMoney(from.currency, v.amount, 'amount', errors);
    if (from && to && from.currency !== to.currency) {
      if (blank(v.toAmount)) errors.push(err('toAmount', 'مبلغ دریافتی در حساب مقصد را وارد کنید.'));
      else input.toAmount = parseMoney(to.currency, v.toAmount, 'toAmount', errors);
    }
  } else {
    input.accountId = v.accountId;
    const a = acc(v.accountId);
    if (a) input.amount = parseMoney(a.currency, v.amount, 'amount', errors);
    if (type === 'debt_payment') input.debtId = v.debtId;
    else {
      input.categoryId = v.categoryId || null;
      if (!v.categoryId) errors.push(err('categoryId', 'یک دسته‌بندی انتخاب کنید.'));
    }
  }
  return { input, errors };
}

async function saveTx(c, form, ev, v, submitter) {
  const edit = form.dataset.action === 'save-tx-edit';
  const id = form.dataset.id;
  const { input, errors } = buildTxInput(c.state, v);
  if (errors.length) return c.setForm({ values: v, errors });
  const allowDuplicate = submitter?.name === 'allowDuplicate';
  try {
    const ctx = { now: c.nowIso, id: () => globalThis.crypto.randomUUID() };
    const out = await c.commit((s) => (edit ? L.updateTransaction(s, id, input, ctx, { allowDuplicate }) : L.addTransaction(s, input, ctx, { allowDuplicate })));
    if (edit) {
      c.toast('تغییرات ذخیره شد.');
      c.ui.form = null;
      c.go(`#/tx/${id}`);
    } else {
      c.toast(out.repeated ? 'این تراکنش قبلاً ثبت شده بود.' : 'تراکنش ثبت شد.');
      // آماده‌ی ثبت بعدی: نوع، حساب و تاریخ می‌ماند
      c.setForm({ values: { ...v, amount: '', toAmount: '', note: '', requestId: globalThis.crypto.randomUUID() }, errors: [], dup: null }, { focus: true });
      globalThis.setTimeout?.(() => c.maybeAutoSync(), 0);
    }
  } catch (e) {
    if (e instanceof L.ValidationError && e.code === 'DUPLICATE') return c.setForm({ values: v, errors: [], dup: { existingId: e.existingId } });
    c.setForm({ values: v, errors: c.errorsFrom(e) });
  }
}

async function saveAccount(c, form, ev, v) {
  const edit = form.dataset.action === 'save-account-edit';
  const errors = [];
  const cur = v.currency || 'IRT';
  const ob = blank(v.openingBalance) ? 0 : parseMoney(cur, v.openingBalance, 'openingBalance', errors, { allowZero: true, allowNegative: true });
  if (errors.length) return c.setForm({ values: v, errors });
  try {
    const ctx = { now: c.nowIso, id: () => globalThis.crypto.randomUUID() };
    const patch = { name: v.name, type: v.type, currency: cur, openingBalance: ob };
    const out = await c.commit((s) => (edit ? L.updateAccount(s, form.dataset.id, patch, ctx) : L.addAccount(s, patch, ctx)));
    c.toast(edit ? 'حساب ذخیره شد.' : 'حساب ساخته شد.');
    c.ui.form = null;
    c.go(edit ? `#/accounts/${form.dataset.id}` : '#/home');
  } catch (e) {
    c.setForm({ values: v, errors: c.errorsFrom(e) });
  }
}

export const coreActions = {
  'save-tx': saveTx,
  'save-tx-edit': saveTx,
  'save-account': saveAccount,
  'save-account-edit': saveAccount,

  'sync-rate': (c) => c.syncRate({ force: true }),

  async 'ask-delete-tx'(c, el) {
    const ok = await c.confirm({ title: 'حذف این تراکنش؟', text: 'این کار قابل بازگشت نیست. موجودی حساب دوباره محاسبه می‌شود.', confirmLabel: 'حذف', danger: true });
    if (!ok) return;
    await c.commit((s) => L.deleteTransaction(s, el.dataset.id));
    c.toast('تراکنش حذف شد.');
    c.go('#/transactions');
  },

  async 'archive-account'(c, el) {
    const ok = await c.confirm({ title: 'بایگانی حساب؟', text: 'حساب بایگانی‌شده در ثبت تراکنش جدید دیده نمی‌شود، ولی تاریخچه‌اش می‌ماند و هر زمان برمی‌گردد.', confirmLabel: 'بایگانی' });
    if (!ok) return;
    await c.commit((s) => L.setAccountArchived(s, el.dataset.id, true, { now: c.nowIso, id: () => globalThis.crypto.randomUUID() }));
    c.toast('حساب بایگانی شد.');
    c.go('#/accounts');
  },
  async 'unarchive-account'(c, el) {
    await c.commit((s) => L.setAccountArchived(s, el.dataset.id, false, { now: c.nowIso, id: () => globalThis.crypto.randomUUID() }));
    c.toast('حساب برگشت.');
    c.render({ keepScroll: true });
  },
  async 'ask-delete-account'(c, el) {
    const ok = await c.confirm({ title: 'حذف حساب؟', text: 'این حساب تراکنشی ندارد و برای همیشه حذف می‌شود.', confirmLabel: 'حذف', danger: true });
    if (!ok) return;
    await c.commit((s) => L.deleteAccount(s, el.dataset.id));
    c.toast('حساب حذف شد.');
    c.go('#/accounts');
  },

  async reconcile(c, form, ev, v) {
    const acc = c.state.accounts.find((a) => a.id === form.dataset.id);
    const errors = [];
    const actual = parseMoney(acc.currency, v.actual, 'actual', errors, { allowZero: true, allowNegative: true });
    if (errors.length) return c.toast(errors[0].message);
    c.ui.reconcile = { id: acc.id, result: L.reconcile(c.state, acc.id, actual) };
    c.render({ keepScroll: true, focus: false });
  },

  async 'manual-rate'(c, form, ev, v) {
    const errors = [];
    const r = M.parseRate(v.rate);
    if (!r.ok) errors.push(err('rate', r.error));
    if (errors.length) return c.setForm({ values: v, errors });
    const nowIso = c.nowIso();
    const opts = v.scope === 'one' ? { txIds: [v.txId], includeDone: true } : v.scope === 'all' ? { includeDone: true } : {};
    const out = await c.commit((s) => {
      const res = applyManualRate(s, r.value, nowIso, opts);
      return { state: { ...res.state, fx: { ...s.fx, lastRate: res.rate, lastError: null } }, updated: res.updated };
    });
    c.ui.form = null;
    c.toast(out.updated ? `نرخ دستی روی ${M.toPersianDigits(String(out.updated))} تراکنش اعمال شد.` : 'نرخ ذخیره شد؛ تراکنشی برای محاسبه نبود.');
    c.go(v.txId ? `#/tx/${v.txId}` : '#/rate');
  },

  filter(c, form) {
    const v = c.formValues(form);
    const p = [];
    for (const k of ['q', 'range', 'type', 'acc', 'cat']) if (v[k]) p.push(`${k}=${encodeURIComponent(v[k])}`);
    c.win.location.hash = `#/transactions${p.length ? `?${p.join('&')}` : ''}`;
  },

  'save-theme'(c, form, ev, v) {
    c.prefs.set({ theme: ['light', 'dark'].includes(v.theme) ? v.theme : 'auto' });
    c.applyTheme();
  },

  async 'request-persist'(c) {
    await c.refreshStorageInfo();
    c.toast(c.ui.persisted ? 'ماندگاری فعال شد.' : 'مرورگر ماندگاری را نپذیرفت؛ پشتیبان‌گیری فراموش نشود.');
    c.render({ keepScroll: true, focus: false });
  },

  // ----- قفل PIN -----
  async 'open-pin-form'(c, el) {
    const mode = el.dataset.mode;
    const title = { set: 'فعال‌سازی قفل PIN', change: 'تغییر PIN', remove: 'برداشتن قفل' }[mode];
    const needOld = mode !== 'set';
    const needNew = mode !== 'remove';
    const ok = await c.sheet(
      h`<h2>${title}</h2><form data-action="pin-form" data-mode="${mode}" novalidate>${needOld ? h`<div class="field"><label for="oldpin">PIN فعلی</label><input type="password" id="oldpin" name="oldpin" inputmode="numeric" maxlength="8" dir="ltr" autocomplete="off"></div>` : ''}${needNew ? h`<div class="field"><label for="newpin">PIN جدید (۴ تا ۸ رقم)</label><input type="password" id="newpin" name="newpin" inputmode="numeric" maxlength="8" dir="ltr" autocomplete="off"></div><div class="field"><label for="newpin2">تکرار PIN</label><input type="password" id="newpin2" name="newpin2" inputmode="numeric" maxlength="8" dir="ltr" autocomplete="off"></div>` : ''}<div class="err" id="pinerr" role="alert"></div><div class="actions two"><button class="btn primary" type="submit">تأیید</button><button class="btn" type="button" data-action="sheet-no">انصراف</button></div></form>`,
    );
    return ok;
  },
  async 'pin-form'(c, form, ev, v) {
    const mode = form.dataset.mode;
    const say = (m) => {
      const e = c.doc.getElementById('pinerr');
      if (e) e.textContent = m;
    };
    const p = c.prefs.get();
    if (mode !== 'set' && !(await verifyPin(v.oldpin, p.pin))) return say('PIN فعلی درست نیست.');
    if (mode === 'remove') {
      c.prefs.set({ pin: null, failCount: 0, lockedUntil: 0 });
      c.closeSheet(true);
      c.toast('قفل برداشته شد.');
      return c.render({ keepScroll: true, focus: false });
    }
    const fmt = validatePinFormat(v.newpin);
    if (!fmt.ok) return say(fmt.error);
    if (fmt.pin !== String(v.newpin2 ?? '').replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0)).trim()) return say('تکرار PIN با PIN جدید یکی نیست.');
    c.prefs.set({ pin: await createPinRecord(fmt.pin), failCount: 0, lockedUntil: 0 });
    c.closeSheet(true);
    c.toast(mode === 'set' ? 'قفل PIN فعال شد.' : 'PIN تغییر کرد.');
    c.render({ keepScroll: true, focus: false });
  },
};
