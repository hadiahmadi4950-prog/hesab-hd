// تولید HTML امن: هر مقدارِ درج‌شده به‌طور پیش‌فرض escape می‌شود (جلوگیری از XSS از یادداشت‌ها و نام‌ها).
// فقط خروجی خود h`` و raw() بدون escape درج می‌شود.

class Safe {
  constructor(s) {
    this.s = s;
  }
  toString() {
    return this.s;
  }
}

export const isSafe = (v) => v instanceof Safe;
export const raw = (s) => new Safe(String(s));

export function esc(v) {
  return String(v)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/`/g, '&#96;');
}

function part(v) {
  if (v === null || v === undefined || v === false || v === true) return '';
  if (v instanceof Safe) return v.s;
  if (Array.isArray(v)) return v.map(part).join('');
  return esc(v);
}

export function h(strings, ...values) {
  let out = strings[0];
  for (let i = 0; i < values.length; i += 1) out += part(values[i]) + strings[i + 1];
  return new Safe(out);
}

export const join = (list, sep = '') => new Safe(list.map(part).join(sep));
