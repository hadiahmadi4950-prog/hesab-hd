import { startApp } from './app.js';
import { createIndexedDBAdapter, createMemoryAdapter } from '../core/storage.js';

const root = document.getElementById('app');
const overlay = document.getElementById('overlay');

function fatal(msg) {
  root.innerHTML = `<main style="padding:24px"><section class="card"><h2>مشکل در راه‌اندازی</h2><p>${msg}</p></section></main>`;
}

async function boot() {
  let adapter;
  try {
    adapter = createIndexedDBAdapter();
  } catch {
    adapter = null;
  }
  if (!adapter) {
    // ذخیره‌سازی دائمی در دسترس نیست (مثلاً حالت خصوصی): فقط تا بستن صفحه
    adapter = createMemoryAdapter();
    window.__hesabVolatile = true;
  }
  try {
    const app = await startApp({ root, overlay, adapter });
    window.__hesab = app; // برای آزمایش خودکار
    if (window.__hesabVolatile) app.toast('ذخیره‌سازی دائمی در دسترس نیست؛ اطلاعات با بستن صفحه از بین می‌رود. پشتیبان بگیرید.', 9000);
  } catch (e) {
    console.error(e);
    fatal(`${e.message ?? e} — اگر در حالت خصوصی مرورگر هستید، از حالت عادی استفاده کنید.`);
  }
}

boot();

if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  window.addEventListener('load', async () => {
    try {
      const reg = await navigator.serviceWorker.register('./sw.js');
      reg.addEventListener('updatefound', () => {
        const w = reg.installing;
        w?.addEventListener('statechange', () => {
          if (w.state === 'installed' && navigator.serviceWorker.controller) {
            window.__hesab?.toast('نسخه‌ی جدید آماده است؛ برنامه را کامل ببندید و دوباره باز کنید.', 8000);
          }
        });
      });
    } catch (e) {
      console.warn('سرویس‌ورکر ثبت نشد؛ حالت آفلاین در این مرورگر کار نمی‌کند.', e);
    }
  });
}
