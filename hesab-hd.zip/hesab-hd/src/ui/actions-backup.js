// پشتیبان‌گیری، بازیابی، پاک‌کردن اطلاعات و رفع خرابی داده
import { exportJSON, exportCSV, parseBackup, previewRestore, mergeStates, restoreReplace, backupFileName, BackupError, MAX_BACKUP_BYTES } from '../core/backup.js';
import { createEmptyState } from '../core/ledger.js';
import { h } from './dom.js';
import { importPreviewHtml } from './views/backup.js';
import { APP_VERSION } from './views/more.js';
import { toPersianDigits } from '../core/money.js';

export function download(c, filename, text, mime) {
  const blob = new Blob([text], { type: mime });
  const url = c.win.URL.createObjectURL(blob);
  const a = c.doc.createElement('a');
  a.href = url;
  a.download = filename;
  a.style.display = 'none';
  c.doc.body.appendChild(a);
  a.click();
  a.remove();
  c.win.setTimeout(() => c.win.URL.revokeObjectURL(url), 15000);
}

const show = (c, html) => {
  const el = c.doc.getElementById('import-result');
  if (el) el.innerHTML = String(html);
};

function errorList(parsed) {
  const first = parsed.errors.slice(0, 5);
  return h`<div class="notice error" role="alert"><div><b>این فایل پذیرفته نشد و هیچ تغییری اعمال نشد.</b><ul>${first.map((e) => h`<li>${e.message}</li>`)}</ul>${parsed.errorCount > first.length ? h`<div class="small">و ${toPersianDigits(String(parsed.errorCount - first.length))} خطای دیگر.</div>` : ''}</div></div>`;
}

async function readBackupFile(c, file) {
  if (file.size > MAX_BACKUP_BYTES) return { ok: false, errors: [{ message: 'فایل بیش از حد بزرگ است.' }], errorCount: 1 };
  let text;
  try {
    text = await file.text();
  } catch {
    return { ok: false, errors: [{ message: 'خواندن فایل ممکن نشد.' }], errorCount: 1 };
  }
  return parseBackup(text);
}

function safetyDownload(c, state) {
  const json = exportJSON(state, { now: c.nowIso(), appVersion: APP_VERSION });
  download(c, backupFileName(c.nowIso(), 'json', 'safety'), json, 'application/json');
  return true;
}

export const backupActions = {
  'download-backup'(c) {
    const json = exportJSON(c.state, { now: c.nowIso(), appVersion: APP_VERSION });
    download(c, backupFileName(c.nowIso(), 'json', 'backup'), json, 'application/json');
    c.prefs.set({ lastBackupAt: c.nowIso() });
    c.toast('فایل پشتیبان ساخته شد. آن را جایی امن نگه دارید.');
    c.render({ keepScroll: true, focus: false });
  },
  'download-csv'(c, el) {
    const kind = el.dataset.kind === 'accounts' ? 'accounts' : 'transactions';
    download(c, backupFileName(c.nowIso(), 'csv', kind === 'accounts' ? 'accounts' : 'transactions'), exportCSV(c.state, { kind }), 'text/csv;charset=utf-8');
    c.toast('فایل CSV ساخته شد.');
  },

  async 'import-file'(c, input, ev, file) {
    show(c, '');
    const parsed = await readBackupFile(c, file);
    if (!parsed.ok) {
      input.value = '';
      return show(c, errorList(parsed));
    }
    const preview = previewRestore(c.state, parsed.state);
    const ok = await c.sheet(importPreviewHtml({ meta: parsed.meta, preview, fileName: file.name }));
    input.value = '';
    if (!ok) return;
    const choice = c.ui.sheetChoice;
    if (choice === 'merge') {
      const out = await c.commit((s) => mergeStates(s, parsed.state));
      const r = out.report;
      c.toast(`ادغام شد: ${toPersianDigits(String(r.added.transactions))} تراکنش جدید اضافه شد.`, 5000);
    } else if (choice === 'replace') {
      if (preview.currentHasData) {
        const sure = await c.confirm({ title: 'جایگزینی کامل؟', text: 'اطلاعات فعلی این دستگاه پاک و با محتوای فایل جایگزین می‌شود. پیش از آن یک پشتیبان خودکار از اطلاعات فعلی دانلود می‌شود.', confirmLabel: 'بله، جایگزین کن', danger: true });
        if (!sure) return;
      }
      const r = restoreReplace(c.state, parsed.state, { confirm: true, now: c.nowIso(), appVersion: APP_VERSION });
      if (r.safetyBackup) download(c, backupFileName(c.nowIso(), 'json', 'safety'), r.safetyBackup, 'application/json');
      await c.commit(() => r.state);
      c.toast('اطلاعات بازیابی شد.', 5000);
    } else return;
    c.go('#/home');
  },

  async 'ask-wipe'(c) {
    const ok = await c.sheet(
      h`<h2>پاک‌کردن همه‌ی اطلاعات؟</h2><p class="muted">همه‌ی حساب‌ها، تراکنش‌ها، بودجه‌ها، اهداف و بدهی‌ها پاک می‌شود. یک پشتیبان خودکار قبل از آن دانلود می‌شود. برای تأیید، کلمه‌ی «حذف» را بنویسید.</p><div class="field"><input type="text" name="confirmword" id="confirmword" autocomplete="off" aria-label="تأیید حذف"></div><div class="actions two"><button class="btn danger" data-action="sheet-yes">پاک کن</button><button class="btn" data-action="sheet-no">انصراف</button></div>`,
    );
    if (!ok) return;
    if ((c.ui.sheetValues?.confirmword ?? '').trim() !== 'حذف') return c.toast('کلمه‌ی تأیید درست نبود؛ چیزی پاک نشد.');
    safetyDownload(c, c.state);
    await c.commit(() => createEmptyState());
    c.toast('همه‌ی اطلاعات پاک شد.');
    c.go('#/home');
  },

  // ----- داده‌ی خراب -----
  async 'download-corrupt'(c) {
    const raw = await c.store.corruptedRaw();
    download(c, 'hesab-hd-corrupt-data.json', JSON.stringify(raw, null, 1) ?? 'null', 'application/json');
  },
  async 'corrupt-restore'(c, input, ev, file) {
    const parsed = await readBackupFile(c, file);
    if (!parsed.ok) {
      input.value = '';
      return show(c, errorList(parsed));
    }
    const ok = await c.confirm({ title: 'بازیابی از این فایل؟', text: `${toPersianDigits(String(parsed.meta.counts.transactions))} تراکنش و ${toPersianDigits(String(parsed.meta.counts.accounts))} حساب بازیابی می‌شود.`, confirmLabel: 'بازیابی' });
    input.value = '';
    if (!ok) return;
    await c.store.resolveCorruption({ action: 'restore', state: parsed.state });
    c.toast('اطلاعات بازیابی شد.');
    c.go('#/home');
    c.render();
  },
  async 'corrupt-fresh'(c) {
    const ok = await c.confirm({ title: 'شروع از نو؟', text: 'اطلاعات خراب‌شده کنار گذاشته می‌شود و برنامه خالی شروع می‌کند.', confirmLabel: 'شروع از نو', danger: true });
    if (!ok) return;
    await c.store.resolveCorruption({ action: 'startFresh' });
    c.go('#/home');
    c.render();
  },
};
