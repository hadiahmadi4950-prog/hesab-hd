// جدول مسیرها: (قطعه‌های مسیر، context) → { tab, title, html, back?, tabs? }
import { h, notice, card, emptyState } from './components.js';
import { homeView } from './views/home.js';
import { transactionsView, txDetailView, txFormView } from './views/transactions.js';
import { accountsView, accountDetailView, accountFormView } from './views/accounts.js';
import { moreView, rateView, settingsView } from './views/more.js';
import * as extra from './views/extra.js';
import { backupView, corruptView } from './views/backup.js';

export function resolveRoute({ parts }, ctx) {
  if (ctx.corrupt) return corruptView(ctx);
  const [a, b, c] = parts;
  const f = ctx.form ?? {};
  switch (a ?? 'home') {
    case 'home':
      return homeView(ctx);
    case 'transactions':
      return transactionsView(ctx);
    case 'add':
      return txFormView(ctx, { mode: 'add', values: f.values, errors: f.errors ?? [], dup: f.dup });
    case 'tx':
      if (c === 'edit') return txFormView(ctx, { mode: 'edit', id: b, values: f.values, errors: f.errors ?? [], dup: f.dup });
      return txDetailView(ctx, b);
    case 'accounts':
      if (b === 'new') return accountFormView(ctx, { values: f.values, errors: f.errors ?? [] });
      if (b && c === 'edit') return accountFormView(ctx, { id: b, values: f.values, errors: f.errors ?? [] });
      if (b) return accountDetailView(ctx, b);
      return accountsView(ctx);
    case 'more':
      return moreView(ctx);
    case 'rate':
      return rateView(ctx);
    case 'settings':
      return settingsView(ctx);
    case 'backup':
      return backupView(ctx);
    default: {
      const r = extra.resolveExtra?.(parts, ctx);
      if (r) return r;
      return { tab: 'home', title: 'صفحه پیدا نشد', back: '#/home', html: card(emptyState({ emoji: '🧭', title: 'این صفحه وجود ندارد', action: { href: '#/home', label: 'بازگشت به خانه' } })) };
    }
  }
}
