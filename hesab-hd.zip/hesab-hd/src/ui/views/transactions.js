import { h, join, raw, icon, fa, money, card, emptyState, notice, dateLabel } from './common.js';
import { txItem, txList, txInfo, byId, accountOptions, categoryOptions, pendingNotice } from './common.js';
import { field, textInput, amountInput, select, textarea, segmented, dateInput, formErrors, header } from '../components.js';
import * as L from '../../core/ledger.js';
import * as M from '../../core/money.js';
import * as J from '../../core/jalali.js';
import { summarize } from '../../core/reports.js';

// ---------- فهرست و فیلتر ----------

export const PAGE_SIZE = 60;

export function rangeFor(range, today) {
  const p = J.parseDate(today);
  if (range === 'today') return { from: today, to: today };
  if (range === 'week') return J.weekRange(today);
  if (range === 'month') return J.monthRange(p.jy, p.jm);
  if (range === 'lastmonth') {
    const prev = J.parseDate(J.addMonths(today, -1));
    return J.monthRange(prev.jy, prev.jm);
  }
  if (range === 'year') return J.yearRange(p.jy);
  return { from: null, to: null };
}

export function filtersFromQuery(q, today) {
  const range = q.range ?? 'month';
  const r = rangeFor(range, today);
  const f = { from: r.from, to: r.to };
  if (q.type === 'debt') f.type = 'debt_payment';
  else if (q.type) f.type = q.type;
  if (q.acc) f.accountId = q.acc;
  if (q.cat) f.categoryId = q.cat;
  if (q.q) f.text = q.q;
  return { range, filter: f };
}

const RANGES = [
  ['today', 'امروز'],
  ['week', 'این هفته'],
  ['month', 'این ماه'],
  ['lastmonth', 'ماه قبل'],
  ['year', 'امسال'],
  ['all', 'همه'],
];
const TYPES = [
  ['', 'همه'],
  ['expense', 'هزینه'],
  ['income', 'درآمد'],
  ['transfer', 'انتقال'],
  ['debt', 'بدهی'],
];

export function transactionsView(ctx) {
  const { state, today, query: q } = ctx;
  const { range, filter } = filtersFromQuery(q, today);
  const all = L.queryTransactions(state, filter);
  const limit = Number(q.limit) > 0 ? Number(q.limit) : PAGE_SIZE;
  const shown = all.slice(0, limit);
  const sum = summarize(state, { from: filter.from, to: filter.to, currency: 'IRT', accountId: filter.accountId ?? null, categoryId: filter.categoryId ?? null });
  const hasFilters = Boolean(q.type || q.acc || q.cat || q.q);

  const chip = (key, val, label, on) => {
    const next = { ...q, [key]: val };
    if (!val) delete next[key];
    delete next.limit;
    return h`<a class="chipbtn ${on ? 'on' : ''}" href="#/transactions${qs(next)}">${label}</a>`;
  };

  const toolbar = h`<form data-action="filter" data-autosubmit role="search"><div class="field"><label class="sr" for="q">جستجو</label><input type="search" id="q" name="q" value="${q.q ?? ''}" placeholder="جستجو در یادداشت، دسته و حساب…" autocomplete="off"></div><div class="chips">${RANGES.map(([k, l]) => chip('range', k === 'month' ? '' : k, l, range === k))}</div><div class="chips">${TYPES.map(([k, l]) => chip('type', k, l, (q.type ?? '') === k))}</div><details ${q.acc || q.cat ? raw('open') : ''}><summary class="link">فیلتر بیشتر</summary><div class="grid2" style="margin-top:8px">${field('حساب', select('acc', [{ value: '', label: 'همه‌ی حساب‌ها' }, ...accountOptions(state, { includeArchived: true })], q.acc ?? '', { id: 'facc' }), { id: 'facc' })}${field('دسته', select('cat', [{ value: '', label: 'همه‌ی دسته‌ها' }, ...state.categories.map((c) => ({ value: c.id, label: `${c.icon} ${c.name}` }))], q.cat ?? '', { id: 'fcat' }), { id: 'fcat' })}</div></details><input type="hidden" name="range" value="${q.range ?? ''}"><input type="hidden" name="type" value="${q.type ?? ''}"></form>`;

  const summaryCard = all.length
    ? h`<div class="grid2"><div class="stat"><span class="muted small">درآمد</span><b class="num pos">+${money('IRT', sum.income)}</b></div><div class="stat"><span class="muted small">هزینه</span><b class="num neg">−${money('IRT', sum.expense)}</b></div></div><div class="hint">${fa(all.length)} تراکنش (جمع‌ها فقط تومانی و بدون انتقال و پرداخت بدهی)</div>`
    : '';

  let list;
  if (all.length === 0) {
    list = state.transactions.length === 0
      ? emptyState({ emoji: '🧾', title: 'هنوز تراکنشی ثبت نشده', text: state.accounts.length ? 'اولین درآمد یا هزینه‌تان را ثبت کنید.' : 'ابتدا یک حساب بسازید.', action: state.accounts.length ? { href: '#/add', label: 'ثبت تراکنش' } : { href: '#/accounts/new', label: 'افزودن حساب' } })
      : emptyState({ emoji: '🔎', title: 'تراکنشی پیدا نشد', text: hasFilters || range !== 'month' ? 'فیلترها را تغییر دهید.' : 'در این بازه تراکنشی نیست.', action: { href: '#/transactions?range=all', label: 'نمایش همه' } });
  } else {
    list = h`${txList(state, shown, today)}${all.length > shown.length ? h`<div class="actions"><a class="btn" href="#/transactions${qs({ ...q, limit: limit + PAGE_SIZE })}">نمایش بیشتر (${fa(all.length - shown.length)} مورد دیگر)</a></div>` : ''}`;
  }

  return {
    tab: 'transactions',
    title: 'تراکنش‌ها',
    html: join([pendingNotice(ctx), card(toolbar), summaryCard ? card(summaryCard) : '', card(list)]),
  };
}

export function qs(obj) {
  const p = Object.entries(obj).filter(([, v]) => v !== undefined && v !== null && v !== '');
  return p.length ? `?${p.map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&')}` : '';
}

// ---------- جزئیات ----------

export function txDetailView(ctx, id) {
  const { state, today } = ctx;
  const t = byId(state.transactions, id);
  if (!t) return { tab: 'transactions', title: 'تراکنش', back: '#/transactions', html: card(emptyState({ emoji: '🤷', title: 'تراکنش پیدا نشد', action: { href: '#/transactions', label: 'بازگشت به فهرست' } })) };
  const i = txInfo(state, t);
  const rows = [['تاریخ', fa(J.formatLong(t.date))], ['نوع', { income: 'درآمد', expense: 'هزینه', transfer: 'انتقال', debt_payment: 'پرداخت بدهی/طلب' }[t.type]]];
  if (t.type === 'transfer') {
    rows.push(['از حساب', byId(state.accounts, t.fromAccountId)?.name ?? '؟'], ['به حساب', byId(state.accounts, t.toAccountId)?.name ?? '؟']);
    if (t.currency !== t.toCurrency) rows.push(['مبلغ دریافتی', money(t.toCurrency, t.toAmount)]);
  } else {
    rows.push(['حساب', byId(state.accounts, t.accountId)?.name ?? '؟']);
    if (t.categoryId) rows.push(['دسته', i.title]);
  }
  if (t.note) rows.push(['یادداشت', t.note]);
  if (t.method) rows.push(['روش پرداخت', t.method]);

  let usd = '';
  if (t.currency === 'IRT' && (t.type === 'income' || t.type === 'expense')) {
    if (t.usd.status === 'done') {
      usd = card(
        h`<div class="kv"><span>معادل دلاری</span><b class="num">${M.formatUsd(t.usd.cents)}</b></div><div class="kv"><span>نرخ استفاده‌شده</span><span class="num">${money('IRT', t.usd.rate)} برای هر دلار</span></div><div class="kv"><span>زمان نرخ</span><span class="num">${fmtTime(t.usd.rateAt)}</span></div><div class="kv"><span>منبع</span><span>${t.usd.source}${t.usd.manual ? ' (وارد‌شده توسط شما)' : ''}</span></div><div class="hint">معادل دلاری با نرخ لحظه‌ی محاسبه ساخته شده است، نه نرخ روز تراکنش. مبلغ اصلی تومانی تغییر نمی‌کند.</div><div class="actions"><a class="btn" href="#/rate?tx=${t.id}">محاسبه‌ی دوباره با نرخ دستی</a></div>`,
        { title: 'معادل دلاری' },
      );
    } else {
      usd = card(h`<p>این تراکنش هنوز معادل دلاری ندارد. بعد از دریافت نرخ لحظه‌ای (یا ورود نرخ دستی) محاسبه می‌شود.</p><div class="actions two"><button class="btn" data-action="sync-rate" ${ctx.online ? '' : raw('disabled')}>دریافت نرخ</button><a class="btn" href="#/rate?tx=${t.id}">نرخ دستی</a></div>`, { title: 'معادل دلاری (در انتظار)' });
    }
  }

  const body = join([
    h`<section class="card"><div class="row"><span class="badge">${i.emoji}</span><div class="grow"><div class="t">${i.title}</div><div class="small muted">${i.sub}</div></div></div><div class="num ${i.cls}" style="font-size:1.6rem;font-weight:800;margin:10px 0">${i.sign}${i.amountText}</div>${rows.map(([k, v]) => h`<div class="kv"><span class="muted">${k}</span><span>${v}</span></div>`)}</section>`,
    usd,
    h`<div class="actions two"><a class="btn" href="#/tx/${t.id}/edit">${icon('edit')} ویرایش</a><button class="btn danger" data-action="ask-delete-tx" data-id="${t.id}">${icon('trash')} حذف</button></div>`,
  ]);
  return { tab: 'transactions', title: 'جزئیات تراکنش', back: '#/transactions', html: body };
}

export function fmtTime(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const p = J.parseDate(J.todayJalali(d, 'Asia/Tehran'));
  const time = new Intl.DateTimeFormat('fa-IR', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Tehran', hour12: false }).format(d);
  return `${p ? `${fa(p.jd)} ${J.MONTH_NAMES[p.jm - 1]} ${fa(p.jy)}` : ''} ساعت ${time}`;
}

// ---------- فرم ثبت/ویرایش ----------

export function defaultTxValues(ctx, type = 'expense') {
  const acc = ctx.state.accounts.find((a) => !a.archived);
  return { type, amount: '', accountId: acc?.id ?? '', fromAccountId: acc?.id ?? '', toAccountId: '', toAmount: '', categoryId: '', note: '', date: ctx.today, requestId: globalThis.crypto?.randomUUID?.() ?? '' };
}

export function txValuesFrom(t) {
  const cur = t.currency;
  return {
    type: t.type,
    amount: M.toEditableString(cur, t.amount),
    accountId: t.accountId ?? '',
    fromAccountId: t.fromAccountId ?? '',
    toAccountId: t.toAccountId ?? '',
    toAmount: t.toAmount !== null && t.toAmount !== undefined && t.toCurrency ? M.toEditableString(t.toCurrency, t.toAmount) : '',
    categoryId: t.categoryId ?? '',
    note: t.note ?? '',
    date: t.date,
    requestId: '',
  };
}

export function txFormView(ctx, { mode = 'add', id = null, values = null, errors = [], dup = null } = {}) {
  const { state } = ctx;
  if (state.accounts.filter((a) => !a.archived).length === 0) {
    return { tab: 'add', title: 'ثبت تراکنش', html: card(emptyState({ emoji: '🏦', title: 'ابتدا یک حساب بسازید', text: 'هر تراکنش به یک حساب (کیف پول، حساب بانکی…) وصل است.', action: { href: '#/accounts/new', label: 'افزودن حساب' } })) };
  }
  const edit = mode === 'edit';
  const old = edit ? byId(state.transactions, id) : null;
  if (edit && !old) return { tab: 'transactions', title: 'ویرایش', back: '#/transactions', html: card(emptyState({ emoji: '🤷', title: 'تراکنش پیدا نشد' })) };
  const v = values ?? (edit ? txValuesFrom(old) : defaultTxValues(ctx, ctx.query?.type === 'income' ? 'income' : ctx.query?.type === 'transfer' ? 'transfer' : 'expense'));
  const type = v.type;
  const isDebt = type === 'debt_payment';
  const fe = (f) => errors.filter((e) => e.field === f).map((e) => e.message).join(' ');
  const accs = accountOptions(state, { includeArchived: false });
  const accCur = (accId) => byId(state.accounts, accId)?.currency ?? 'IRT';

  let typeSel;
  if (isDebt) typeSel = h`<div class="notice"><div>این پرداخت مربوط به یک بدهی/طلب است؛ نوعش قابل تغییر نیست.</div></div><input type="hidden" name="type" value="debt_payment">`;
  else if (edit && type === 'transfer') typeSel = h`<input type="hidden" name="type" value="transfer"><div class="chips"><span class="chipbtn on">انتقال بین حساب‌ها</span></div>`;
  else if (edit) typeSel = segmented('type', [{ value: 'expense', label: 'هزینه', cls: 'exp' }, { value: 'income', label: 'درآمد', cls: 'inc' }], type);
  else typeSel = segmented('type', [{ value: 'expense', label: 'هزینه', cls: 'exp' }, { value: 'income', label: 'درآمد', cls: 'inc' }, { value: 'transfer', label: 'انتقال' }], type);
  const typeCtl = h`<div data-rerender>${typeSel}</div>`;

  let main;
  if (type === 'transfer') {
    const fromCur = accCur(v.fromAccountId);
    const toAcc = v.toAccountId ? byId(state.accounts, v.toAccountId) : null;
    const cross = toAcc && toAcc.currency !== fromCur;
    main = join([
      field('از حساب', h`<div data-rerender>${select('fromAccountId', accs, v.fromAccountId, { id: 'fromAccountId' })}</div>`, { id: 'fromAccountId', error: fe('fromAccountId') }),
      field('به حساب', h`<div data-rerender>${select('toAccountId', [{ value: '', label: 'انتخاب کنید…' }, ...accountOptions(state, { exclude: v.fromAccountId })], v.toAccountId, { id: 'toAccountId' })}</div>`, { id: 'toAccountId', error: fe('toAccountId') }),
      field(cross ? `مبلغ برداشتی از مبدأ (${M.CURRENCIES[fromCur].name})` : 'مبلغ', amountInput('amount', v.amount, { currency: fromCur }), { id: 'amount', error: fe('amount') }),
      cross ? field(`مبلغ دریافتی در مقصد (${M.CURRENCIES[toAcc.currency].name})`, amountInput('toAmount', v.toAmount, { currency: toAcc.currency, id: 'toAmount' }), { id: 'toAmount', error: fe('toAmount'), hint: 'برای انتقال بین دو ارز، مبلغ دقیقی را که دریافت کرده‌اید وارد کنید؛ برنامه نرخ حدس نمی‌زند.' }) : '',
    ]);
  } else {
    const cur = accCur(v.accountId);
    const kind = type === 'income' ? 'income' : 'expense';
    const cats = state.categories.filter((c) => c.kind === kind);
    main = join([
      field('مبلغ', amountInput('amount', v.amount, { currency: cur }), { id: 'amount', error: fe('amount') }),
      isDebt ? h`<input type="hidden" name="debtId" value="${old?.debtId ?? ''}">` : '',
      field('حساب', h`<div data-rerender>${select('accountId', accs, v.accountId, { id: 'accountId' })}</div>`, { id: 'accountId', error: fe('accountId') }),
      isDebt ? '' : field('دسته‌بندی', h`<div class="catgrid" role="radiogroup" aria-label="دسته‌بندی">${cats.map((c) => h`<label class="catpick"><input type="radio" name="categoryId" value="${c.id}" ${c.id === v.categoryId ? raw('checked') : ''}><span class="catbtn"><span class="e" aria-hidden="true">${c.icon}</span>${c.name}</span></label>`)}</div><a class="link" href="#/categories/new?kind=${kind}">+ دسته‌ی جدید</a>`, { error: fe('categoryId') }),
    ]);
  }

  const dupBox = dup ? h`<div class="notice warn" role="alert">${icon('warn', { size: 20 })}<div>تراکنش مشابهی (همان مبلغ، تاریخ، حساب و دسته) قبلاً ثبت شده است. اگر واقعاً دوباره خرج کرده‌اید، «ثبت به‌هر‌حال» را بزنید.<div class="actions two" style="margin-top:8px"><button class="btn primary" type="submit" name="allowDuplicate" value="1">ثبت به‌هر‌حال</button><a class="btn" href="#/tx/${dup.existingId}">دیدن تراکنش قبلی</a></div></div></div>` : '';

  const html = h`<form data-action="${edit ? 'save-tx-edit' : 'save-tx'}" ${edit ? raw(`data-id="${id}"`) : ''} novalidate>${formErrors(errors.filter((e) => !e.field || !['amount', 'accountId', 'fromAccountId', 'toAccountId', 'toAmount', 'categoryId'].includes(e.field)))}${dupBox}<input type="hidden" name="requestId" value="${v.requestId ?? ''}"><div class="card" style="display:grid;gap:14px">${typeCtl}${main}${field('تاریخ', dateInput('date', v.date), { error: fe('date') })}${field('یادداشت (اختیاری)', textarea('note', v.note, { rows: 2 }), { error: fe('note') })}${edit && old.currency === 'IRT' && (old.type === 'income' || old.type === 'expense') ? h`<div class="hint">اگر مبلغ را تغییر دهید، معادل دلاری قبلی بایگانی می‌شود و دوباره محاسبه خواهد شد.</div>` : ''}</div><div class="actions"><button class="btn primary block" type="submit">${edit ? 'ذخیره‌ی تغییرات' : 'ثبت تراکنش'}</button></div></form>`;
  return { tab: edit ? 'transactions' : 'add', title: edit ? 'ویرایش تراکنش' : 'ثبت تراکنش', back: edit ? `#/tx/${id}` : null, html };
}
