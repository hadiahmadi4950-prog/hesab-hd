import { h, join, raw, icon, fa, money, card, emptyState, notice, progress, percentText, dateLabel, txAmountClass } from '../components.js';
import * as L from '../../core/ledger.js';
import * as M from '../../core/money.js';

export const byId = (list, id) => list.find((x) => x.id === id) ?? null;

export function txInfo(state, t) {
  if (t.type === 'transfer') {
    const from = byId(state.accounts, t.fromAccountId);
    const to = byId(state.accounts, t.toAccountId);
    return { emoji: '🔁', title: 'انتقال بین حساب‌ها', sub: `${from?.name ?? '؟'} ← ${to?.name ?? '؟'}${t.currency === t.toCurrency ? '' : ` (دریافتی ${money(t.toCurrency, t.toAmount)})`}`, sign: '', cls: 'neu', amountText: money(t.currency, t.amount) };
  }
  if (t.type === 'debt_payment') {
    const d = byId(state.debts, t.debtId);
    const acc = byId(state.accounts, t.accountId);
    const owe = d?.direction === 'owe';
    return { emoji: '🤝', title: owe ? `پرداخت بدهی به ${d?.person ?? '؟'}` : `دریافت طلب از ${d?.person ?? '؟'}`, sub: acc?.name ?? '', sign: owe ? '−' : '+', cls: owe ? 'neg' : 'pos', amountText: money(t.currency, t.amount) };
  }
  const cat = byId(state.categories, t.categoryId);
  const acc = byId(state.accounts, t.accountId);
  const income = t.type === 'income';
  return { emoji: cat?.icon ?? '🏷️', title: cat?.name ?? 'بدون دسته', sub: acc?.name ?? '', sign: income ? '+' : '−', cls: txAmountClass(t.type), amountText: money(t.currency, t.amount), color: cat?.color };
}

export function usdBadge(t) {
  if (t.currency !== 'IRT' || t.type === 'transfer' || t.type === 'debt_payment') return '';
  if (t.usd?.status === 'pending') return h`<span class="tag pend">در انتظار نرخ دلار</span>`;
  if (t.usd?.status === 'done') return h`<span class="tag ok">≈ ${M.formatUsd(t.usd.cents)}${t.usd.manual ? ' (دستی)' : ''}</span>`;
  return '';
}

export function txItem(state, t, { today = null, showDate = false } = {}) {
  const i = txInfo(state, t);
  return h`<a class="item" href="#/tx/${t.id}"><span class="badge" aria-hidden="true">${i.emoji}</span><span class="grow"><span class="t">${i.title}</span>${usdBadge(t)}<br><span class="s">${[i.sub, t.note, showDate ? dateLabel(t.date, today) : ''].filter(Boolean).join(' · ')}</span></span><span class="amt num ${i.cls}">${i.sign}${i.amountText}</span></a>`;
}

export function groupByDate(list) {
  const groups = [];
  for (const t of list) {
    const last = groups[groups.length - 1];
    if (last && last.date === t.date) last.items.push(t);
    else groups.push({ date: t.date, items: [t] });
  }
  return groups;
}

export function txList(state, list, today) {
  if (list.length === 0) return '';
  return join(
    groupByDate(list).map(
      (g) => h`<div class="day-head">${dateLabel(g.date, today)}</div><div class="list">${g.items.map((t) => txItem(state, t, { today }))}</div>`,
    ),
  );
}

export function accountOptions(state, { currency = null, exclude = null, includeArchived = false } = {}) {
  return state.accounts
    .filter((a) => (includeArchived || !a.archived) && (!currency || a.currency === currency) && a.id !== exclude)
    .map((a) => ({ value: a.id, label: `${a.name} (${M.CURRENCIES[a.currency].name})` }));
}

export function categoryOptions(state, kind) {
  return state.categories.filter((c) => c.kind === kind).map((c) => ({ value: c.id, label: `${c.icon} ${c.name}` }));
}

export function pendingNotice(ctx) {
  const n = ctx.pendingCount;
  if (!n) return '';
  const online = ctx.online;
  return notice(
    h`${fa(n)} تراکنش هنوز معادل دلاری ندارد. ${online ? 'با «به‌روزرسانی نرخ» محاسبه می‌شود.' : 'وقتی اینترنت وصل شد خودکار محاسبه می‌شود.'} می‌توانید نرخ را دستی هم وارد کنید.<div class="actions two" style="margin-top:8px"><button class="btn" data-action="sync-rate" ${online ? '' : raw('disabled')}>به‌روزرسانی نرخ</button><a class="btn" href="#/rate">نرخ دستی</a></div>`,
    'warn',
  );
}

export { h, join, raw, icon, fa, money, card, emptyState, notice, progress, percentText, dateLabel };
