import { h, join, raw, icon, fa, money, card, emptyState, notice, progress, percentText, dateLabel } from './common.js';
import { byId, accountOptions } from './common.js';
import { field, textInput, amountInput, select, segmented, dateInput, formErrors, textarea } from '../components.js';
import * as L from '../../core/ledger.js';
import * as M from '../../core/money.js';
import * as J from '../../core/jalali.js';

const faDate = (d) => fa(J.formatLong(d));

// ---------- اهداف ----------

export function goalsView(ctx) {
  const { state, today } = ctx;
  const list = state.goals.map((g) => L.goalProgress(g, today));
  const parts = [];
  if (list.length === 0) parts.push(card(emptyState({ emoji: '🎯', title: 'هنوز هدفی ندارید', text: 'برای چیزی که می‌خواهید بخرید یا پس‌انداز کنید هدف بسازید و پیشرفتش را ببینید.', action: { href: '#/goals/new', label: 'ساخت هدف' } })));
  else {
    parts.push(card(join(list.map((g) => h`<a class="item" href="#/goals/${g.goal.id}" style="display:block"><div class="row between"><b>${g.goal.name}</b><span class="small ${g.reached ? 'pos' : 'muted'}">${g.reached ? 'رسیدید 🎉' : percentText(g.progressBp)}</span></div>${progress(g.progressBp, 'ok', g.goal.name)}<div class="small muted">${money(g.goal.currency, g.saved)} از ${money(g.goal.currency, g.goal.targetAmount)}${g.daysLeft !== null ? (g.overdue ? ' · موعد گذشته' : ` · ${fa(g.daysLeft)} روز مانده`) : ''}</div></a>`))), h`<div class="actions"><a class="btn primary" href="#/goals/new">${icon('plus')} هدف جدید</a></div>`);
    parts.push(notice('پس‌انداز هدف فقط یک «علامت‌گذاری» است؛ موجودی حساب‌ها را تغییر نمی‌دهد و جزو هزینه حساب نمی‌شود.', 'info'));
  }
  return { tab: 'more', title: 'اهداف پس‌انداز', back: '#/more', html: join(parts) };
}

export function goalFormView(ctx, { id = null, values = null, errors = [] } = {}) {
  const { state } = ctx;
  const edit = Boolean(id);
  const old = edit ? byId(state.goals, id) : null;
  if (edit && !old) return { tab: 'more', title: 'هدف', back: '#/goals', html: card(emptyState({ emoji: '🤷', title: 'هدف پیدا نشد' })) };
  const v = values ?? (old ? { name: old.name, currency: old.currency, targetAmount: M.toEditableString(old.currency, old.targetAmount), targetDate: old.targetDate ?? '' } : { name: '', currency: 'IRT', targetAmount: '', targetDate: '' });
  const fe = (f) => errors.filter((e) => e.field === f).map((e) => e.message).join(' ');
  const html = h`<form data-action="${edit ? 'save-goal-edit' : 'save-goal'}" ${edit ? raw(`data-id="${id}"`) : ''} novalidate>${formErrors(errors.filter((e) => !['name', 'currency', 'targetAmount', 'targetDate'].includes(e.field)))}<div class="card" style="display:grid;gap:14px">${field('نام هدف', textInput('name', v.name, { placeholder: 'مثلاً خرید لپ‌تاپ', maxlength: 40 }), { id: 'name', error: fe('name') })}${edit ? h`<input type="hidden" name="currency" value="${v.currency}">` : field('واحد پول', h`<div data-rerender>${select('currency', [{ value: 'IRT', label: 'تومان' }, { value: 'USD', label: 'دلار' }], v.currency)}</div>`, { id: 'currency' })}${field('مبلغ هدف', amountInput('targetAmount', v.targetAmount, { currency: v.currency, id: 'targetAmount' }), { id: 'targetAmount', error: fe('targetAmount') })}${field('تاریخ هدف (اختیاری)', dateInput('targetDate', v.targetDate || null, { optional: true, maxYear: 1430 }), { error: fe('targetDate') })}</div><div class="actions"><button class="btn primary block" type="submit">${edit ? 'ذخیره' : 'ساخت هدف'}</button></div></form>`;
  return { tab: 'more', title: edit ? 'ویرایش هدف' : 'هدف جدید', back: edit ? `#/goals/${id}` : '#/goals', html };
}

export function goalDetailView(ctx, id) {
  const { state, today, form } = ctx;
  const g = byId(state.goals, id);
  if (!g) return { tab: 'more', title: 'هدف', back: '#/goals', html: card(emptyState({ emoji: '🤷', title: 'هدف پیدا نشد' })) };
  const p = L.goalProgress(g, today);
  const errs = form?.errors ?? [];
  const v = form?.values ?? { kind: 'add', amount: '', note: '', date: today };
  const contribs = [...g.contributions].sort((a, b) => (a.date < b.date ? 1 : -1));
  const html = join([
    h`<section class="card hero"><div class="muted small">${g.name}</div><div class="big num">${money(g.currency, p.saved)}</div><div class="muted small">از ${money(g.currency, g.targetAmount)} · ${percentText(p.progressBp)}${p.daysLeft !== null ? (p.overdue ? ' · موعد گذشته' : ` · ${fa(p.daysLeft)} روز مانده`) : ''}</div><div style="margin-top:10px">${progress(p.progressBp, 'ok', g.name)}</div>${p.reached ? h`<div style="margin-top:8px">🎉 به هدف رسیدید!</div>` : h`<div style="margin-top:8px" class="small">${money(g.currency, p.remaining)} تا هدف مانده</div>`}</section>`,
    card(
      h`<form data-action="goal-contribute" data-id="${id}" novalidate>${formErrors(errs.filter((e) => e.field !== 'amount'))}${segmented('kind', [{ value: 'add', label: 'افزودن به پس‌انداز' }, { value: 'withdraw', label: 'برداشت' }], v.kind)}${field('مبلغ', amountInput('amount', v.amount, { currency: g.currency, id: 'amount' }), { id: 'amount', error: errs.find((e) => e.field === 'amount')?.message })}${field('تاریخ', dateInput('date', v.date))}${field('یادداشت (اختیاری)', textInput('note', v.note ?? ''))}<button class="btn primary" type="submit">ثبت</button></form>`,
      { title: 'ثبت پس‌انداز' },
    ),
    card(contribs.length ? h`<div class="list">${contribs.map((c) => h`<div class="item" style="cursor:default"><span class="badge">${c.kind === 'add' ? '⬆️' : '⬇️'}</span><span class="grow"><span class="t">${c.kind === 'add' ? 'افزودن' : 'برداشت'}</span><br><span class="s">${dateLabel(c.date, today)}${c.note ? ` · ${c.note}` : ''}</span></span><span class="amt num ${c.kind === 'add' ? 'pos' : 'neg'}">${c.kind === 'add' ? '+' : '−'}${money(g.currency, c.amount)}</span><button class="iconbtn" data-action="remove-contribution" data-goal="${g.id}" data-id="${c.id}" aria-label="حذف این مورد">${icon('trash', { size: 18 })}</button></div>`)}</div>` : emptyState({ emoji: '🐖', title: 'هنوز چیزی پس‌انداز نکرده‌اید' }), { title: 'تاریخچه' }),
    h`<div class="actions two"><a class="btn" href="#/goals/${id}/edit">${icon('edit')} ویرایش</a><button class="btn danger" data-action="ask-delete-goal" data-id="${id}">${icon('trash')} حذف</button></div>`,
  ]);
  return { tab: 'more', title: g.name, back: '#/goals', html };
}

// ---------- بدهی و طلب ----------

const DIR = { owe: 'بدهی من', owed: 'طلب من' };

export function debtsView(ctx) {
  const { state, today } = ctx;
  const all = state.debts.map((d) => L.debtStatus(state, d.id, today));
  const open = all.filter((s) => s.status !== 'settled');
  const done = all.filter((s) => s.status === 'settled');
  const row = (s) => h`<a class="item" href="#/debts/${s.debt.id}"><span class="badge">${s.debt.direction === 'owe' ? '📤' : '📥'}</span><span class="grow"><span class="t">${s.debt.person}</span>${s.status === 'overdue' ? h`<span class="tag bad">سررسید گذشته</span>` : ''}${s.status === 'settled' ? h`<span class="tag ok">تسویه‌شده</span>` : ''}<br><span class="s">${DIR[s.debt.direction]}${s.debt.dueDate ? ` · سررسید ${dateLabel(s.debt.dueDate, today)}` : ''}</span></span><span class="amt num ${s.debt.direction === 'owe' ? 'neg' : 'pos'}">${money(s.debt.currency, s.remaining)}</span></a>`;
  const parts = [];
  if (all.length === 0) parts.push(card(emptyState({ emoji: '🤝', title: 'بدهی یا طلبی ثبت نشده', text: 'پولی که قرض گرفته‌اید یا قرض داده‌اید را اینجا ثبت کنید و پرداخت‌های قسطی را دنبال کنید.', action: { href: '#/debts/new', label: 'ثبت مورد جدید' } })));
  else {
    for (const dir of ['owe', 'owed']) {
      const list = open.filter((s) => s.debt.direction === dir);
      if (list.length) parts.push(card(h`<div class="list">${list.map(row)}</div>`, { title: dir === 'owe' ? 'بدهی‌های من' : 'طلب‌های من' }));
    }
    if (done.length) parts.push(card(h`<div class="list">${done.map(row)}</div>`, { title: 'تسویه‌شده' }));
    parts.push(h`<div class="actions two"><a class="btn primary" href="#/debts/new?dir=owe">${icon('plus')} بدهی جدید</a><a class="btn primary" href="#/debts/new?dir=owed">${icon('plus')} طلب جدید</a></div>`);
  }
  return { tab: 'more', title: 'بدهی و طلب', back: '#/more', html: join(parts) };
}

export function debtFormView(ctx, { id = null, values = null, errors = [] } = {}) {
  const { state, today, query } = ctx;
  const edit = Boolean(id);
  const old = edit ? byId(state.debts, id) : null;
  if (edit && !old) return { tab: 'more', title: 'بدهی', back: '#/debts', html: card(emptyState({ emoji: '🤷', title: 'مورد پیدا نشد' })) };
  const v = values ?? (old ? { direction: old.direction, person: old.person, currency: old.currency, principal: M.toEditableString(old.currency, old.principal), date: old.date, dueDate: old.dueDate ?? '', accountId: old.accountId ?? '', note: old.note ?? '' } : { direction: query?.dir === 'owed' ? 'owed' : 'owe', person: '', currency: 'IRT', principal: '', date: today, dueDate: '', accountId: '', note: '' });
  const fe = (f) => errors.filter((e) => e.field === f).map((e) => e.message).join(' ');
  const accs = [{ value: '', label: 'بدون اثر روی حساب‌ها' }, ...accountOptions(state, { currency: v.currency })];
  const owe = v.direction === 'owe';
  const html = h`<form data-action="${edit ? 'save-debt-edit' : 'save-debt'}" ${edit ? raw(`data-id="${id}"`) : ''} novalidate>${formErrors(errors.filter((e) => !['person', 'principal', 'date', 'dueDate', 'accountId', 'currency', 'direction', 'note'].includes(e.field)))}<div class="card" style="display:grid;gap:14px">${edit ? h`<input type="hidden" name="direction" value="${v.direction}"><input type="hidden" name="currency" value="${v.currency}"><div class="notice"><div>${DIR[v.direction]}</div></div>` : h`<div data-rerender>${segmented('direction', [{ value: 'owe', label: 'بدهی من (قرض گرفتم)' }, { value: 'owed', label: 'طلب من (قرض دادم)' }], v.direction)}</div>${field('واحد پول', h`<div data-rerender>${select('currency', [{ value: 'IRT', label: 'تومان' }, { value: 'USD', label: 'دلار' }], v.currency)}</div>`, { id: 'currency' })}`}${field('طرف حساب', textInput('person', v.person, { maxlength: 40, placeholder: 'نام شخص یا مؤسسه' }), { id: 'person', error: fe('person') })}${field('مبلغ کل', amountInput('principal', v.principal, { currency: v.currency, id: 'principal' }), { id: 'principal', error: fe('principal') })}${edit ? '' : field('تاریخ', dateInput('date', v.date), { error: fe('date') })}${field('سررسید (اختیاری)', dateInput('dueDate', v.dueDate || null, { optional: true, maxYear: 1430 }), { error: fe('dueDate') })}${edit ? '' : field(owe ? 'پول به کدام حساب آمد؟' : 'پول از کدام حساب رفت؟', select('accountId', accs, v.accountId, { id: 'accountId' }), { id: 'accountId', error: fe('accountId'), hint: 'اگر انتخاب کنید، موجودی آن حساب هم‌اکنون تغییر می‌کند. اگر پول قبلاً در موجودی اولیه حساب‌ها حساب شده، «بدون اثر» را بگذارید.' })}${field('یادداشت (اختیاری)', textarea('note', v.note, { rows: 2 }), { error: fe('note') })}</div><div class="actions"><button class="btn primary block" type="submit">${edit ? 'ذخیره' : 'ثبت'}</button></div></form>`;
  return { tab: 'more', title: edit ? 'ویرایش' : 'بدهی/طلب جدید', back: edit ? `#/debts/${id}` : '#/debts', html };
}

export function debtDetailView(ctx, id) {
  const { state, today, form } = ctx;
  const d = byId(state.debts, id);
  if (!d) return { tab: 'more', title: 'بدهی', back: '#/debts', html: card(emptyState({ emoji: '🤷', title: 'مورد پیدا نشد' })) };
  const s = L.debtStatus(state, id, today);
  const owe = d.direction === 'owe';
  const pays = L.queryTransactions(state, { type: 'debt_payment' }).filter((t) => t.debtId === id);
  const errs = form?.errors ?? [];
  const v = form?.values ?? { amount: String(M.toEditableString(d.currency, s.remaining)), date: today, note: '', accountId: d.accountId ?? state.accounts.find((a) => !a.archived && a.currency === d.currency)?.id ?? '' };
  const accs = accountOptions(state, { currency: d.currency });
  const html = join([
    h`<section class="card hero"><div class="muted small">${DIR[d.direction]} · ${d.person}</div><div class="big num">${money(d.currency, s.remaining)}</div><div class="muted small">مانده از ${money(d.currency, d.principal)} · ${percentText(s.progressBp)} ${owe ? 'پرداخت شده' : 'دریافت شده'}</div><div style="margin-top:10px">${progress(s.progressBp, 'ok', d.person)}</div></section>`,
    s.status === 'overdue' ? notice('سررسید این مورد گذشته است.', 'warn') : '',
    card(h`<div class="kv"><span class="muted">تاریخ ثبت</span><span>${faDate(d.date)}</span></div>${d.dueDate ? h`<div class="kv"><span class="muted">سررسید</span><span>${faDate(d.dueDate)}</span></div>` : ''}${d.accountId ? h`<div class="kv"><span class="muted">حساب مرتبط</span><span>${byId(state.accounts, d.accountId)?.name ?? '؟'}</span></div>` : ''}${d.note ? h`<div class="kv"><span class="muted">یادداشت</span><span>${d.note}</span></div>` : ''}`),
    s.remaining > 0
      ? card(
          accs.length === 0 ? notice(`برای ثبت ${owe ? 'پرداخت' : 'دریافت'} به یک حساب ${M.CURRENCIES[d.currency].name}ی نیاز دارید.`, 'warn') : h`<form data-action="debt-pay" data-id="${id}" novalidate>${formErrors(errs.filter((e) => !['amount', 'accountId'].includes(e.field)))}${field('مبلغ', amountInput('amount', v.amount, { currency: d.currency, id: 'amount' }), { id: 'amount', error: errs.find((e) => e.field === 'amount')?.message, hint: 'می‌توانید بخشی از مبلغ را بدهید؛ مانده می‌ماند.' })}${field(owe ? 'از کدام حساب پرداخت شد؟' : 'به کدام حساب واریز شد؟', select('accountId', accs, v.accountId, { id: 'accountId' }), { id: 'accountId', error: errs.find((e) => e.field === 'accountId')?.message })}${field('تاریخ', dateInput('date', v.date))}${field('یادداشت (اختیاری)', textInput('note', v.note ?? ''))}<button class="btn primary" type="submit">${owe ? 'ثبت پرداخت' : 'ثبت دریافت'}</button></form>`,
          { title: owe ? 'پرداخت قسط' : 'دریافت قسط' },
        )
      : card(h`<p class="pos">✅ تسویه شد.</p>`),
    card(pays.length ? h`<div class="list">${pays.map((t) => h`<a class="item" href="#/tx/${t.id}"><span class="badge">💸</span><span class="grow"><span class="t">${dateLabel(t.date, today)}</span><br><span class="s">${byId(state.accounts, t.accountId)?.name ?? ''}${t.note ? ` · ${t.note}` : ''}</span></span><span class="amt num">${money(t.currency, t.amount)}</span></a>`)}</div>` : emptyState({ emoji: '🧾', title: 'هنوز پرداختی ثبت نشده' }), { title: 'پرداخت‌ها' }),
    h`<div class="actions two"><a class="btn" href="#/debts/${id}/edit">${icon('edit')} ویرایش</a><button class="btn danger" data-action="ask-delete-debt" data-id="${id}">${icon('trash')} حذف</button></div>`,
  ]);
  return { tab: 'more', title: d.person, back: '#/debts', html };
}
