import { h, join, raw, icon, fa, money, card, emptyState, progress, percentText } from './common.js';
import { txItem, pendingNotice } from './common.js';
import { backupReminder } from './backup.js';
import { dashboard } from '../../core/reports.js';
import { barChart as bc } from '../components.js';
import * as M from '../../core/money.js';
import * as J from '../../core/jalali.js';

export function homeView(ctx) {
  const { state, today } = ctx;
  const d = dashboard(state, today, { recent: 5, trendMonths: 6 });
  const body = [];

  if (state.accounts.length === 0) {
    body.push(
      card(
        emptyState({
          emoji: '👋',
          title: 'به «حساب HD» خوش آمدید',
          text: 'برای شروع، حساب‌هایتان را بسازید (مثلاً «کیف پول» یا «حساب بانک ملی») و موجودی فعلی هر کدام را وارد کنید. همه‌چیز فقط روی همین دستگاه می‌ماند.',
          action: { href: '#/accounts/new', label: 'افزودن اولین حساب' },
        }),
      ),
      card(h`<div class="row"><span class="badge">🔒</span><div class="grow small muted">اطلاعات شما به هیچ سرویسی وصل نمی‌شود. تنها تماس اینترنتی برنامه، دریافت نرخ دلار است.</div></div>`),
    );
    return { tab: 'home', title: 'حساب HD', html: join(body) };
  }

  // موجودی کل
  const totals = Object.entries(d.totals);
  body.push(
    h`<section class="card hero"><div class="muted small">موجودی کل</div>${totals.map(([c, v]) => h`<div class="big num">${money(c, v)}</div>`)}<div class="muted small" style="margin-top:6px">${fa(d.accounts.length)} حساب فعال</div></section>`,
  );

  body.push(pendingNotice(ctx), backupReminder(ctx));

  // خلاصه‌ی امروز/هفته/ماه (تومان)
  const t = d.byCurrency.IRT;
  const row = (label, s) => h`<span class="muted small">${label}</span><b class="num pos">+${money('IRT', s.income, { withUnit: false })}</b><b class="num neg">−${money('IRT', s.expense, { withUnit: false })}</b>`;
  body.push(card(h`<div class="sumtable"><span></span><span class="muted small">درآمد</span><span class="muted small">هزینه</span>${row('امروز', t.today)}${row('این هفته', t.week)}${row('این ماه', t.month)}</div><div class="hint">مبالغ به تومان؛ انتقال بین حساب‌ها و پرداخت بدهی جزو درآمد/هزینه نیست.</div>`, { title: 'درآمد و هزینه' }));

  // بودجه
  if (d.budgets.length) {
    body.push(
      card(
        join(
          d.budgets.slice(0, 3).map(
            (b) => h`<div style="margin-bottom:12px"><div class="row between"><b>${b.title}</b><span class="small ${b.level === 'exceeded' ? 'neg' : 'muted'}">${b.level === 'exceeded' ? `${money('IRT', b.overBy)} بیشتر از سقف` : `${money('IRT', b.remaining)} مانده`}</span></div>${progress(b.usedBp, b.level, b.title)}<div class="small muted">${percentText(b.usedBp)} از ${money('IRT', b.limit)}</div></div>`,
          ),
        ),
        { title: 'بودجه', action: { href: '#/budgets', label: 'همه' } },
      ),
    );
  }

  // روند ۶ ماه
  if (d.trend.rows?.some((r) => r.hasData)) {
    body.push(card(bc(d.trend.rows.map((r) => ({ label: J.MONTH_NAMES[r.jm - 1], income: r.income, expense: r.expense }))), { title: 'روند ۶ ماه اخیر', action: { href: '#/reports', label: 'گزارش‌ها' } }));
  }

  // حساب‌ها
  body.push(
    card(
      h`<div class="list">${d.accounts.map((x) => h`<a class="item" href="#/accounts/${x.account.id}"><span class="badge">${x.account.type === 'bank' ? '🏦' : x.account.type === 'wallet' ? '👛' : x.account.type === 'fx' ? '💵' : '💰'}</span><span class="grow t">${x.account.name}</span><span class="amt num ${x.balance < 0 ? 'neg' : ''}">${money(x.account.currency, x.balance)}</span></a>`)}</div>`,
      { title: 'حساب‌ها', action: { href: '#/accounts', label: 'مدیریت' } },
    ),
  );

  // آخرین تراکنش‌ها
  body.push(
    card(
      d.recent.length ? h`<div class="list">${d.recent.map((tx) => txItem(state, tx, { today, showDate: true }))}</div>` : emptyState({ emoji: '🧾', title: 'هنوز تراکنشی ثبت نشده', text: 'اولین درآمد یا هزینه‌تان را ثبت کنید.', action: { href: '#/add', label: 'ثبت تراکنش' } }),
      { title: 'آخرین تراکنش‌ها', action: d.recent.length ? { href: '#/transactions', label: 'همه' } : null },
    ),
  );

  // بدهی‌ها و اهداف
  const owe = Object.entries(d.debts.owe).filter(([, v]) => v > 0);
  const owed = Object.entries(d.debts.owed).filter(([, v]) => v > 0);
  if (owe.length || owed.length || d.debts.overdue.length) {
    body.push(
      card(
        h`${owe.map(([c, v]) => h`<div class="kv"><span>بدهی من</span><b class="num neg">${money(c, v)}</b></div>`)}${owed.map(([c, v]) => h`<div class="kv"><span>طلب من</span><b class="num pos">${money(c, v)}</b></div>`)}${d.debts.overdue.length ? h`<div class="notice warn" style="margin-top:6px">${icon('warn', { size: 20 })}<div>${fa(d.debts.overdue.length)} مورد سررسیدگذشته دارید.</div></div>` : ''}`,
        { title: 'بدهی و طلب', action: { href: '#/debts', label: 'مشاهده' } },
      ),
    );
  }
  if (d.goals.length) {
    body.push(
      card(
        join(d.goals.slice(0, 3).map((g) => h`<div style="margin-bottom:12px"><div class="row between"><b>${g.goal.name}</b><span class="small muted">${percentText(g.progressBp)}</span></div>${progress(g.progressBp, 'ok', g.goal.name)}<div class="small muted">${money(g.goal.currency, g.saved)} از ${money(g.goal.currency, g.goal.targetAmount)}</div></div>`)),
        { title: 'اهداف پس‌انداز', action: { href: '#/goals', label: 'مشاهده' } },
      ),
    );
  }
  return { tab: 'home', title: 'حساب HD', html: join(body) };
}
