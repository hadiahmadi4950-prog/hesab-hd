import { h, join, raw, icon, fa, money, card, emptyState, notice } from './common.js';
import { fmtTime } from './transactions.js';
import * as M from '../../core/money.js';

export const BACKUP_REMINDER_DAYS = 7;

export function daysSince(iso, nowMs) {
  const t = Date.parse(iso ?? '');
  return Number.isFinite(t) ? Math.floor((nowMs - t) / 86400000) : null;
}

export function backupReminder(ctx) {
  const { state, prefs, nowMs } = ctx;
  if (state.transactions.length === 0 && state.accounts.length === 0) return '';
  const d = daysSince(prefs.lastBackupAt, nowMs);
  if (d === null) return notice(h`هنوز از اطلاعاتتان پشتیبان نگرفته‌اید. اطلاعات فقط روی همین دستگاه است؛ <a class="link" href="#/backup">همین حالا پشتیبان بگیرید</a>.`, 'warn');
  if (d >= BACKUP_REMINDER_DAYS) return notice(h`${fa(d)} روز از آخرین پشتیبان گذشته. <a class="link" href="#/backup">پشتیبان تازه بگیرید</a>.`, 'warn');
  return '';
}

export function summaryRows(s) {
  return h`<div class="kv"><span class="muted">حساب</span><span class="num">${fa(s.accounts)}</span></div><div class="kv"><span class="muted">تراکنش</span><span class="num">${fa(s.transactions)}</span></div><div class="kv"><span class="muted">دسته</span><span class="num">${fa(s.categories)}</span></div><div class="kv"><span class="muted">بدهی/طلب</span><span class="num">${fa(s.debts)}</span></div><div class="kv"><span class="muted">هدف</span><span class="num">${fa(s.goals)}</span></div><div class="kv"><span class="muted">بودجه</span><span class="num">${fa(s.budgets)}</span></div>${s.dateRange ? h`<div class="kv"><span class="muted">بازه‌ی تراکنش‌ها</span><span class="num">${fa(s.dateRange.from)} تا ${fa(s.dateRange.to)}</span></div>` : ''}`;
}

export function backupView(ctx) {
  const { state, prefs } = ctx;
  const has = state.accounts.length + state.transactions.length > 0;
  const html = join([
    backupReminder(ctx),
    card(
      h`<p class="small muted">همه‌ی اطلاعات فقط روی همین دستگاه است. فایل پشتیبان را جایی امن (حافظه‌ی گوشی، ایمیل به خودتان، فلش) نگه دارید. اگر دستگاه گم شود یا داده‌های مرورگر پاک شود، فقط با همین فایل برمی‌گردد.</p>${prefs.lastBackupAt ? h`<div class="kv"><span class="muted">آخرین پشتیبان</span><span class="num">${fmtTime(prefs.lastBackupAt)}</span></div>` : ''}<div class="actions"><button class="btn primary" data-action="download-backup" ${has ? '' : raw('disabled')}>${icon('download')} دانلود پشتیبان کامل (JSON)</button></div>`,
      { title: 'پشتیبان‌گیری' },
    ),
    card(
      h`<p class="small muted">برای باز کردن در اکسل یا شیت‌های گوگل (فارسی درست نمایش داده می‌شود). این خروجی برای مرور است و برای بازیابی استفاده نمی‌شود.</p><div class="actions two"><button class="btn" data-action="download-csv" data-kind="transactions" ${state.transactions.length ? '' : raw('disabled')}>CSV تراکنش‌ها</button><button class="btn" data-action="download-csv" data-kind="accounts" ${state.accounts.length ? '' : raw('disabled')}>CSV حساب‌ها</button></div>`,
      { title: 'خروجی برای اکسل' },
    ),
    card(
      h`<p class="small muted">فایل پشتیبان «حساب HD» را انتخاب کنید. قبل از هر تغییری، محتوای فایل بررسی و خلاصه‌اش نشان داده می‌شود؛ هیچ‌چیز بدون تأیید شما عوض نمی‌شود.</p><div class="field"><label for="restorefile">فایل پشتیبان (.json)</label><input type="file" id="restorefile" accept=".json,application/json" data-file-action="import-file"></div><div id="import-result" aria-live="polite"></div>`,
      { title: 'بازیابی از فایل' },
    ),
    card(h`<p class="small muted">همه‌ی حساب‌ها، تراکنش‌ها و تنظیمات داده را از این دستگاه پاک می‌کند. قبل از پاک‌کردن، یک پشتیبان خودکار دانلود می‌شود.</p><div class="actions"><button class="btn danger" data-action="ask-wipe" ${has ? '' : raw('disabled')}>${icon('trash')} پاک‌کردن همه‌ی اطلاعات</button></div>`, { title: 'پاک‌کردن اطلاعات' }),
  ]);
  return { tab: 'more', title: 'پشتیبان‌گیری', back: '#/more', html };
}

// پیش‌نمایش پس از انتخاب فایل (در پنجره‌ی پایینی)
export function importPreviewHtml({ meta, preview, fileName }) {
  const m = preview.merge;
  return h`<h2>بررسی فایل پشتیبان</h2><div class="notice"><div>فایل «${fileName}» سالم است${meta.exportedAt ? h` و در ${fmtTime(meta.exportedAt)} ساخته شده` : ''}.</div></div><div class="card" style="box-shadow:none"><b>محتوای فایل</b>${summaryRows(preview.incoming)}</div>${preview.currentHasData ? h`<div class="card" style="box-shadow:none"><b>اطلاعات فعلی این دستگاه</b>${summaryRows(preview.current)}</div>` : h`<p class="muted">این دستگاه هنوز اطلاعاتی ندارد.</p>`}${preview.currentHasData ? (m.ok ? h`<div class="notice"><div><b>ادغام:</b> ${fa(m.report.added.transactions)} تراکنش، ${fa(m.report.added.accounts)} حساب، ${fa(m.report.added.debts)} بدهی/طلب و ${fa(m.report.added.goals)} هدف جدید اضافه می‌شود. ${m.report.skippedExisting.transactions + m.report.skippedDuplicates ? `${fa(m.report.skippedExisting.transactions + m.report.skippedDuplicates)} تراکنش تکراری نادیده گرفته می‌شود. ` : ''}${m.report.renamed.length ? `${fa(m.report.renamed.length)} مورد هم‌نام با پسوند «(واردشده)» اضافه می‌شود. ` : ''}هیچ مورد موجودی پاک یا بازنویسی نمی‌شود.</div></div>` : notice(`ادغام ممکن نیست: ${m.error}`, 'error')) : ''}<div class="actions">${preview.currentHasData ? h`<button class="btn primary" data-action="sheet-yes" data-choice="merge" ${m.ok ? '' : raw('disabled')}>ادغام با اطلاعات فعلی</button><button class="btn danger" data-action="sheet-yes" data-choice="replace">جایگزینی کامل (پاک‌شدن اطلاعات فعلی)</button>` : h`<button class="btn primary" data-action="sheet-yes" data-choice="replace">بازیابی اطلاعات</button>`}<button class="btn" data-action="sheet-no">انصراف</button></div>`;
}

// داده‌ی ذخیره‌شده خراب است و نسخه‌ی قبلی هم سالم نبود
export function corruptView() {
  return {
    tab: 'home',
    title: 'اطلاعات ذخیره‌شده خراب است',
    tabs: false,
    html: join([
      notice('اطلاعات ذخیره‌شده روی این دستگاه ناقص یا خراب است و نسخه‌ی قبلی سالمی هم پیدا نشد. برای جلوگیری از از دست رفتن بیشتر، هیچ‌چیز بازنویسی نشده است. یکی از راه‌های زیر را انتخاب کنید.', 'error'),
      card(h`<p class="small muted">نسخه‌ی خراب را نگه داشته‌ایم. می‌توانید آن را دانلود کنید تا با کمک یک فرد فنی بررسی شود.</p><div class="actions"><button class="btn" data-action="download-corrupt">دانلود نسخه‌ی خراب</button></div>`, { title: '۱) نگه‌داشتن برای بررسی' }),
      card(h`<p class="small muted">اگر فایل پشتیبان دارید، آن را انتخاب کنید.</p><div class="field"><label for="restorefile2">فایل پشتیبان (.json)</label><input type="file" id="restorefile2" accept=".json,application/json" data-file-action="corrupt-restore"></div><div id="import-result" aria-live="polite"></div>`, { title: '۲) بازیابی از فایل پشتیبان' }),
      card(h`<p class="small muted">با اطلاعات خالی شروع می‌کنید. توصیه می‌شود ابتدا نسخه‌ی خراب را دانلود کنید.</p><div class="actions"><button class="btn danger" data-action="corrupt-fresh">شروع از نو</button></div>`, { title: '۳) شروع از نو' }),
    ]),
  };
}
