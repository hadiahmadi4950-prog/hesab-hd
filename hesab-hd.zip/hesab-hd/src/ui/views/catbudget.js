import { h, join, raw, icon, fa, money, card, emptyState, notice, progress, percentText } from './common.js';
import { byId } from './common.js';
import { field, textInput, amountInput, select, segmented, formErrors } from '../components.js';
import * as L from '../../core/ledger.js';
import * as M from '../../core/money.js';
import { budgetStatuses } from '../../core/reports.js';

export const EMOJIS = ['🍽️', '☕', '🛒', '🚌', '🚕', '⛽', '💡', '📱', '🏠', '💊', '🏥', '📚', '🎓', '🎬', '🎮', '👕', '👟', '🎁', '✈️', '🧾', '💼', '💰', '🏪', '📈', '🔧', '🐾', '👶', '💇', '🏋️', '🍔', '🥦', '🧴', '🎉', '📦', '➕', '🏷️', '🚗', '🕌', '💳', '🧹'];
export const COLORS = ['#ef6c3c', '#3b82c4', '#e0a800', '#7c5cbf', '#d6455d', '#2f9e8f', '#c75fa5', '#5c7cfa', '#8d6e4e', '#e8590c', '#2f9e44', '#0c8599', '#5f3dc4', '#868e96'];
const safeColor = (c) => (/^#[0-9a-fA-F]{6}$/.test(c) ? c : '#868e96');

// ---------- دسته‌ها ----------

export function categoriesView(ctx) {
  const { state } = ctx;
  const sect = (kind, title) => {
    const list = state.categories.filter((c) => c.kind === kind);
    return card(
      h`<div class="list">${list.map((c) => h`<a class="item" href="#/categories/${c.id}/edit"><span class="badge" style="background:${safeColor(c.color)}22">${c.icon}</span><span class="grow"><span class="t">${c.name}</span><br><span class="s">${fa(L.categoryUsage(state, c.id))} تراکنش</span></span>${icon('edit', { size: 18 })}</a>`)}</div><div class="actions"><a class="btn" href="#/categories/new?kind=${kind}">${icon('plus')} دسته‌ی جدید</a></div>`,
      { title },
    );
  };
  return { tab: 'more', title: 'دسته‌بندی‌ها', back: '#/more', html: join([sect('expense', 'دسته‌های هزینه'), sect('income', 'دسته‌های درآمد')]) };
}

export function categoryFormView(ctx, { id = null, values = null, errors = [] } = {}) {
  const { state, query } = ctx;
  const edit = Boolean(id);
  const old = edit ? byId(state.categories, id) : null;
  if (edit && !old) return { tab: 'more', title: 'دسته', back: '#/categories', html: card(emptyState({ emoji: '🤷', title: 'دسته پیدا نشد' })) };
  const v = values ?? (old ? { name: old.name, kind: old.kind, icon: old.icon, color: old.color } : { name: '', kind: query?.kind === 'income' ? 'income' : 'expense', icon: '🏷️', color: COLORS[5] });
  const fe = (f) => errors.filter((e) => e.field === f).map((e) => e.message).join(' ');
  const html = h`<form data-action="${edit ? 'save-category-edit' : 'save-category'}" ${edit ? raw(`data-id="${id}"`) : ''} novalidate>${formErrors(errors.filter((e) => !['name', 'kind', 'icon', 'color'].includes(e.field)))}<div class="card" style="display:grid;gap:14px">${edit ? h`<input type="hidden" name="kind" value="${v.kind}"><div class="notice"><div>${v.kind === 'income' ? 'دسته‌ی درآمد' : 'دسته‌ی هزینه'}${old.builtin ? ' (پیش‌فرض؛ قابل ویرایش و حذف است)' : ''}</div></div>` : field('نوع', segmented('kind', [{ value: 'expense', label: 'هزینه', cls: 'exp' }, { value: 'income', label: 'درآمد', cls: 'inc' }], v.kind))}${field('نام', textInput('name', v.name, { maxlength: 40, placeholder: 'مثلاً قهوه' }), { id: 'name', error: fe('name') })}${field('آیکون', h`<input type="text" id="icon" name="icon" value="${v.icon}" maxlength="8" style="max-width:6rem;text-align:center;font-size:1.6rem"><div class="emoji-grid">${EMOJIS.map((e) => h`<button type="button" class="emoji" data-action="pick-icon" data-v="${e}" aria-label="آیکون ${e}">${e}</button>`)}</div>`, { id: 'icon', error: fe('icon'), hint: 'یکی را بزنید یا خودتان یک اموجی بنویسید.' })}${field('رنگ', h`<div class="swatches" role="radiogroup" aria-label="رنگ">${COLORS.map((c) => h`<label class="swatch"><input type="radio" name="color" value="${c}" ${c.toLowerCase() === String(v.color).toLowerCase() ? raw('checked') : ''}><span style="background:${c}"></span></label>`)}</div>`, { error: fe('color') })}</div><div class="actions"><button class="btn primary block" type="submit">${edit ? 'ذخیره' : 'ساخت دسته'}</button>${edit ? h`<button class="btn danger" type="button" data-action="ask-delete-category" data-id="${id}">${icon('trash')} حذف دسته</button>` : ''}</div></form>`;
  return { tab: 'more', title: edit ? 'ویرایش دسته' : 'دسته‌ی جدید', back: '#/categories', html };
}

// ---------- بودجه ----------

const PERIOD_LABEL = { daily: 'روزانه', weekly: 'هفتگی (از شنبه)', monthly: 'ماهانه' };

export function budgetsView(ctx) {
  const { state, today } = ctx;
  const list = budgetStatuses(state, today);
  const parts = [];
  if (list.length === 0) parts.push(card(emptyState({ emoji: '📊', title: 'بودجه‌ای تعریف نشده', text: 'برای کل هزینه‌ها یا هر دسته سقف بگذارید تا هنگام نزدیک‌شدن به سقف هشدار بگیرید.', action: { href: '#/budgets/new', label: 'ساخت بودجه' } })));
  else {
    parts.push(
      card(
        join(
          list.map(
            (b) => h`<a class="item" href="#/budgets/${b.budget.id}/edit" style="display:block"><div class="row between"><b>${b.title} <span class="tag">${PERIOD_LABEL[b.budget.period].split(' ')[0]}</span></b><span class="small ${b.level === 'exceeded' ? 'neg' : b.level === 'warning' ? '' : 'muted'}">${b.level === 'exceeded' ? `${money('IRT', b.overBy)} بیشتر از سقف` : `${money('IRT', b.remaining)} مانده`}</span></div>${progress(b.usedBp, b.level, b.title)}<div class="small muted">${money('IRT', b.spent)} از ${money('IRT', b.limit)} (${percentText(b.usedBp)})${b.level === 'warning' ? ' · نزدیک سقف' : ''}${b.level === 'exceeded' ? ' · از سقف گذشته' : ''}</div></a>`,
          ),
        ),
      ),
      h`<div class="actions"><a class="btn primary" href="#/budgets/new">${icon('plus')} بودجه‌ی جدید</a></div>`,
    );
  }
  return { tab: 'more', title: 'بودجه', back: '#/more', html: join(parts) };
}

export function budgetFormView(ctx, { id = null, values = null, errors = [] } = {}) {
  const { state, today } = ctx;
  const edit = Boolean(id);
  const old = edit ? byId(state.budgets, id) : null;
  if (edit && !old) return { tab: 'more', title: 'بودجه', back: '#/budgets', html: card(emptyState({ emoji: '🤷', title: 'بودجه پیدا نشد' })) };
  const v = values ?? (old ? { categoryId: old.categoryId ?? '', period: old.period, limit: String(old.limit), warn: String(Math.round(old.warnBp / 100)) } : { categoryId: '', period: 'monthly', limit: '', warn: '80' });
  const fe = (f) => errors.filter((e) => e.field === f).map((e) => e.message).join(' ');
  const cats = [{ value: '', label: 'کل هزینه‌ها' }, ...state.categories.filter((c) => c.kind === 'expense').map((c) => ({ value: c.id, label: `${c.icon} ${c.name}` }))];
  const html = h`<form data-action="save-budget" ${edit ? raw(`data-id="${id}"`) : ''} novalidate>${formErrors(errors.filter((e) => !['categoryId', 'period', 'limit', 'warnBp'].includes(e.field)))}<div class="card" style="display:grid;gap:14px">${field('برای کدام هزینه؟', edit ? h`<div class="notice"><div>${old.categoryId ? byId(state.categories, old.categoryId)?.name ?? 'دسته‌ی حذف‌شده' : 'کل هزینه‌ها'} — ${PERIOD_LABEL[old.period]}</div></div><input type="hidden" name="categoryId" value="${old.categoryId ?? ''}"><input type="hidden" name="period" value="${old.period}">` : select('categoryId', cats, v.categoryId), { id: 'categoryId', error: fe('categoryId') })}${edit ? '' : field('دوره', select('period', Object.entries(PERIOD_LABEL).map(([k, l]) => ({ value: k, label: l })), v.period), { id: 'period', error: fe('period') })}${field('سقف (تومان)', amountInput('limit', v.limit, { id: 'limit' }), { id: 'limit', error: fe('limit') })}${field('هشدار از', select('warn', [50, 60, 70, 80, 90, 100].map((n) => ({ value: n, label: `${fa(n)}٪ سقف` })), v.warn), { id: 'warn', error: fe('warnBp') })}${edit ? h`<div class="hint">تغییر سقف از امروز اعمال می‌شود؛ بودجه‌ی گذشته با سقف همان زمان سنجیده می‌ماند.</div>` : ''}</div><div class="actions"><button class="btn primary block" type="submit">${edit ? 'ذخیره‌ی سقف جدید' : 'ساخت بودجه'}</button>${edit ? h`<button class="btn danger" type="button" data-action="ask-delete-budget" data-id="${id}">${icon('trash')} حذف بودجه</button>` : ''}</div></form>`;
  return { tab: 'more', title: edit ? 'ویرایش بودجه' : 'بودجه‌ی جدید', back: '#/budgets', html };
}
