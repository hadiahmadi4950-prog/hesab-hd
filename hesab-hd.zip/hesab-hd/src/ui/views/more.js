import { h, join, raw, icon, fa, money, card, emptyState, notice } from './common.js';
import { byId, pendingNotice } from './common.js';
import { field, amountInput, segmented, textInput, formErrors } from '../components.js';
import { fmtTime } from './transactions.js';
import { isFresh } from '../../core/fx.js';
import * as M from '../../core/money.js';

export const APP_NAME = 'حساب HD';
export const APP_VERSION = '1.0.0';

const MENU = [
  ['accounts', '🏦', 'حساب‌ها', 'کیف پول، بانک، حساب ارزی'],
  ['categories', '🏷️', 'دسته‌بندی‌ها', 'ساخت و ویرایش دسته‌ها'],
  ['budgets', '📊', 'بودجه', 'سقف هزینه‌ی کل و هر دسته'],
  ['goals', '🎯', 'اهداف پس‌انداز', 'برای خرید یا هدف‌های آینده'],
  ['debts', '🤝', 'بدهی و طلب', 'پرداخت قسطی و سررسید'],
  ['rate', '💵', 'نرخ دلار', 'نرخ لحظه‌ای یا دستی'],
  ['backup', '💾', 'پشتیبان‌گیری', 'ذخیره و بازیابی اطلاعات'],
  ['settings', '⚙️', 'تنظیمات و قفل', 'ظاهر، قفل PIN، درباره‌ی برنامه'],
];

export function moreView(ctx) {
  return {
    tab: 'more',
    title: 'بیشتر',
    html: card(h`<div class="list">${MENU.map(([id, e, t, s]) => h`<a class="item" href="#/${id}"><span class="badge" aria-hidden="true">${e}</span><span class="grow"><span class="t">${t}</span><br><span class="s">${s}</span></span>${icon('back')}</a>`)}</div>`),
  };
}

// ---------- نرخ دلار ----------

export function rateView(ctx) {
  const { state, query: q, nowMs } = ctx;
  const fx = state.fx;
  const last = fx.lastRate;
  const fresh = last ? isFresh(last, nowMs, (fx.maxAgeMinutes ?? 30) * 60000) : false;
  const tx = q.tx ? byId(state.transactions, q.tx) : null;
  const pending = ctx.pendingCount;
  const errs = ctx.formErrors ?? [];
  const opts = [];
  if (tx) opts.push({ value: 'one', label: 'فقط این تراکنش' });
  if (pending) opts.push({ value: 'pending', label: `${fa(pending)} تراکنش در انتظار` });
  opts.push({ value: 'all', label: 'همه‌ی تراکنش‌های تومانی (محاسبه‌ی دوباره)' });
  const html = join([
    card(
      last
        ? h`<div class="kv"><span>آخرین نرخ ثبت‌شده</span><b class="num">${money('IRT', last.value)}</b></div><div class="kv"><span>زمان</span><span class="num">${fmtTime(last.at)}</span></div><div class="kv"><span>منبع</span><span>${last.source}${last.manual ? ' (دستی)' : ''}</span></div>${fresh ? h`<span class="tag ok">تازه (کمتر از ${fa(fx.maxAgeMinutes ?? 30)} دقیقه)</span>` : h`<span class="tag pend">قدیمی</span>`}`
        : h`<p class="muted">هنوز نرخی دریافت یا وارد نشده است.</p>`,
      { title: 'نرخ دلار آزاد' },
    ),
    fx.lastError ? notice(h`آخرین تلاش برای دریافت نرخ ناموفق بود: ${fx.lastError.message}`, 'warn') : '',
    pendingNotice(ctx),
    card(
      h`<p class="small muted">برنامه نرخ را از اینترنت می‌گیرد (تنها تماس اینترنتی برنامه). اگر اینترنت نبود یا منبع کار نکرد، خودتان نرخ را وارد کنید. دلار هر تراکنش با نرخ <b>لحظه‌ی محاسبه</b> ساخته می‌شود، نه نرخ روز تراکنش؛ نرخ و زمان آن کنار تراکنش می‌ماند.</p><div class="actions"><button class="btn primary" data-action="sync-rate" ${ctx.online ? '' : raw('disabled')}>${icon('cloud')} دریافت نرخ لحظه‌ای از اینترنت</button>${ctx.online ? '' : h`<div class="hint">اینترنت وصل نیست؛ بعد از اتصال خودکار انجام می‌شود.</div>`}</div>`,
      { title: 'دریافت خودکار' },
    ),
    card(
      h`<form data-action="manual-rate" novalidate>${formErrors(errs.filter((e) => !e.field))}${field('نرخ هر ۱ دلار (تومان)', amountInput('rate', ctx.values?.rate ?? '', { id: 'rate', currency: 'IRT' }), { id: 'rate', error: errs.find((e) => e.field === 'rate')?.message, hint: 'همان عددی که الان قیمت یک دلار است (به تومان).' })}${field('اعمال روی', segmented('scope', opts, ctx.values?.scope ?? (tx ? 'one' : pending ? 'pending' : 'all')))}${tx ? h`<input type="hidden" name="txId" value="${tx.id}">` : ''}<button class="btn primary" type="submit">اعمال نرخ دستی</button></form>`,
      { title: 'نرخ دستی' },
    ),
  ]);
  return { tab: 'more', title: 'نرخ دلار', back: '#/more', html };
}

// ---------- تنظیمات ----------

export function settingsView(ctx) {
  const { prefs } = ctx;
  const hasPin = Boolean(prefs.pin);
  const html = join([
    card(h`<form data-action="save-theme" data-autosubmit>${field('ظاهر برنامه', segmented('theme', [{ value: 'auto', label: 'خودکار' }, { value: 'light', label: 'روشن' }, { value: 'dark', label: 'تاریک' }], prefs.theme))}</form>`, { title: 'ظاهر' }),
    card(
      hasPin
        ? h`<p>قفل PIN فعال است.</p><div class="actions"><button class="btn" data-action="open-pin-form" data-mode="change">تغییر PIN</button><button class="btn danger" data-action="open-pin-form" data-mode="remove">برداشتن قفل</button></div>`
        : h`<p class="muted">برنامه را با یک PIN چهار تا هشت رقمی قفل کنید.</p><div class="actions"><button class="btn primary" data-action="open-pin-form" data-mode="set">${icon('lock')} فعال‌سازی قفل PIN</button></div>`,
      { title: 'قفل برنامه' },
    ),
    notice('قفل PIN فقط صفحه‌ی برنامه را می‌پوشاند و جلوی دیدن اطلاعات توسط اطرافیان را می‌گیرد. اطلاعات روی دستگاه رمزنگاری نمی‌شود؛ اگر کسی به فایل‌های مرورگر یا دستگاه دسترسی فنی داشته باشد، می‌تواند آن را بخواند. اگر PIN را فراموش کنید، راه بازیابی ندارد مگر پاک‌کردن داده‌های سایت (که اطلاعات را هم پاک می‌کند) و بازیابی از فایل پشتیبان. پس مرتب پشتیبان بگیرید.', 'warn'),
    card(
      h`<div class="kv"><span>فضای ذخیره‌سازی</span><span class="num">${ctx.storageInfo ?? '—'}</span></div><div class="kv"><span>ماندگاری داده</span><span>${ctx.persisted === true ? 'تضمین‌شده توسط مرورگر' : ctx.persisted === false ? 'تضمین نشده' : 'نامشخص'}</span></div>${ctx.persisted === false ? h`<div class="actions"><button class="btn" data-action="request-persist">درخواست ماندگاری از مرورگر</button></div>` : ''}<div class="hint">مرورگر ممکن است در کمبود فضا داده‌ی سایت‌ها را پاک کند، مگر ماندگاری فعال باشد. در هر حال پشتیبان بگیرید.</div>`,
      { title: 'ذخیره‌سازی' },
    ),
    card(
      h`<div class="kv"><span>نسخه</span><span class="num">${fa(APP_VERSION)}</span></div><p class="small muted">همه‌ی اطلاعات فقط روی همین دستگاه ذخیره می‌شود. هیچ حسابی به بانک یا سرویس دیگری وصل نمی‌شود. تنها تماس اینترنتی برنامه، دریافت نرخ دلار است. فونت وزیرمتن با مجوز SIL OFL.</p>`,
      { title: 'درباره‌ی حساب HD' },
    ),
  ]);
  return { tab: 'more', title: 'تنظیمات و قفل', back: '#/more', html };
}
