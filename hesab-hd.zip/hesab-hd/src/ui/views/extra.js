// نگاشت مسیرهای ثانویه (دسته‌ها، بودجه، اهداف، بدهی، گزارش‌ها، پشتیبان)
import { categoriesView, categoryFormView, budgetsView, budgetFormView } from './catbudget.js';
import { goalsView, goalFormView, goalDetailView, debtsView, debtFormView, debtDetailView } from './goaldebt.js';

import { reportsView } from './reports.js';

export function resolveExtra(parts, ctx) {
  const [a, b, c] = parts;
  const f = ctx.form ?? {};
  const fv = { values: f.values, errors: f.errors ?? [] };
  switch (a) {
    case 'categories':
      if (b === 'new') return categoryFormView(ctx, fv);
      if (b && c === 'edit') return categoryFormView(ctx, { id: b, ...fv });
      return categoriesView(ctx);
    case 'budgets':
      if (b === 'new') return budgetFormView(ctx, fv);
      if (b && c === 'edit') return budgetFormView(ctx, { id: b, ...fv });
      return budgetsView(ctx);
    case 'goals':
      if (b === 'new') return goalFormView(ctx, fv);
      if (b && c === 'edit') return goalFormView(ctx, { id: b, ...fv });
      if (b) return goalDetailView(ctx, b);
      return goalsView(ctx);
    case 'debts':
      if (b === 'new') return debtFormView(ctx, fv);
      if (b && c === 'edit') return debtFormView(ctx, { id: b, ...fv });
      if (b) return debtDetailView(ctx, b);
      return debtsView(ctx);
    case 'reports':
      return reportsView(ctx);
    default:
      return null;
  }
}
