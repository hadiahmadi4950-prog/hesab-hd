import { h, join, raw, icon, fa, money, card, emptyState, notice } from './common.js';
import { txItem, byId } from './common.js';
import { field, textInput, amountInput, select, formErrors } from '../components.js';
import * as L from '../../core/ledger.js';
import * as M from '../../core/money.js';

export const ACCOUNT_EMOJI = { cash: '💰', bank: '🏦', wallet: '👛', fx: '💵' };

export function accountsView(ctx) {
  const { state } = ctx;
  const balances = L.accountBalances(state);
  const active = balances.filter((x) => !x.account.archived);
  const archived = balances.filter((x) => x.account.archived);
  const row = (x) => h`<a class="item" href="#/accounts/${x.account.id}"><span class="badge">${ACCOUNT_EMOJI[x.account.type]}</span><span class="grow"><span class="t">${x.account.name}</span><br><span class="s">${L.ACCOUNT_TYPE_LABELS[x.account.type]} · ${M.CURRENCIES[x.account.currency].name}</span></span><span class="amt num ${x.balance < 0 ? 'neg' : ''}">${money(x.account.currency, x.balance)}</span></a>`;
  const parts = [];
  if (active.length === 0) parts.push(card(emptyState({ emoji: '🏦', title: 'هنوز حسابی ندارید', text: 'برای هر جایی که پول نگه می‌دارید یک حساب بسازید: کیف پول، حساب بانکی، حساب ارزی…', action: { href: '#/accounts/new', label: 'افزودن حساب' } })));
  else parts.push(card(h`<div class="list">${active.map(row)}</div>`), h`<div class="actions"><a class="btn primary" href="#/accounts/new">${icon('plus')} حساب جدید</a></div>`);
  if (archived.length) parts.push(card(h`<div class="list">${archived.map(row)}</div>`, { title: 'بایگانی‌شده' }));
  return { tab: 'more', title: 'حساب‌ها', back: '#/more', html: join(parts) };
}

export function accountDetailView(ctx, id) {
  const { state, today } = ctx;
  const a = byId(state.accounts, id);
  if (!a) return { tab: 'more', title: 'حساب', back: '#/accounts', html: card(emptyState({ emoji: '🤷', title: 'حساب پیدا نشد', action: { href: '#/accounts', label: 'بازگشت' } })) };
  const bal = L.accountBalance(state, id);
  const txs = L.queryTransactions(state, { accountId: id }).slice(0, 15);
  const used = L.accountInUse(state, id);
  const rec = ctx.ui?.reconcile?.id === id ? ctx.ui.reconcile.result : null;
  const html = join([
    h`<section class="card hero"><div class="muted small">${a.name} · ${L.ACCOUNT_TYPE_LABELS[a.type]}${a.archived ? ' · بایگانی‌شده' : ''}</div><div class="big num">${money(a.currency, bal)}</div><div class="muted small">موجودی اولیه: ${money(a.currency, a.openingBalance)}</div></section>`,
    card(
      h`<form data-action="reconcile" data-id="${id}">${field('موجودی واقعی که الان دارید', amountInput('actual', '', { currency: a.currency, id: 'actual' }), { hint: 'برای مقایسه با موجودی محاسبه‌شده‌ی برنامه (مثلاً بعد از شمردن پول نقد یا دیدن موجودی بانک).' })}<button class="btn" type="submit">مقایسه</button></form>${rec ? (rec.status === 'match' ? notice('موجودی برنامه با موجودی واقعی برابر است. ✅', 'info') : notice(h`اختلاف: <b class="num">${money(a.currency, Math.abs(rec.difference))}</b> ${rec.difference > 0 ? 'پول بیشتری دارید' : 'پول کمتری دارید'} نسبت به محاسبه‌ی برنامه. تراکنش فراموش‌شده را ثبت کنید یا موجودی اولیه را اصلاح کنید.`, 'warn')) : ''}`,
      { title: 'مغایرت‌گیری' },
    ),
    card(txs.length ? h`<div class="list">${txs.map((t) => txItem(state, t, { today, showDate: true }))}</div>` : emptyState({ emoji: '🧾', title: 'تراکنشی در این حساب نیست' }), { title: 'آخرین تراکنش‌ها', action: txs.length ? { href: `#/transactions?acc=${id}&range=all`, label: 'همه' } : null }),
    h`<div class="actions two"><a class="btn" href="#/accounts/${id}/edit">${icon('edit')} ویرایش</a>${a.archived ? h`<button class="btn" data-action="unarchive-account" data-id="${id}">بازگرداندن از بایگانی</button>` : h`<button class="btn" data-action="archive-account" data-id="${id}">بایگانی</button>`}</div>${used ? h`<div class="hint">این حساب تراکنش دارد، پس حذف نمی‌شود؛ فقط بایگانی می‌شود.</div>` : h`<div class="actions"><button class="btn danger" data-action="ask-delete-account" data-id="${id}">${icon('trash')} حذف حساب</button></div>`}`,
  ]);
  return { tab: 'more', title: a.name, back: '#/accounts', html };
}

export function accountFormView(ctx, { id = null, values = null, errors = [] } = {}) {
  const { state } = ctx;
  const edit = Boolean(id);
  const old = edit ? byId(state.accounts, id) : null;
  if (edit && !old) return { tab: 'more', title: 'حساب', back: '#/accounts', html: card(emptyState({ emoji: '🤷', title: 'حساب پیدا نشد' })) };
  const v = values ?? (old ? { name: old.name, type: old.type, currency: old.currency, openingBalance: M.toEditableString(old.currency, old.openingBalance) } : { name: '', type: 'cash', currency: 'IRT', openingBalance: '' });
  const fe = (f) => errors.filter((e) => e.field === f).map((e) => e.message).join(' ');
  const locked = edit && L.accountInUse(state, id);
  const html = h`<form data-action="${edit ? 'save-account-edit' : 'save-account'}" ${edit ? raw(`data-id="${id}"`) : ''} novalidate>${formErrors(errors.filter((e) => !['name', 'type', 'currency', 'openingBalance'].includes(e.field)))}<div class="card" style="display:grid;gap:14px">${field('نام حساب', textInput('name', v.name, { placeholder: 'مثلاً کیف پول، بانک ملی', maxlength: 40 }), { id: 'name', error: fe('name') })}${field('نوع حساب', select('type', Object.entries(L.ACCOUNT_TYPE_LABELS).map(([k, l]) => ({ value: k, label: l })), v.type), { id: 'type', error: fe('type') })}${field('واحد پول', h`<div data-rerender>${select('currency', [{ value: 'IRT', label: 'تومان' }, { value: 'USD', label: 'دلار' }], v.currency, { attrs: locked ? 'disabled' : '' })}</div>${locked ? h`<input type="hidden" name="currency" value="${v.currency}">` : ''}`, { id: 'currency', error: fe('currency'), hint: locked ? 'واحد پول حسابی که تراکنش دارد قابل تغییر نیست.' : '' })}${field('موجودی فعلی (اولیه)', amountInput('openingBalance', v.openingBalance, { currency: v.currency }), { id: 'openingBalance', error: fe('openingBalance'), hint: edit ? 'تغییر موجودی اولیه، موجودی فعلی را به همان اندازه جابه‌جا می‌کند.' : 'پولی که همین الان در این حساب دارید. اگر صفر است خالی بگذارید. عدد را همان‌طور که می‌خوانید بنویسید (به تومان).' })}</div><div class="actions"><button class="btn primary block" type="submit">${edit ? 'ذخیره' : 'ساخت حساب'}</button></div></form>`;
  return { tab: 'more', title: edit ? 'ویرایش حساب' : 'حساب جدید', back: edit ? `#/accounts/${id}` : '#/accounts', html };
}
