import { h, join, raw, icon, fa, money, card, emptyState, notice, percentText } from './common.js';
import { field, dateInput, barChart, lineChart, donut, compactAmount } from '../components.js';
import { rangeFor, qs, fmtTime } from './transactions.js';
import { summarize, series, balanceOverTime, monthComparison, usdReport } from '../../core/reports.js';
import * as M from '../../core/money.js';
import * as J from '../../core/jalali.js';
import * as L from '../../core/ledger.js';

const RANGES = [
  ['week', 'این هفته'],
  ['month', 'این ماه'],
  ['lastmonth', 'ماه قبل'],
  ['year', 'امسال'],
  ['all', 'همه'],
  ['custom', 'بازه‌ی دلخواه'],
];

export function reportRange(q, state, today) {
  const range = q.range ?? 'month';
  if (range === 'custom') {
    const from = J.isValidDateString?.(q.from) ? q.from : today;
    let to = J.isValidDateString?.(q.to) ? q.to : today;
    if (J.compareDates(from, to) > 0) to = from;
    return { range, from, to };
  }
  if (range === 'all') {
    const dates = state.transactions.map((t) => t.date).sort();
    const first = dates[0] ?? today;
    const last = dates[dates.length - 1] ?? today;
    return { range, from: first, to: last > today ? last : today };
  }
  return { range, ...rangeFor(range, today) };
}

function granularityFor(from, to) {
  const days = J.diffDays(to, from) + 1;
  if (days <= 10) return 'day';
  if (days <= 62) return 'week';
  if (days <= 800) return 'month';
  return 'year';
}

function bucketLabel(b, g) {
  const p = J.parseDate(b.from);
  if (g === 'day') return fa(p.jd);
  if (g === 'week') return `${fa(p.jd)} ${J.MONTH_NAMES[p.jm - 1]}`;
  if (g === 'month') return J.MONTH_NAMES[p.jm - 1];
  return fa(p.jy);
}

export function reportsView(ctx) {
  const { state, today, query: q } = ctx;
  const { range, from, to } = reportRange(q, state, today);
  const cur = q.cur === 'USD' && state.accounts.some((a) => a.currency === 'USD') ? 'USD' : 'IRT';
  const hasUsd = state.accounts.some((a) => a.currency === 'USD');

  const chip = (key, val, label, on) => {
    const next = { ...q, [key]: val };
    if (key === 'range' && val !== 'custom') { delete next.from; delete next.to; }
    return h`<a class="chipbtn ${on ? 'on' : ''}" href="#/reports${qs(next)}">${label}</a>`;
  };

  const controls = card(
    h`<div class="chips">${RANGES.map(([k, l]) => chip('range', k === 'month' ? '' : k, l, range === k))}</div>${hasUsd ? h`<div class="chips" style="margin-top:8px">${chip('cur', '', 'تومان', cur === 'IRT')}${chip('cur', 'USD', 'دلار', cur === 'USD')}</div>` : ''}${range === 'custom' ? h`<form data-action="report-custom" style="margin-top:10px" novalidate><div class="field"><label>از تاریخ</label>${dateInput('from', from)}</div><div class="field"><label>تا تاریخ</label>${dateInput('to', to)}</div><button class="btn" type="submit">اعمال</button></form>` : ''}<div class="hint">${fa(J.formatLong(from))} تا ${fa(J.formatLong(to))}</div>`,
  );

  if (state.transactions.length === 0) {
    return { tab: 'reports', title: 'گزارش‌ها', html: join([controls, card(emptyState({ emoji: '📈', title: 'هنوز داده‌ای برای گزارش نیست', text: 'بعد از ثبت چند تراکنش، اینجا نمودار و تحلیل می‌بینید.', action: { href: '#/add', label: 'ثبت تراکنش' } }))]) };
  }

  const s = summarize(state, { from, to, currency: cur });
  const unit = M.CURRENCIES[cur].name;
  const g = granularityFor(from, to);
  const buckets = series(state, { from, to, currency: cur, granularity: g });
  const step = Math.ceil(buckets.length / 8);
  const rows = buckets.map((b, i) => ({ label: i % step === 0 || buckets.length <= 8 ? bucketLabel(b, g) : '', income: b.income, expense: b.expense }));

  const parts = [controls];
  parts.push(
    card(
      s.hasData
        ? h`<div class="kv"><span>درآمد</span><b class="num pos">${money(cur, s.income)}</b></div><div class="kv"><span>هزینه</span><b class="num neg">${money(cur, s.expense)}</b></div><div class="kv"><span>تراز (درآمد − هزینه)</span><b class="num ${s.net < 0 ? 'neg' : 'pos'}">${money(cur, s.net)}</b></div>${s.days ? h`<div class="kv"><span>میانگین هزینه‌ی روزانه</span><span class="num">${money(cur, s.avgDailyExpense)}</span></div>` : ''}<div class="kv"><span>تعداد تراکنش</span><span class="num">${fa(s.count)}</span></div>${s.debtPaidOut || s.debtReceived ? h`<div class="hint">پرداخت/دریافت بدهی (${s.debtPaidOut ? `پرداختی ${money(cur, s.debtPaidOut)}` : ''}${s.debtPaidOut && s.debtReceived ? '، ' : ''}${s.debtReceived ? `دریافتی ${money(cur, s.debtReceived)}` : ''}) جزو درآمد و هزینه نیست.</div>` : ''}${s.excludedTransfers ? h`<div class="hint">${fa(s.excludedTransfers)} انتقال بین حساب‌ها در جمع‌ها حساب نشده است.</div>` : ''}`
        : emptyState({ emoji: '🗓️', title: 'در این بازه تراکنشی نیست', text: 'بازه‌ی دیگری را انتخاب کنید.' }),
      { title: 'خلاصه' },
    ),
  );
  if (s.hasData) {
    parts.push(card(barChart(rows, { label: `درآمد و هزینه (${unit})`, unit }), { title: `درآمد و هزینه (${{ day: 'روزانه', week: 'هفتگی', month: 'ماهانه', year: 'سالانه' }[g]})` }));
    if (s.expenseByCategory.length) {
      parts.push(
        card(
          h`${donut(s.expenseByCategory.slice(0, 8), { label: 'سهم دسته‌های هزینه', centerText: compactAmount(s.expense) })}<div class="list">${s.expenseByCategory.map((c) => h`<a class="item" href="#/transactions${qs({ cat: c.categoryId, range: range === 'custom' ? 'all' : range === 'month' ? '' : range })}"><span class="badge" style="background:${/^#[0-9a-f]{6}$/i.test(c.color) ? c.color : '#868e96'}22">${c.icon}</span><span class="grow"><span class="t">${c.name}</span><br><span class="s">${fa(c.count)} تراکنش · ${percentText(c.shareBp)}</span></span><span class="amt num">${money(cur, c.total)}</span></a>`)}</div>`,
          { title: 'هزینه به تفکیک دسته' },
        ),
      );
    }
    if (s.incomeByCategory.length) {
      parts.push(card(h`<div class="list">${s.incomeByCategory.map((c) => h`<div class="item" style="cursor:default"><span class="badge">${c.icon}</span><span class="grow"><span class="t">${c.name}</span><br><span class="s">${fa(c.count)} تراکنش · ${percentText(c.shareBp)}</span></span><span class="amt num pos">${money(cur, c.total)}</span></div>`)}</div>`, { title: 'درآمد به تفکیک دسته' }));
    }
  }

  // روند موجودی
  const days = J.diffDays(to, from) + 1;
  if (state.accounts.some((a) => a.currency === cur) && days >= 2) {
    const all = balanceOverTime(state, { from, to, currency: cur });
    const stride = Math.max(1, Math.ceil(all.length / 60));
    const pts = all.filter((_, i) => i % stride === 0 || i === all.length - 1).map((p) => ({ label: fa(J.formatLong(p.date)), value: p.balance }));
    parts.push(card(h`${lineChart(pts, { label: `روند موجودی (${unit})` })}<div class="kv"><span class="muted">ابتدای بازه</span><span class="num">${money(cur, pts[0].value)}</span></div><div class="kv"><span class="muted">انتهای بازه</span><span class="num">${money(cur, pts[pts.length - 1].value)}</span></div>`, { title: 'روند موجودی' }));
  }

  // مقایسه‌ی ماه‌ها
  const p = J.parseDate(today);
  const mc = monthComparison(state, { jy: p.jy, jm: p.jm, months: 6, currency: cur });
  if (mc.rows.some((r) => r.hasData)) {
    const delta = mc.expenseDelta;
    parts.push(
      card(
        h`${barChart(mc.rows.map((r) => ({ label: J.MONTH_NAMES[r.jm - 1], income: r.income, expense: r.expense })), { label: 'مقایسه‌ی ماه‌ها', unit })}${delta !== null ? h`<p class="small">هزینه‌ی این ماه نسبت به ماه قبل ${delta === 0 ? 'تغییری نکرده' : h`<b class="${delta > 0 ? 'neg' : 'pos'}">${money(cur, Math.abs(delta))} ${delta > 0 ? 'بیشتر' : 'کمتر'}</b> شده`} است.</p>` : ''}`,
        { title: 'مقایسه‌ی ۶ ماه اخیر' },
      ),
    );
  }

  // دلار
  if (cur === 'IRT') {
    const u = usdReport(state, { from, to });
    if (u.doneCount || u.pendingCount) {
      parts.push(
        card(
          h`<div class="kv"><span>درآمد (دلاری)</span><b class="num pos">${M.formatUsd(u.incomeCents)}</b></div><div class="kv"><span>هزینه (دلاری)</span><b class="num neg">${M.formatUsd(u.expenseCents)}</b></div>${u.pendingCount ? notice(`${fa(u.pendingCount)} تراکنش (${money('IRT', u.pendingToman)}) هنوز معادل دلاری ندارد و در این جمع نیست.`, 'warn') : ''}${u.rates.length ? h`<details><summary class="link">نرخ‌های استفاده‌شده (${fa(u.rates.length)})</summary>${u.rates.map((r) => h`<div class="kv small"><span>${money('IRT', r.rate)} · ${r.source}${r.manual ? ' (دستی)' : ''}</span><span class="muted">${fa(r.count)} تراکنش · ${fmtTime(r.rateAt)}</span></div>`)}</details>` : ''}<div class="hint">هر تراکنش با نرخ لحظه‌ی محاسبه‌ی خودش به دلار تبدیل شده است؛ پس این جمع، ارزش «تقریبی» است نه نرخ روز تراکنش.</div>`,
          { title: 'معادل دلاری' },
        ),
      );
    }
  }
  return { tab: 'reports', title: 'گزارش‌ها', html: join(parts) };
}
