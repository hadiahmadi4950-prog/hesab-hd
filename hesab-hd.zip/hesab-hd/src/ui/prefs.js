// تنظیمات سبک دستگاه (نه داده‌ی مالی): پوسته، قفل PIN. در localStorage؛ اگر در دسترس نبود، فقط در حافظه.
const KEY = 'hesab-hd:prefs';
const DEFAULTS = { theme: 'auto', pin: null, lockAfterSec: 60, failCount: 0, lockedUntil: 0 };

export function createPrefs(storage = globalThis.localStorage) {
  let mem = { ...DEFAULTS };
  const read = () => {
    try {
      const raw = storage?.getItem(KEY);
      if (!raw) return { ...mem };
      const o = JSON.parse(raw);
      return { ...DEFAULTS, ...(o && typeof o === 'object' ? o : {}) };
    } catch {
      return { ...mem };
    }
  };
  const write = (o) => {
    mem = { ...o };
    try {
      storage?.setItem(KEY, JSON.stringify(o));
    } catch {
      /* حافظه در دسترس نیست؛ فقط تا پایان این نشست می‌ماند */
    }
  };
  return {
    get: () => read(),
    set(patch) {
      const next = { ...read(), ...patch };
      write(next);
      return next;
    },
  };
}
