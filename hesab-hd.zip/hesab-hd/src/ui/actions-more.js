// عملیات دسته‌ها، بودجه، اهداف، بدهی/طلب (و بعداً گزارش‌ها و پشتیبان)
import * as L from '../core/ledger.js';
import * as M from '../core/money.js';
import { h } from './dom.js';
import { select } from './components.js';

const blank = (s) => s === undefined || s === null || String(s).trim() === '';
const err = (field, message) => ({ field, message });
const uuid = () => globalThis.crypto.randomUUID();
const mk = (c) => ({ now: c.nowIso, id: uuid });

function money(currency, text, field, errors, opts) {
  const r = M.parseAmount(currency, text, opts);
  if (!r.ok) {
    errors.push(err(field, r.error));
    return null;
  }
  return r.value;
}
function optDate(v, field, errors) {
  if (blank(v)) return null;
  if (v === 'ناقص') {
    errors.push(err(field, 'تاریخ را کامل انتخاب کنید.'));
    return null;
  }
  return v;
}
function reqDate(v, field, errors) {
  if (blank(v) || v === 'ناقص') {
    errors.push(err(field, 'تاریخ را کامل انتخاب کنید.'));
    return null;
  }
  return v;
}

// اجرای عملیات فرم: خطاها در همان فرم نشان داده می‌شوند
async function formOp(c, v, errors, run, after) {
  if (errors.length) return c.setForm({ values: v, errors });
  try {
    const out = await c.commit(run);
    c.ui.form = null;
    after(out);
  } catch (e) {
    c.setForm({ values: v, errors: c.errorsFrom(e) });
  }
}

export const moreActions = {
  'report-custom'(c, form, ev, v) {
    if (!v.from || v.from === 'ناقص' || !v.to || v.to === 'ناقص') return c.toast('تاریخ‌ها را کامل انتخاب کنید.');
    c.win.location.hash = `#/reports?range=custom&from=${v.from}&to=${v.to}`;
  },
  // ----- دسته‌ها -----
  'pick-icon'(c, el) {
    const input = el.closest('form')?.elements?.icon;
    if (input) input.value = el.dataset.v;
  },
  'save-category': (c, form, ev, v) =>
    formOp(c, v, [], (s) => L.addCategory(s, { name: v.name, kind: v.kind, icon: v.icon?.trim() || '🏷️', color: v.color || '#868e96' }, mk(c)), () => {
      c.toast('دسته ساخته شد.');
      c.go(c.win.history.length > 1 && c.ui.returnTo ? c.ui.returnTo : '#/categories');
    }),
  'save-category-edit': (c, form, ev, v) =>
    formOp(c, v, [], (s) => L.updateCategory(s, form.dataset.id, { name: v.name, icon: v.icon?.trim() || '🏷️', color: v.color }), () => {
      c.toast('دسته ذخیره شد.');
      c.go('#/categories');
    }),
  async 'ask-delete-category'(c, el) {
    const id = el.dataset.id;
    const cat = c.state.categories.find((x) => x.id === id);
    const used = L.categoryUsage(c.state, id);
    const others = c.state.categories.filter((x) => x.kind === cat.kind && x.id !== id).map((x) => ({ value: x.id, label: `${x.icon} ${x.name}` }));
    const ok = await c.sheet(
      h`<h2>حذف دسته «${cat.name}»؟</h2>${used ? h`<p class="muted">${M.toPersianDigits(String(used))} تراکنش با این دسته ثبت شده است. آن‌ها به دسته‌ی زیر منتقل می‌شوند:</p><div class="field"><label for="reassign">دسته‌ی جایگزین</label>${select('reassign', others, others[0]?.value ?? '', { id: 'reassign' })}</div>` : h`<p class="muted">این دسته تراکنشی ندارد. بودجه‌ی این دسته (در صورت وجود) بسته می‌شود.</p>`}<div class="actions two"><button class="btn danger" data-action="sheet-yes">حذف</button><button class="btn" data-action="sheet-no">انصراف</button></div>`,
    );
    if (!ok) return;
    const reassignTo = c.ui.sheetValues?.reassign ?? null;
    await c.commit((s) => L.deleteCategory(s, id, { reassignTo, today: c.today() }));
    c.toast('دسته حذف شد.');
    c.go('#/categories');
  },

  // ----- بودجه -----
  'save-budget'(c, form, ev, v) {
    const errors = [];
    const limit = money('IRT', v.limit, 'limit', errors);
    const warnBp = Number(v.warn) * 100;
    return formOp(c, v, errors, (s) => L.setBudget(s, { categoryId: v.categoryId || null, period: v.period, limit, warnBp, effectiveFrom: c.today() }, mk(c)), () => {
      c.toast('بودجه ذخیره شد.');
      c.go('#/budgets');
    });
  },
  async 'ask-delete-budget'(c, el) {
    const ok = await c.confirm({ title: 'حذف این بودجه؟', text: 'بودجه از امروز متوقف می‌شود؛ تاریخچه‌ی گذشته دست‌نخورده می‌ماند.', confirmLabel: 'حذف', danger: true });
    if (!ok) return;
    await c.commit((s) => L.removeBudget(s, el.dataset.id, c.today()));
    c.toast('بودجه حذف شد.');
    c.go('#/budgets');
  },

  // ----- اهداف -----
  'save-goal': (c, form, ev, v) => saveGoal(c, form, v, false),
  'save-goal-edit': (c, form, ev, v) => saveGoal(c, form, v, true),
  async 'goal-contribute'(c, form, ev, v) {
    const g = c.state.goals.find((x) => x.id === form.dataset.id);
    const errors = [];
    const amount = money(g.currency, v.amount, 'amount', errors);
    const date = reqDate(v.date, 'date', errors);
    if (errors.length) return c.setForm({ values: v, errors });
    try {
      await c.commit((s) => L.addGoalContribution(s, g.id, { kind: v.kind, amount, date, note: v.note ?? '' }, mk(c)));
      c.ui.form = null;
      c.toast('ثبت شد.');
      c.render({ keepScroll: true, focus: false });
    } catch (e) {
      c.setForm({ values: v, errors: c.errorsFrom(e) });
    }
  },
  async 'remove-contribution'(c, el) {
    const ok = await c.confirm({ title: 'حذف این مورد؟', confirmLabel: 'حذف', danger: true });
    if (!ok) return;
    await c.commit((s) => L.removeGoalContribution(s, el.dataset.goal, el.dataset.id, mk(c)));
    c.render({ keepScroll: true, focus: false });
  },
  async 'ask-delete-goal'(c, el) {
    const ok = await c.confirm({ title: 'حذف این هدف؟', text: 'تاریخچه‌ی پس‌انداز این هدف هم حذف می‌شود. موجودی حساب‌ها تغییر نمی‌کند.', confirmLabel: 'حذف', danger: true });
    if (!ok) return;
    await c.commit((s) => L.deleteGoal(s, el.dataset.id));
    c.toast('هدف حذف شد.');
    c.go('#/goals');
  },

  // ----- بدهی و طلب -----
  'save-debt': (c, form, ev, v) => saveDebt(c, form, v, false),
  'save-debt-edit': (c, form, ev, v) => saveDebt(c, form, v, true),
  async 'debt-pay'(c, form, ev, v) {
    const d = c.state.debts.find((x) => x.id === form.dataset.id);
    const errors = [];
    const amount = money(d.currency, v.amount, 'amount', errors);
    const date = reqDate(v.date, 'date', errors);
    if (errors.length) return c.setForm({ values: v, errors });
    try {
      await c.commit((s) => L.addTransaction(s, { type: 'debt_payment', debtId: d.id, accountId: v.accountId, amount, date, note: v.note ?? '' }, mk(c), { allowDuplicate: true }));
      c.ui.form = null;
      c.toast(d.direction === 'owe' ? 'پرداخت ثبت شد.' : 'دریافت ثبت شد.');
      c.render({ keepScroll: true, focus: false });
    } catch (e) {
      c.setForm({ values: v, errors: c.errorsFrom(e) });
    }
  },
  async 'ask-delete-debt'(c, el) {
    const id = el.dataset.id;
    const payments = c.state.transactions.filter((t) => t.type === 'debt_payment' && t.debtId === id).length;
    const ok = await c.confirm({ title: 'حذف این مورد؟', text: payments ? `${M.toPersianDigits(String(payments))} پرداخت ثبت‌شده‌ی آن هم حذف می‌شود و موجودی حساب‌ها دوباره محاسبه می‌شود.` : 'این کار قابل بازگشت نیست.', confirmLabel: 'حذف', danger: true });
    if (!ok) return;
    await c.commit((s) => L.deleteDebt(s, id, { cascade: true }));
    c.toast('حذف شد.');
    c.go('#/debts');
  },
};

function saveGoal(c, form, v, edit) {
  const errors = [];
  const cur = v.currency || 'IRT';
  const targetAmount = money(cur, v.targetAmount, 'targetAmount', errors);
  const targetDate = optDate(v.targetDate, 'targetDate', errors);
  return formOp(c, v, errors, (s) => (edit ? L.updateGoal(s, form.dataset.id, { name: v.name, targetAmount, targetDate }, mk(c)) : L.addGoal(s, { name: v.name, currency: cur, targetAmount, targetDate }, mk(c))), (out) => {
    c.toast('هدف ذخیره شد.');
    c.go(edit ? `#/goals/${form.dataset.id}` : `#/goals/${out.goal.id}`);
  });
}

function saveDebt(c, form, v, edit) {
  const errors = [];
  const cur = v.currency || 'IRT';
  const principal = money(cur, v.principal, 'principal', errors);
  const date = edit ? null : reqDate(v.date, 'date', errors);
  const dueDate = optDate(v.dueDate, 'dueDate', errors);
  const base = { person: v.person, principal, dueDate, note: v.note ?? '' };
  return formOp(c, v, errors, (s) => (edit ? L.updateDebt(s, form.dataset.id, base, mk(c)) : L.addDebt(s, { ...base, direction: v.direction, currency: cur, date, accountId: v.accountId || null }, mk(c))), (out) => {
    c.toast('ذخیره شد.');
    c.go(edit ? `#/debts/${form.dataset.id}` : `#/debts/${out.debt.id}`);
  });
}
