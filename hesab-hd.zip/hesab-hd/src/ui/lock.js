// قفل PIN اختیاری.
// توجه صادقانه: این قفل فقط صفحه‌ی برنامه را می‌پوشاند و جلوی دیدن اطلاعات توسط اطرافیان را می‌گیرد.
// اطلاعات روی دستگاه رمزنگاری نمی‌شود؛ کسی که به فایل‌های مرورگر یا دستگاه دسترسی فنی دارد می‌تواند آن را بخواند.
// PIN خام ذخیره نمی‌شود، فقط هش PBKDF2 با salt تصادفی.

export const PIN_MIN = 4;
export const PIN_MAX = 8;
export const PBKDF2_ITER = 150_000;
export const MAX_FREE_ATTEMPTS = 5;

const subtle = () => globalThis.crypto?.subtle;
const b64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)));
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

export function normalizePin(input) {
  return String(input ?? '')
    .replace(/[۰-۹]/g, (c) => String(c.charCodeAt(0) - 0x06f0))
    .replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 0x0660))
    .trim();
}

export function validatePinFormat(input) {
  const p = normalizePin(input);
  if (!/^\d+$/.test(p)) return { ok: false, error: 'PIN فقط شامل رقم باشد.' };
  if (p.length < PIN_MIN || p.length > PIN_MAX) return { ok: false, error: `PIN باید ${PIN_MIN} تا ${PIN_MAX} رقم باشد.` };
  if (/^(\d)\1+$/.test(p) || '0123456789'.includes(p) || '9876543210'.includes(p)) return { ok: false, error: 'PIN خیلی ساده است (مثل ۱۱۱۱ یا ۱۲۳۴).' };
  return { ok: true, pin: p };
}

async function derive(pin, salt, iter) {
  if (!subtle()) throw new Error('WebCrypto در دسترس نیست.');
  const key = await subtle().importKey('raw', new TextEncoder().encode(pin), 'PBKDF2', false, ['deriveBits']);
  return subtle().deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: iter }, key, 256);
}

export async function createPinRecord(pin, iter = PBKDF2_ITER) {
  const v = validatePinFormat(pin);
  if (!v.ok) throw new Error(v.error);
  const salt = globalThis.crypto.getRandomValues(new Uint8Array(16));
  return { salt: b64(salt), hash: b64(await derive(v.pin, salt, iter)), iter };
}

export async function verifyPin(pin, record) {
  if (!record?.salt || !record?.hash) return false;
  try {
    const got = b64(await derive(normalizePin(pin), unb64(record.salt), record.iter ?? PBKDF2_ITER));
    // مقایسه‌ی هم‌زمان (بدون خروج زودهنگام)
    let diff = got.length ^ record.hash.length;
    for (let i = 0; i < got.length; i += 1) diff |= got.charCodeAt(i) ^ (record.hash.charCodeAt(i) || 0);
    return diff === 0;
  } catch {
    return false;
  }
}

// تأخیر پس از پنج تلاش ناموفق: ۳۰ ثانیه، سپس دو برابر (حداکثر ۱۵ دقیقه)
export function lockoutMs(failCount) {
  if (failCount < MAX_FREE_ATTEMPTS) return 0;
  return Math.min(30_000 * 2 ** (failCount - MAX_FREE_ATTEMPTS), 15 * 60_000);
}
