// اجزای مشترک رابط (همه خالص: ورودی → رشته‌ی HTML امن)
import { h, join, raw } from './dom.js';
import { icon } from './icons.js';
import * as M from '../core/money.js';
import * as J from '../core/jalali.js';

export const fa = (n) => M.toPersianDigits(String(n));
export const money = (currency, v, opts) => M.formatAmount(currency, v, opts);

export const TABS = [
  { id: 'home', label: 'خانه', icon: 'home' },
  { id: 'transactions', label: 'تراکنش‌ها', icon: 'list' },
  { id: 'add', label: 'ثبت', icon: 'plus', primary: true },
  { id: 'reports', label: 'گزارش‌ها', icon: 'chart' },
  { id: 'more', label: 'بیشتر', icon: 'more' },
];

export function bottomNav(active) {
  return h`<nav class="tabbar" aria-label="ناوبری اصلی">${TABS.map(
    (t) => h`<a class="tab ${t.primary ? 'tab-add' : ''} ${t.id === active ? 'on' : ''}" href="#/${t.id}" ${t.id === active ? raw('aria-current="page"') : ''}>${icon(t.icon, { size: t.primary ? 26 : 22 })}<span>${t.label}</span></a>`,
  )}</nav>`;
}

export function header(title, { back = null, actions = [] } = {}) {
  return h`<header class="appbar">${back ? h`<a class="iconbtn" href="${back}" aria-label="بازگشت">${icon('back')}</a>` : ''}<h1>${title}</h1><div class="appbar-actions">${actions.map(
    (a) => h`<a class="iconbtn" href="${a.href}" aria-label="${a.label}">${icon(a.icon)}</a>`,
  )}<button type="button" class="iconbtn exitbtn" data-action="exit-app" aria-label="خروج از برنامه">${icon('power')}</button></div></header>`;
}

export function card(body, { title = null, action = null, cls = '' } = {}) {
  return h`<section class="card ${cls}">${title || action ? h`<div class="card-head">${title ? h`<h2>${title}</h2>` : ''}${action ? h`<a class="link" href="${action.href}">${action.label}</a>` : ''}</div>` : ''}${body}</section>`;
}

export function emptyState({ emoji = '🌱', title, text = '', action = null }) {
  return h`<div class="empty"><div class="empty-emoji" aria-hidden="true">${emoji}</div><h3>${title}</h3>${text ? h`<p>${text}</p>` : ''}${action ? h`<a class="btn primary" href="${action.href}">${action.label}</a>` : ''}</div>`;
}

export function notice(text, kind = 'info') {
  return h`<div class="notice ${kind}" role="${kind === 'error' ? 'alert' : 'status'}">${icon(kind === 'error' || kind === 'warn' ? 'warn' : 'info', { size: 20 })}<div>${text}</div></div>`;
}

export function progress(bp, level = 'ok', label = '') {
  const pct = Math.max(0, Math.min(100, Math.round(bp / 100)));
  return h`<div class="bar ${level}" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pct}" aria-label="${label}"><i style="width:${pct}%"></i></div>`;
}

export const percentText = (bp) => `${fa(Math.round(bp / 100))}٪`;

// ---------- فرم ----------

export function field(label, control, { hint = '', error = '', id = '' } = {}) {
  return h`<div class="field ${error ? 'has-error' : ''}"><label ${id ? raw(`for="${id}"`) : ''}>${label}</label>${control}${hint ? h`<div class="hint">${hint}</div>` : ''}${error ? h`<div class="err" role="alert">${error}</div>` : ''}</div>`;
}

export function textInput(name, value = '', { placeholder = '', maxlength = 500, required = false, id = name } = {}) {
  return h`<input type="text" id="${id}" name="${name}" value="${value ?? ''}" placeholder="${placeholder}" maxlength="${maxlength}" autocomplete="off" ${required ? raw('required') : ''}>`;
}

export function amountInput(name, value = '', { id = name, placeholder = '۰', currency = 'IRT' } = {}) {
  return h`<div class="amount-wrap"><input type="text" id="${id}" name="${name}" value="${value}" inputmode="${currency === 'USD' ? 'decimal' : 'numeric'}" dir="ltr" class="amount" placeholder="${placeholder}" autocomplete="off" data-amount data-currency="${currency}"><span class="unit" data-unit>${M.CURRENCIES[currency]?.name ?? ''}</span></div><div class="preview" data-preview aria-live="polite"></div>`;
}

export function select(name, options, selected = '', { id = name, attrs = '' } = {}) {
  return h`<select id="${id}" name="${name}" ${raw(attrs)}>${options.map((o) => h`<option value="${o.value}" ${String(o.value) === String(selected) ? raw('selected') : ''} ${o.disabled ? raw('disabled') : ''}>${o.label}</option>`)}</select>`;
}

export function textarea(name, value = '', { rows = 2, maxlength = 500 } = {}) {
  return h`<textarea name="${name}" id="${name}" rows="${rows}" maxlength="${maxlength}">${value ?? ''}</textarea>`;
}

// انتخاب یکی از چند گزینه به‌صورت دکمه‌های کنار هم
export function segmented(name, options, selected) {
  return h`<div class="seg" role="radiogroup">${options.map(
    (o, i) => h`<label class="seg-item ${o.cls ?? ''}"><input type="radio" name="${name}" value="${o.value}" ${String(o.value) === String(selected) ? raw('checked') : ''} ${o.disabled ? raw('disabled') : ''}><span>${o.label}</span></label>`,
  )}</div>`;
}

// تاریخ شمسی با سه لیست کشویی (بدون تایپ، بدون خطای فرمت)
export function dateInput(name, value, { minYear = 1395, maxYear = 1420, optional = false } = {}) {
  const p = value ? J.parseDate(value) : null;
  const y = p?.jy ?? '';
  const m = p?.jm ?? '';
  const d = p?.jd ?? '';
  const years = [];
  for (let i = minYear; i <= maxYear; i += 1) years.push({ value: i, label: fa(i) });
  if (p && (p.jy < minYear || p.jy > maxYear)) years.push({ value: p.jy, label: fa(p.jy) });
  const months = J.MONTH_NAMES.map((n, i) => ({ value: i + 1, label: n }));
  const dayCount = p ? J.monthLength(p.jy, p.jm) : 31;
  const days = [];
  for (let i = 1; i <= dayCount; i += 1) days.push({ value: i, label: fa(i) });
  const blank = optional ? [{ value: '', label: '—' }] : [];
  return h`<div class="date3" data-date="${name}" data-optional="${optional ? 1 : 0}">${select(`${name}_d`, [...blank, ...days], d, { id: `${name}_d`, attrs: 'aria-label="روز"' })}${select(`${name}_m`, [...blank, ...months], m, { id: `${name}_m`, attrs: 'aria-label="ماه"' })}${select(`${name}_y`, [...blank, ...years], y, { id: `${name}_y`, attrs: 'aria-label="سال"' })}</div>`;
}

export function readDate(form, name) {
  const y = form.get(`${name}_y`);
  const m = form.get(`${name}_m`);
  const d = form.get(`${name}_d`);
  if (!y && !m && !d) return null;
  if (!y || !m || !d) return 'ناقص';
  return J.formatDate({ jy: Number(y), jm: Number(m), jd: Number(d) });
}

export function formErrors(errors) {
  if (!errors || errors.length === 0) return '';
  return h`<div class="notice error" role="alert">${icon('warn', { size: 20 })}<ul>${errors.map((e) => h`<li>${e.message}</li>`)}</ul></div>`;
}

export function dateLabel(date, today = null) {
  if (!date) return '';
  if (today && date === today) return 'امروز';
  if (today && date === J.addDays(today, -1)) return 'دیروز';
  const p = J.parseDate(date);
  return `${fa(p.jd)} ${J.MONTH_NAMES[p.jm - 1]}`;
}

// ---------- نمودارها (SVG، بدون کتابخانه) ----------
// جهت زمان در نمودارها راست‌به‌چپ است (قدیمی‌ترین در سمت راست).

const compact = (n) => {
  const a = Math.abs(n);
  const sign = n < 0 ? '−' : '';
  if (a >= 1e9) return `${sign}${fa((a / 1e9).toFixed(1).replace(/\.0$/, ''))} میلیارد`;
  if (a >= 1e6) return `${sign}${fa((a / 1e6).toFixed(1).replace(/\.0$/, ''))} میلیون`;
  if (a >= 1e3) return `${sign}${fa(Math.round(a / 1e3))} هزار`;
  return `${sign}${fa(a)}`;
};
export const compactAmount = compact;

// ستون‌های جفتیِ درآمد/هزینه. rows: [{label, income, expense}]
export function barChart(rows, { label = 'نمودار درآمد و هزینه', unit = 'تومان' } = {}) {
  const W = 320;
  const Hh = 170;
  const padB = 28;
  const padT = 8;
  const max = Math.max(1, ...rows.flatMap((r) => [r.income, r.expense]));
  const n = rows.length;
  const slot = (W - 10) / Math.max(n, 1);
  const bw = Math.min(16, slot / 2.6);
  const y = (v) => padT + (Hh - padB - padT) * (1 - v / max);
  const bars = rows.map((r, i) => {
    const cx = W - 5 - slot * (i + 0.5);
    const ih = Hh - padB - y(r.income);
    const eh = Hh - padB - y(r.expense);
    return `<g><rect class="bar-inc" x="${(cx - bw - 1).toFixed(1)}" y="${y(r.income).toFixed(1)}" width="${bw.toFixed(1)}" height="${Math.max(ih, 0).toFixed(1)}" rx="3"/><rect class="bar-exp" x="${(cx + 1).toFixed(1)}" y="${y(r.expense).toFixed(1)}" width="${bw.toFixed(1)}" height="${Math.max(eh, 0).toFixed(1)}" rx="3"/><text class="axis" x="${cx.toFixed(1)}" y="${Hh - 10}" text-anchor="middle">${String(r.label).replace(/[<>&]/g, '')}</text></g>`;
  });
  const desc = rows.map((r) => `${r.label}: درآمد ${compact(r.income)}، هزینه ${compact(r.expense)} ${unit}`).join('؛ ');
  return h`<figure class="chart"><svg viewBox="0 0 ${W} ${Hh}" role="img" aria-label="${label}. ${desc}"><line class="grid" x1="0" x2="${W}" y1="${Hh - padB}" y2="${Hh - padB}"/>${raw(bars.join(''))}</svg><figcaption class="legend"><span><i class="dot inc"></i>درآمد</span><span><i class="dot exp"></i>هزینه</span></figcaption></figure>`;
}

// نمودار خطی ساده برای روند (مثل موجودی). points: [{label, value}]
export function lineChart(points, { label = 'روند' } = {}) {
  const W = 320;
  const Hh = 150;
  const pad = 10;
  if (points.length === 0) return h``;
  const vals = points.map((p) => p.value);
  const min = Math.min(0, ...vals);
  const max = Math.max(1, ...vals);
  const n = points.length;
  const x = (i) => (n === 1 ? W / 2 : W - pad - ((W - 2 * pad) * i) / (n - 1));
  const y = (v) => pad + (Hh - 2 * pad) * (1 - (v - min) / (max - min || 1));
  const d = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)},${y(p.value).toFixed(1)}`).join(' ');
  const zeroY = y(0).toFixed(1);
  const first = points[0];
  const last = points[n - 1];
  return h`<figure class="chart"><svg viewBox="0 0 ${W} ${Hh}" role="img" aria-label="${label}: از ${first.label} (${compact(first.value)}) تا ${last.label} (${compact(last.value)})"><line class="grid" x1="0" x2="${W}" y1="${zeroY}" y2="${zeroY}"/><path class="line" d="${d}" fill="none"/>${raw(points.length <= 40 ? points.map((p, i) => `<circle class="pt" cx="${x(i).toFixed(1)}" cy="${y(p.value).toFixed(1)}" r="2.5"/>`).join('') : '')}</svg></figure>`;
}

// نمودار حلقه‌ای سهم دسته‌ها. items: [{name, color, total, shareBp}]
export function donut(items, { label = 'سهم دسته‌ها', centerText = '' } = {}) {
  const R = 52;
  const C = 2 * Math.PI * R;
  let offset = 0;
  const total = items.reduce((s, i) => s + i.total, 0) || 1;
  const segs = items.map((it) => {
    const len = (it.total / total) * C;
    const s = `<circle cx="70" cy="70" r="${R}" fill="none" stroke="${/^#[0-9a-fA-F]{6}$/.test(it.color) ? it.color : '#868e96'}" stroke-width="18" stroke-dasharray="${len.toFixed(2)} ${(C - len).toFixed(2)}" stroke-dashoffset="${(-offset).toFixed(2)}" transform="rotate(-90 70 70)"/>`;
    offset += len;
    return s;
  });
  const desc = items.map((i) => `${i.name} ${percentText(i.shareBp)}`).join('، ');
  return h`<figure class="chart donut"><svg viewBox="0 0 140 140" role="img" aria-label="${label}: ${desc}">${raw(segs.join(''))}${centerText ? raw(`<text x="70" y="75" text-anchor="middle" class="donut-c">${String(centerText).replace(/[<>&]/g, '')}</text>`) : ''}</svg></figure>`;
}

export function txAmountClass(type) {
  return type === 'income' ? 'pos' : type === 'expense' ? 'neg' : 'neu';
}

export { h, join, raw, icon };
