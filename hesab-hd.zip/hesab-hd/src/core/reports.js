// حساب HD — گزارش‌ها و تجمیع داده برای داشبورد و نمودارها
//
// تمام اعداد از همان تراکنش‌های ذخیره‌شده و با منطق مشترک ledger محاسبه می‌شوند.
// قواعد ثابت: انتقال بین حساب‌ها، پرداخت/دریافت بدهی و مشارکت پس‌انداز هیچ‌وقت درآمد یا هزینه
// حساب نمی‌شوند؛ و ارزهای مختلف هیچ‌وقت بدون تبدیل مشخص با هم جمع نمی‌شوند (هر گزارش یک ارز دارد).

import * as J from './jalali.js';
import * as M from './money.js';
import * as L from './ledger.js';
import { USD_STATUS, pendingTransactions } from './fx.js';

const isFlow = (t) => t.type === 'income' || t.type === 'expense';

function inRange(t, from, to) {
  return (!from || t.date >= from) && (!to || t.date <= to);
}

function rankCategories(state, totals, type) {
  const grand = M.sumAmounts([...totals.values()].map((v) => v.total));
  return [...totals.entries()]
    .map(([categoryId, v]) => {
      const cat = state.categories.find((c) => c.id === categoryId);
      return {
        categoryId,
        name: cat?.name ?? 'بدون دسته',
        icon: cat?.icon ?? '🏷️',
        color: cat?.color ?? '#868e96',
        type,
        total: v.total,
        count: v.count,
        shareBp: M.percentBp(v.total, grand),
      };
    })
    .sort((a, b) => b.total - a.total || a.name.localeCompare(b.name, 'fa'));
}

// ---------- خلاصه‌ی یک بازه ----------

export function summarize(state, { from = null, to = null, currency = 'IRT', accountId = null, categoryId = null } = {}) {
  let income = 0;
  let expense = 0;
  let incomeCount = 0;
  let expenseCount = 0;
  let debtPaidOut = 0;
  let debtReceived = 0;
  let excludedTransfers = 0;
  const exp = new Map();
  const inc = new Map();
  for (const t of state.transactions) {
    if (!inRange(t, from, to)) continue;
    if (t.type === 'transfer') {
      if (t.currency === currency || t.toCurrency === currency) excludedTransfers += 1;
      continue;
    }
    if (t.currency !== currency) continue;
    if (accountId && t.accountId !== accountId) continue;
    if (t.type === 'debt_payment') {
      const d = state.debts.find((x) => x.id === t.debtId);
      if (d?.direction === 'owe') debtPaidOut = M.safeAdd(debtPaidOut, t.amount);
      else if (d) debtReceived = M.safeAdd(debtReceived, t.amount);
      continue;
    }
    if (categoryId && t.categoryId !== categoryId) continue;
    const bucket = t.type === 'income' ? inc : exp;
    const cur = bucket.get(t.categoryId) ?? { total: 0, count: 0 };
    bucket.set(t.categoryId, { total: M.safeAdd(cur.total, t.amount), count: cur.count + 1 });
    if (t.type === 'income') {
      income = M.safeAdd(income, t.amount);
      incomeCount += 1;
    } else {
      expense = M.safeAdd(expense, t.amount);
      expenseCount += 1;
    }
  }
  const days = from && to ? J.diffDays(to, from) + 1 : null;
  return {
    currency,
    from,
    to,
    income,
    expense,
    net: income - expense,
    incomeCount,
    expenseCount,
    count: incomeCount + expenseCount,
    days,
    avgDailyExpense: days ? M.roundDiv(expense, days) : null,
    avgDailyIncome: days ? M.roundDiv(income, days) : null,
    expenseByCategory: rankCategories(state, exp, 'expense'),
    incomeByCategory: rankCategories(state, inc, 'income'),
    debtPaidOut,
    debtReceived,
    excludedTransfers,
    hasData: incomeCount + expenseCount > 0,
  };
}

// ---------- سری‌های زمانی ----------

export function periodOf(date, granularity) {
  const p = J.parseDate(date);
  if (!p) throw new RangeError(`تاریخ نامعتبر: ${date}`);
  switch (granularity) {
    case 'day':
      return { key: date, from: date, to: date };
    case 'week': {
      const r = J.weekRange(date);
      return { key: r.from, from: r.from, to: r.to };
    }
    case 'month': {
      const r = J.monthRange(p.jy, p.jm);
      return { key: `${String(p.jy).padStart(4, '0')}-${String(p.jm).padStart(2, '0')}`, ...r };
    }
    case 'year': {
      const r = J.yearRange(p.jy);
      return { key: String(p.jy).padStart(4, '0'), ...r };
    }
    default:
      throw new RangeError(`گام زمانی نامعتبر: ${granularity}`);
  }
}

// تمام بازه‌های بین from و to (حتی بدون تراکنش) با جمع درآمد/هزینه‌ی همان بازه.
// جمع‌ها فقط تراکنش‌های داخل [from, to] را می‌شمارند، حتی اگر هفته/ماه نیمه‌کاره باشد.
export function series(state, { from, to, currency = 'IRT', granularity = 'day' }) {
  if (J.compareDates(from, to) > 0) throw new RangeError('تاریخ شروع بعد از پایان است.');
  const buckets = [];
  const index = new Map();
  let cur = from;
  while (cur <= to) {
    const p = periodOf(cur, granularity);
    const b = { ...p, income: 0, expense: 0, net: 0, count: 0 };
    buckets.push(b);
    index.set(p.key, b);
    cur = J.addDays(p.to, 1);
  }
  for (const t of state.transactions) {
    if (!isFlow(t) || t.currency !== currency || !inRange(t, from, to)) continue;
    const b = index.get(periodOf(t.date, granularity).key);
    if (!b) continue;
    if (t.type === 'income') b.income = M.safeAdd(b.income, t.amount);
    else b.expense = M.safeAdd(b.expense, t.amount);
    b.count += 1;
  }
  for (const b of buckets) b.net = b.income - b.expense;
  return buckets;
}

// تغییر موجودی در طول زمان (جمع حساب‌های همان ارز)؛ انتقال داخلی بین حساب‌ها اثر خالص صفر دارد
export function balanceOverTime(state, { from, to, currency = 'IRT', accountIds = null }) {
  const accounts = state.accounts.filter((a) => a.currency === currency && (!accountIds || accountIds.includes(a.id)));
  const ids = new Set(accounts.map((a) => a.id));
  let balance = M.sumAmounts(accounts.map((a) => a.openingBalance));
  const perDay = new Map();
  for (const e of L.allEffects(state)) {
    if (!ids.has(e.accountId)) continue;
    if (e.date < from) balance = M.safeAdd(balance, e.delta);
    else if (e.date <= to) perDay.set(e.date, M.safeAdd(perDay.get(e.date) ?? 0, e.delta));
  }
  return J.listDates(from, to).map((date) => {
    balance = M.safeAdd(balance, perDay.get(date) ?? 0);
    return { date, balance };
  });
}

// مقایسه‌ی ماه جاری با ماه‌های قبل
export function monthComparison(state, { jy, jm, months = 6, currency = 'IRT' }) {
  const rows = [];
  let cursor = J.formatDate({ jy, jm, jd: 1 });
  for (let i = 0; i < months; i += 1) {
    const p = J.parseDate(cursor);
    const r = J.monthRange(p.jy, p.jm);
    const s = summarize(state, { ...r, currency });
    rows.push({ jy: p.jy, jm: p.jm, label: `${J.MONTH_NAMES[p.jm - 1]} ${p.jy}`, income: s.income, expense: s.expense, net: s.net, hasData: s.hasData });
    cursor = J.addMonths(cursor, -1);
  }
  rows.reverse();
  const current = rows[rows.length - 1];
  const previous = rows.length > 1 ? rows[rows.length - 2] : null;
  return {
    rows,
    expenseDelta: previous ? current.expense - previous.expense : null,
    incomeDelta: previous ? current.income - previous.income : null,
  };
}

// ---------- بودجه ----------

export function periodRangeFor(date, period) {
  if (period === 'daily') return { from: date, to: date };
  if (period === 'weekly') return J.weekRange(date);
  const p = J.parseDate(date);
  return J.monthRange(p.jy, p.jm);
}

export function budgetStatuses(state, date) {
  return L.budgetsActiveOn(state, date).map((budget) => {
    const range = periodRangeFor(date, budget.period);
    const s = summarize(state, { ...range, currency: budget.currency, categoryId: budget.categoryId });
    const spent = s.expense;
    const usedBp = M.percentBp(spent, budget.limit);
    let level = 'ok';
    if (spent > budget.limit) level = 'exceeded';
    else if (usedBp >= budget.warnBp) level = 'warning';
    const cat = budget.categoryId ? state.categories.find((c) => c.id === budget.categoryId) : null;
    return {
      budget,
      title: cat ? cat.name : 'کل هزینه‌ها',
      range,
      limit: budget.limit,
      spent,
      remaining: budget.limit - spent,
      overBy: Math.max(spent - budget.limit, 0),
      usedBp,
      level,
    };
  });
}

// ---------- ارزش دلاری ----------
// ارزش دلاریِ «محاسبه‌شده» از «در انتظار» جدا می‌ماند و نرخ‌های استفاده‌شده فهرست می‌شوند.

export function usdReport(state, { from = null, to = null } = {}) {
  const out = {
    doneCount: 0,
    pendingCount: 0,
    pendingToman: 0,
    incomeCents: 0,
    expenseCents: 0,
    nativeUsdIncomeCents: 0,
    nativeUsdExpenseCents: 0,
    rates: [],
  };
  const rates = new Map();
  for (const t of state.transactions) {
    if (!isFlow(t) || !inRange(t, from, to)) continue;
    if (t.currency === 'USD') {
      if (t.type === 'income') out.nativeUsdIncomeCents = M.safeAdd(out.nativeUsdIncomeCents, t.amount);
      else out.nativeUsdExpenseCents = M.safeAdd(out.nativeUsdExpenseCents, t.amount);
      continue;
    }
    if (t.usd?.status === USD_STATUS.DONE) {
      out.doneCount += 1;
      if (t.type === 'income') out.incomeCents = M.safeAdd(out.incomeCents, t.usd.cents);
      else out.expenseCents = M.safeAdd(out.expenseCents, t.usd.cents);
      const key = `${t.usd.rate}|${t.usd.rateAt}|${t.usd.source}|${t.usd.manual}`;
      const r = rates.get(key) ?? { rate: t.usd.rate, rateAt: t.usd.rateAt, source: t.usd.source, manual: t.usd.manual, count: 0 };
      r.count += 1;
      rates.set(key, r);
    } else if (t.usd?.status === USD_STATUS.PENDING) {
      out.pendingCount += 1;
      out.pendingToman = M.safeAdd(out.pendingToman, t.amount);
    }
  }
  out.rates = [...rates.values()].sort((a, b) => (a.rateAt < b.rateAt ? 1 : -1));
  return out;
}

// ---------- داشبورد ----------

export function dashboard(state, today, { recent = 10, trendMonths = 6 } = {}) {
  const p = J.parseDate(today);
  const week = J.weekRange(today);
  const month = J.monthRange(p.jy, p.jm);
  const currencies = new Set(state.accounts.filter((a) => !a.archived).map((a) => a.currency));
  currencies.add('IRT');
  const byCurrency = {};
  for (const c of currencies) {
    byCurrency[c] = {
      today: summarize(state, { from: today, to: today, currency: c }),
      week: summarize(state, { ...week, currency: c }),
      month: summarize(state, { ...month, currency: c }),
    };
  }
  return {
    today,
    isEmpty: state.accounts.length === 0 && state.transactions.length === 0,
    totals: L.totalBalances(state),
    accounts: L.accountBalances(state).filter((x) => !x.account.archived),
    byCurrency,
    budgets: budgetStatuses(state, today),
    goals: state.goals.map((g) => L.goalProgress(g, today)),
    debts: L.debtTotals(state, today),
    recent: L.queryTransactions(state, {}).slice(0, recent),
    trend: monthComparison(state, { jy: p.jy, jm: p.jm, months: trendMonths }),
    topCategories: byCurrency.IRT.month.expenseByCategory.slice(0, 5),
    pendingUsdCount: pendingTransactions(state).length,
  };
}
