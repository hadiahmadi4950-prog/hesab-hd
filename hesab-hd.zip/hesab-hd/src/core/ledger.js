// حساب HD — منطق مالی (دفتر کل)
//
// قراردادها:
// - تمام توابع «خالص» هستند: state را عوض نمی‌کنند و state جدید برمی‌گردانند.
// - مبلغ‌ها همیشه عدد صحیح «واحد کوچک» هستند: تومان (IRT) و سنت (USD). ورودی متنی کاربر را
//   لایه‌ی رابط کاربری با money.parseAmount تبدیل می‌کند؛ این ماژول رشته نمی‌پذیرد.
// - تاریخ‌ها رشته‌ی شمسی «YYYY-MM-DD» هستند.
// - انتقال بین حساب‌ها یک رکورد واحد است (نه دو رکورد)؛ بنابراین ویرایش یا حذفش هر دو سمت را
//   هم‌زمان درست می‌کند و هیچ‌وقت درآمد/هزینه حساب نمی‌شود.
// - پرداخت/دریافت بدهی و مشارکت پس‌انداز هزینه یا درآمد حساب نمی‌شوند.

import * as J from './jalali.js';
import * as M from './money.js';
import { initialUsdField, invalidateUsdField, createFxState } from './fx.js';

export const STATE_VERSION = 1;
export const TX_TYPES = Object.freeze(['income', 'expense', 'transfer', 'debt_payment']);
export const ACCOUNT_TYPES = Object.freeze(['cash', 'bank', 'wallet', 'fx']);
export const ACCOUNT_TYPE_LABELS = Object.freeze({ cash: 'پول نقد', bank: 'حساب بانکی', wallet: 'کیف پول', fx: 'حساب ارزی' });
export const MAX_NOTE_LENGTH = 500;
export const MAX_NAME_LENGTH = 40;

export class ValidationError extends Error {
  constructor(errors, code = 'VALIDATION', extra = {}) {
    const list = Array.isArray(errors) ? errors : [{ field: '_', message: String(errors) }];
    super(list.map((e) => e.message).join(' '));
    this.name = 'ValidationError';
    this.code = code;
    this.errors = list;
    Object.assign(this, extra);
  }
}

export function defaultCtx() {
  return {
    now: () => new Date().toISOString(),
    id: () => globalThis.crypto.randomUUID(),
  };
}

// ---------- دسته‌بندی‌های پیش‌فرض (قابل ویرایش و حذف) ----------

export function defaultCategories() {
  const expense = [
    ['food', 'خوراک', '🍽️', '#ef6c3c'],
    ['transport', 'حمل‌ونقل', '🚌', '#3b82c4'],
    ['bills', 'قبوض', '💡', '#e0a800'],
    ['rent', 'اجاره و مسکن', '🏠', '#7c5cbf'],
    ['health', 'سلامت و درمان', '💊', '#d6455d'],
    ['education', 'آموزش', '📚', '#2f9e8f'],
    ['fun', 'تفریح', '🎬', '#c75fa5'],
    ['clothes', 'پوشاک', '👕', '#5c7cfa'],
    ['home', 'خرید منزل', '🛒', '#8d6e4e'],
    ['gift', 'هدیه و صدقه', '🎁', '#e8590c'],
    ['other', 'سایر هزینه‌ها', '📦', '#868e96'],
  ].map(([k, name, icon, color]) => ({ id: `cat-expense-${k}`, name, kind: 'expense', icon, color, builtin: true }));
  const income = [
    ['salary', 'حقوق', '💼', '#2f9e44'],
    ['business', 'کسب‌وکار', '🏪', '#0c8599'],
    ['gift', 'هدیه', '🎉', '#e8590c'],
    ['invest', 'سرمایه‌گذاری', '📈', '#5f3dc4'],
    ['other', 'سایر درآمدها', '➕', '#868e96'],
  ].map(([k, name, icon, color]) => ({ id: `cat-income-${k}`, name, kind: 'income', icon, color, builtin: true }));
  return [...expense, ...income];
}

export function createEmptyState() {
  return {
    version: STATE_VERSION,
    accounts: [],
    categories: defaultCategories(),
    transactions: [],
    budgets: [],
    goals: [],
    debts: [],
    fx: createFxState(),
  };
}

// ---------- ابزارهای کوچک ----------

const byId = (list, id) => list.find((x) => x.id === id) ?? null;
const err = (field, message) => ({ field, message });

function cleanName(raw, field, label, errors) {
  const name = typeof raw === 'string' ? raw.trim().replace(/\s+/g, ' ') : '';
  if (name === '') errors.push(err(field, `${label} را وارد کنید.`));
  else if (name.length > MAX_NAME_LENGTH) errors.push(err(field, `${label} حداکثر ${MAX_NAME_LENGTH} نویسه باشد.`));
  return name;
}

export function normalizeFa(s) {
  return String(s ?? '')
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/[۰-۹]/g, (c) => String(c.charCodeAt(0) - 0x06f0))
    .replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 0x0660))
    .toLowerCase();
}

const sameName = (a, b) => normalizeFa(a) === normalizeFa(b);

function checkAmount(currency, value, field, errors, { allowZero = false, allowNegative = false } = {}) {
  if (typeof value !== 'number' || !Number.isSafeInteger(value)) {
    errors.push(err(field, 'مبلغ باید عدد صحیح باشد.'));
    return false;
  }
  if (!M.isValidAmount(currency, value)) {
    errors.push(err(field, 'مبلغ خارج از محدوده‌ی مجاز است.'));
    return false;
  }
  if (value < 0 && !allowNegative) {
    errors.push(err(field, 'مبلغ نمی‌تواند منفی باشد.'));
    return false;
  }
  if (value === 0 && !allowZero) {
    errors.push(err(field, 'مبلغ باید بیشتر از صفر باشد.'));
    return false;
  }
  return true;
}

// بازه‌ی سال قابل‌قبول برای تاریخ‌ها؛ از ورود اشتباه تاریخ میلادی (مثلاً 2026-10-11) جلوگیری می‌کند
export const DATE_MIN_YEAR = 1300;
export const DATE_MAX_YEAR = 1500;

function cleanDate(raw, field, errors) {
  const p = J.parseDate(raw);
  if (!p) {
    errors.push(err(field, 'تاریخ شمسی نامعتبر است.'));
    return null;
  }
  if (p.jy < DATE_MIN_YEAR || p.jy > DATE_MAX_YEAR) {
    errors.push(err(field, `سال تاریخ باید بین ${DATE_MIN_YEAR} و ${DATE_MAX_YEAR} شمسی باشد.`));
    return null;
  }
  return J.formatDate(p);
}

function cleanNote(raw, errors) {
  if (raw === undefined || raw === null) return '';
  if (typeof raw !== 'string') {
    errors.push(err('note', 'یادداشت باید متن باشد.'));
    return '';
  }
  const note = raw.trim();
  if (note.length > MAX_NOTE_LENGTH) errors.push(err('note', `یادداشت حداکثر ${MAX_NOTE_LENGTH} نویسه باشد.`));
  return note;
}

function put(state, key, list) {
  return { ...state, [key]: list };
}

// ---------- حساب‌ها ----------

export function accountInUse(state, id) {
  return (
    state.transactions.some((t) => t.accountId === id || t.fromAccountId === id || t.toAccountId === id) ||
    state.debts.some((d) => d.accountId === id)
  );
}

export function addAccount(state, input, ctx = defaultCtx()) {
  const errors = [];
  const name = cleanName(input.name, 'name', 'نام حساب', errors);
  const type = input.type ?? 'cash';
  if (!ACCOUNT_TYPES.includes(type)) errors.push(err('type', 'نوع حساب نامعتبر است.'));
  const currency = input.currency ?? 'IRT';
  if (!M.CURRENCIES[currency]) errors.push(err('currency', 'واحد پول نامعتبر است.'));
  const openingBalance = input.openingBalance ?? 0;
  if (M.CURRENCIES[currency]) checkAmount(currency, openingBalance, 'openingBalance', errors, { allowZero: true, allowNegative: true });
  if (name && state.accounts.some((a) => !a.archived && sameName(a.name, name))) {
    errors.push(err('name', 'حسابی با این نام وجود دارد.'));
  }
  if (errors.length) throw new ValidationError(errors);
  const now = ctx.now();
  const account = { id: ctx.id(), name, type, currency, openingBalance, archived: false, createdAt: now, updatedAt: now };
  return { state: put(state, 'accounts', [...state.accounts, account]), account };
}

export function updateAccount(state, id, patch, ctx = defaultCtx()) {
  const old = byId(state.accounts, id);
  if (!old) throw new ValidationError('حساب پیدا نشد.', 'NOT_FOUND');
  const errors = [];
  const next = { ...old };
  if (patch.name !== undefined) next.name = cleanName(patch.name, 'name', 'نام حساب', errors);
  if (patch.type !== undefined) {
    if (!ACCOUNT_TYPES.includes(patch.type)) errors.push(err('type', 'نوع حساب نامعتبر است.'));
    else next.type = patch.type;
  }
  if (patch.currency !== undefined && patch.currency !== old.currency) {
    if (accountInUse(state, id)) errors.push(err('currency', 'واحد پول حسابی که تراکنش دارد قابل تغییر نیست.'));
    else if (!M.CURRENCIES[patch.currency]) errors.push(err('currency', 'واحد پول نامعتبر است.'));
    else next.currency = patch.currency;
  }
  if (patch.openingBalance !== undefined) {
    if (checkAmount(next.currency, patch.openingBalance, 'openingBalance', errors, { allowZero: true, allowNegative: true })) {
      next.openingBalance = patch.openingBalance;
    }
  }
  if (next.name && state.accounts.some((a) => a.id !== id && !a.archived && sameName(a.name, next.name))) {
    errors.push(err('name', 'حسابی با این نام وجود دارد.'));
  }
  if (errors.length) throw new ValidationError(errors);
  next.updatedAt = ctx.now();
  return { state: put(state, 'accounts', state.accounts.map((a) => (a.id === id ? next : a))), account: next };
}

export function setAccountArchived(state, id, archived, ctx = defaultCtx()) {
  const old = byId(state.accounts, id);
  if (!old) throw new ValidationError('حساب پیدا نشد.', 'NOT_FOUND');
  if (!archived && state.accounts.some((a) => a.id !== id && !a.archived && sameName(a.name, old.name))) {
    throw new ValidationError([err('name', 'حسابی با این نام وجود دارد.')]);
  }
  const next = { ...old, archived: Boolean(archived), updatedAt: ctx.now() };
  return { state: put(state, 'accounts', state.accounts.map((a) => (a.id === id ? next : a))), account: next };
}

export function deleteAccount(state, id) {
  if (!byId(state.accounts, id)) throw new ValidationError('حساب پیدا نشد.', 'NOT_FOUND');
  if (accountInUse(state, id)) {
    throw new ValidationError('این حساب تراکنش دارد و حذف نمی‌شود؛ می‌توانید آن را بایگانی کنید.', 'IN_USE');
  }
  return { state: put(state, 'accounts', state.accounts.filter((a) => a.id !== id)) };
}

// ---------- دسته‌بندی‌ها ----------

export function addCategory(state, input, ctx = defaultCtx()) {
  const errors = [];
  const name = cleanName(input.name, 'name', 'نام دسته', errors);
  const kind = input.kind;
  if (kind !== 'income' && kind !== 'expense') errors.push(err('kind', 'نوع دسته باید درآمد یا هزینه باشد.'));
  if (name && state.categories.some((c) => c.kind === kind && sameName(c.name, name))) {
    errors.push(err('name', 'دسته‌ای با این نام وجود دارد.'));
  }
  const color = input.color ?? '#868e96';
  if (typeof color !== 'string' || !/^#[0-9a-fA-F]{6}$/.test(color)) errors.push(err('color', 'رنگ نامعتبر است.'));
  const icon = input.icon ?? '🏷️';
  if (typeof icon !== 'string' || icon.length === 0 || icon.length > 8) errors.push(err('icon', 'آیکون نامعتبر است.'));
  if (errors.length) throw new ValidationError(errors);
  const category = { id: ctx.id(), name, kind, icon, color, builtin: false };
  return { state: put(state, 'categories', [...state.categories, category]), category };
}

export function updateCategory(state, id, patch) {
  const old = byId(state.categories, id);
  if (!old) throw new ValidationError('دسته پیدا نشد.', 'NOT_FOUND');
  const errors = [];
  const next = { ...old };
  if (patch.name !== undefined) next.name = cleanName(patch.name, 'name', 'نام دسته', errors);
  if (patch.icon !== undefined) {
    if (typeof patch.icon !== 'string' || patch.icon.length === 0 || patch.icon.length > 8) errors.push(err('icon', 'آیکون نامعتبر است.'));
    else next.icon = patch.icon;
  }
  if (patch.color !== undefined) {
    if (typeof patch.color !== 'string' || !/^#[0-9a-fA-F]{6}$/.test(patch.color)) errors.push(err('color', 'رنگ نامعتبر است.'));
    else next.color = patch.color;
  }
  if (next.name && state.categories.some((c) => c.id !== id && c.kind === next.kind && sameName(c.name, next.name))) {
    errors.push(err('name', 'دسته‌ای با این نام وجود دارد.'));
  }
  if (errors.length) throw new ValidationError(errors);
  return { state: put(state, 'categories', state.categories.map((c) => (c.id === id ? next : c))), category: next };
}

export function categoryUsage(state, id) {
  return state.transactions.filter((t) => t.categoryId === id).length;
}

// حذف دسته: اگر تراکنش دارد باید دسته‌ی جایگزین (هم‌نوع) داده شود. بودجه‌های آن دسته بسته می‌شوند.
export function deleteCategory(state, id, { reassignTo = null, today = null } = {}) {
  const cat = byId(state.categories, id);
  if (!cat) throw new ValidationError('دسته پیدا نشد.', 'NOT_FOUND');
  const used = categoryUsage(state, id);
  let transactions = state.transactions;
  if (used > 0) {
    const target = reassignTo ? byId(state.categories, reassignTo) : null;
    if (!target || target.id === id || target.kind !== cat.kind) {
      throw new ValidationError('این دسته تراکنش دارد؛ دسته‌ی جایگزین (هم‌نوع) را انتخاب کنید.', 'IN_USE', { usage: used });
    }
    transactions = transactions.map((t) => (t.categoryId === id ? { ...t, categoryId: target.id } : t));
  }
  const closeOn = today ?? null;
  const budgets = state.budgets.map((b) =>
    b.categoryId === id && !b.effectiveTo
      ? { ...b, effectiveTo: closeOn ? J.addDays(closeOn, -1) : b.effectiveFrom, categoryRemoved: true }
      : b,
  );
  return {
    state: { ...state, categories: state.categories.filter((c) => c.id !== id), transactions, budgets },
    reassigned: used,
  };
}

// ---------- تراکنش‌ها ----------

function emptyTxShape() {
  return { accountId: null, fromAccountId: null, toAccountId: null, toAmount: null, categoryId: null, debtId: null };
}

function usdFor(type, currency) {
  return type === 'income' || type === 'expense' ? initialUsdField(currency) : { status: 'not_applicable' };
}

export function debtPaid(state, debtId, { excludeTxId = null } = {}) {
  let sum = 0;
  for (const t of state.transactions) {
    if (t.type === 'debt_payment' && t.debtId === debtId && t.id !== excludeTxId) sum = M.safeAdd(sum, t.amount);
  }
  return sum;
}

// ورودی کامل یک تراکنش را اعتبارسنجی و به شکل استاندارد درمی‌آورد
function buildTransaction(state, input, { excludeTxId = null } = {}) {
  const errors = [];
  const type = input.type;
  if (!TX_TYPES.includes(type)) {
    return { errors: [err('type', 'نوع تراکنش نامعتبر است.')] };
  }
  const tx = { ...emptyTxShape(), type, amount: input.amount, date: null, note: '', method: null };
  tx.date = cleanDate(input.date, 'date', errors);
  tx.note = cleanNote(input.note, errors);
  if (input.method !== undefined && input.method !== null) {
    if (typeof input.method !== 'string' || input.method.length > 40) errors.push(err('method', 'روش پرداخت نامعتبر است.'));
    else tx.method = input.method.trim() || null;
  }

  const account = (id, field) => {
    const a = byId(state.accounts, id);
    if (!a) errors.push(err(field, 'حساب انتخاب‌شده وجود ندارد.'));
    else if (a.archived) errors.push(err(field, `حساب «${a.name}» بایگانی شده است.`));
    return a;
  };

  if (type === 'income' || type === 'expense') {
    const acc = account(input.accountId, 'accountId');
    tx.accountId = input.accountId ?? null;
    const cat = byId(state.categories, input.categoryId);
    if (!cat) errors.push(err('categoryId', 'دسته‌بندی انتخاب‌شده وجود ندارد.'));
    else if (cat.kind !== type) errors.push(err('categoryId', 'نوع دسته با نوع تراکنش (درآمد/هزینه) هم‌خوان نیست.'));
    tx.categoryId = input.categoryId ?? null;
    if (acc) {
      tx.currency = acc.currency;
      checkAmount(acc.currency, tx.amount, 'amount', errors);
    }
  } else if (type === 'transfer') {
    const from = account(input.fromAccountId, 'fromAccountId');
    const to = account(input.toAccountId, 'toAccountId');
    tx.fromAccountId = input.fromAccountId ?? null;
    tx.toAccountId = input.toAccountId ?? null;
    if (from && to && from.id === to.id) errors.push(err('toAccountId', 'حساب مبدأ و مقصد نباید یکی باشد.'));
    if (from) {
      tx.currency = from.currency;
      checkAmount(from.currency, tx.amount, 'amount', errors);
    }
    if (from && to) {
      tx.toCurrency = to.currency;
      if (from.currency === to.currency) {
        if (input.toAmount !== undefined && input.toAmount !== null && input.toAmount !== tx.amount) {
          errors.push(err('toAmount', 'در انتقال هم‌ارز، مبلغ مبدأ و مقصد باید برابر باشد.'));
        }
        tx.toAmount = tx.amount;
      } else if (input.toAmount === undefined || input.toAmount === null) {
        errors.push(err('toAmount', 'برای انتقال بین دو ارز مختلف، مبلغ دریافتی در حساب مقصد را وارد کنید.'));
      } else if (checkAmount(to.currency, input.toAmount, 'toAmount', errors)) {
        tx.toAmount = input.toAmount;
      }
    }
  } else {
    // debt_payment
    const acc = account(input.accountId, 'accountId');
    tx.accountId = input.accountId ?? null;
    const debt = byId(state.debts, input.debtId);
    if (!debt) errors.push(err('debtId', 'بدهی/طلب انتخاب‌شده وجود ندارد.'));
    tx.debtId = input.debtId ?? null;
    if (acc) {
      tx.currency = acc.currency;
      if (checkAmount(acc.currency, tx.amount, 'amount', errors) && debt) {
        if (debt.currency !== acc.currency) {
          errors.push(err('accountId', 'واحد پول حساب با واحد پول بدهی/طلب یکی نیست.'));
        } else {
          const remaining = debt.principal - debtPaid(state, debt.id, { excludeTxId });
          if (tx.amount > remaining) {
            errors.push(err('amount', `مبلغ از مانده‌ی بدهی/طلب (${M.formatAmount(debt.currency, remaining)}) بیشتر است.`));
          }
        }
      }
    }
  }
  return { tx, errors };
}

export function dupKey(t) {
  return [t.type, t.amount, t.date, t.accountId, t.fromAccountId, t.toAccountId, t.categoryId, t.debtId, normalizeFa(t.note)].join('|');
}

export function findDuplicate(state, candidate, { excludeTxId = null } = {}) {
  const key = dupKey(candidate);
  return state.transactions.find((t) => t.id !== excludeTxId && dupKey(t) === key) ?? null;
}

// requestId: شناسه‌ی یکتای یک «ثبت» در رابط کاربری؛ دوبار فشردن دکمه همان تراکنش را برمی‌گرداند
export function addTransaction(state, input, ctx = defaultCtx(), { allowDuplicate = false } = {}) {
  if (input.requestId) {
    const existing = state.transactions.find((t) => t.requestId === input.requestId);
    if (existing) return { state, transaction: existing, repeated: true };
  }
  const { tx, errors } = buildTransaction(state, input);
  if (errors.length) throw new ValidationError(errors);
  const dup = findDuplicate(state, tx);
  if (dup && !allowDuplicate) {
    throw new ValidationError('تراکنش مشابهی با همین مشخصات قبلاً ثبت شده است.', 'DUPLICATE', { existingId: dup.id });
  }
  const now = ctx.now();
  const transaction = {
    id: ctx.id(),
    ...tx,
    usd: usdFor(tx.type, tx.currency),
    requestId: input.requestId ?? null,
    createdAt: now,
    updatedAt: now,
  };
  return { state: put(state, 'transactions', [...state.transactions, transaction]), transaction, repeated: false };
}

export function updateTransaction(state, id, patch, ctx = defaultCtx(), { allowDuplicate = false } = {}) {
  const old = byId(state.transactions, id);
  if (!old) throw new ValidationError('تراکنش پیدا نشد.', 'NOT_FOUND');
  if (patch.type !== undefined && patch.type !== old.type) {
    const flip = ['income', 'expense'];
    if (!(flip.includes(patch.type) && flip.includes(old.type))) {
      throw new ValidationError([err('type', 'نوع این تراکنش قابل تغییر نیست؛ آن را حذف و دوباره ثبت کنید.')]);
    }
  }
  const merged = { ...old, ...patch };
  if (old.type === 'transfer' && patch.toAmount === undefined) {
    // در انتقال هم‌ارز، مبلغ مقصد همیشه مشتق از مبلغ مبدأ است و جدا ویرایش نمی‌شود
    const from = byId(state.accounts, merged.fromAccountId);
    const to = byId(state.accounts, merged.toAccountId);
    if (from && to && from.currency === to.currency) merged.toAmount = undefined;
  }
  const { tx, errors } = buildTransaction(state, merged, { excludeTxId: id });
  if (errors.length) throw new ValidationError(errors);
  const dup = findDuplicate(state, tx, { excludeTxId: id });
  if (dup && !allowDuplicate) {
    throw new ValidationError('تراکنش مشابهی با همین مشخصات قبلاً ثبت شده است.', 'DUPLICATE', { existingId: dup.id });
  }
  const now = ctx.now();
  const moneyChanged = tx.amount !== old.amount || tx.currency !== old.currency;
  const transaction = {
    ...old,
    ...tx,
    id: old.id,
    requestId: old.requestId ?? null,
    createdAt: old.createdAt,
    updatedAt: now,
    usd: moneyChanged ? invalidateUsdField(old.usd, tx.currency, now) : old.usd,
  };
  return { state: put(state, 'transactions', state.transactions.map((t) => (t.id === id ? transaction : t))), transaction };
}

export function deleteTransaction(state, id) {
  const old = byId(state.transactions, id);
  if (!old) throw new ValidationError('تراکنش پیدا نشد.', 'NOT_FOUND');
  return { state: put(state, 'transactions', state.transactions.filter((t) => t.id !== id)), removed: old };
}

export function queryTransactions(state, f = {}) {
  const text = f.text ? normalizeFa(f.text.trim()) : '';
  const catName = (id) => byId(state.categories, id)?.name ?? '';
  const accName = (id) => byId(state.accounts, id)?.name ?? '';
  let list = state.transactions.filter((t) => {
    if (f.from && t.date < f.from) return false;
    if (f.to && t.date > f.to) return false;
    if (f.types && !f.types.includes(t.type)) return false;
    if (f.type && t.type !== f.type) return false;
    if (f.accountId && ![t.accountId, t.fromAccountId, t.toAccountId].includes(f.accountId)) return false;
    if (f.categoryId && t.categoryId !== f.categoryId) return false;
    if (f.currency && t.currency !== f.currency) return false;
    if (f.minAmount !== undefined && f.minAmount !== null && t.amount < f.minAmount) return false;
    if (f.maxAmount !== undefined && f.maxAmount !== null && t.amount > f.maxAmount) return false;
    if (text) {
      const hay = normalizeFa(`${t.note} ${catName(t.categoryId)} ${accName(t.accountId)} ${accName(t.fromAccountId)} ${accName(t.toAccountId)}`);
      if (!hay.includes(text)) return false;
    }
    return true;
  });
  const sort = f.sort ?? 'date_desc';
  const cmpDate = (a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : a.createdAt < b.createdAt ? -1 : a.createdAt > b.createdAt ? 1 : a.id < b.id ? -1 : 1);
  list = [...list];
  if (sort === 'date_asc') list.sort(cmpDate);
  else if (sort === 'amount_desc') list.sort((a, b) => b.amount - a.amount || cmpDate(b, a));
  else if (sort === 'amount_asc') list.sort((a, b) => a.amount - b.amount || cmpDate(b, a));
  else list.sort((a, b) => cmpDate(b, a));
  return list;
}

// ---------- موجودی‌ها ----------

// اثر هر تراکنش روی حساب‌ها. انتقال: کم از مبدأ، اضافه به مقصد. پرداخت بدهی: بسته به جهت بدهی.
export function txEffects(state, tx) {
  switch (tx.type) {
    case 'income':
      return [{ accountId: tx.accountId, delta: tx.amount }];
    case 'expense':
      return [{ accountId: tx.accountId, delta: -tx.amount }];
    case 'transfer':
      return [
        { accountId: tx.fromAccountId, delta: -tx.amount },
        { accountId: tx.toAccountId, delta: tx.toAmount },
      ];
    case 'debt_payment': {
      const d = byId(state.debts, tx.debtId);
      if (!d) return [];
      return [{ accountId: tx.accountId, delta: d.direction === 'owe' ? -tx.amount : tx.amount }];
    }
    default:
      return [];
  }
}

// اگر هنگام ثبت بدهی/طلب، حسابی مشخص شده باشد، اصل مبلغ روی موجودی آن حساب اثر می‌گذارد
export function debtPrincipalEffects(debt) {
  if (!debt.accountId) return [];
  return [{ accountId: debt.accountId, delta: debt.direction === 'owe' ? debt.principal : -debt.principal, date: debt.date }];
}

export function allEffects(state) {
  const out = [];
  for (const t of state.transactions) for (const e of txEffects(state, t)) out.push({ ...e, date: t.date });
  for (const d of state.debts) out.push(...debtPrincipalEffects(d));
  return out;
}

export function accountBalance(state, accountId, { upTo = null } = {}) {
  const acc = byId(state.accounts, accountId);
  if (!acc) throw new ValidationError('حساب پیدا نشد.', 'NOT_FOUND');
  let total = acc.openingBalance;
  for (const e of allEffects(state)) {
    if (e.accountId !== accountId) continue;
    if (upTo && e.date > upTo) continue;
    total = M.safeAdd(total, e.delta);
  }
  return total;
}

export function accountBalances(state, { upTo = null } = {}) {
  const map = new Map(state.accounts.map((a) => [a.id, a.openingBalance]));
  for (const e of allEffects(state)) {
    if (upTo && e.date > upTo) continue;
    if (map.has(e.accountId)) map.set(e.accountId, M.safeAdd(map.get(e.accountId), e.delta));
  }
  return state.accounts.map((a) => ({ account: a, balance: map.get(a.id) }));
}

// جمع موجودی به تفکیک ارز؛ هیچ‌وقت ارزهای مختلف بدون تبدیل مشخص جمع نمی‌شوند
export function totalBalances(state, { includeArchived = false, upTo = null } = {}) {
  const totals = {};
  for (const { account, balance } of accountBalances(state, { upTo })) {
    if (account.archived && !includeArchived) continue;
    totals[account.currency] = M.safeAdd(totals[account.currency] ?? 0, balance);
  }
  return totals;
}

// مقایسه‌ی موجودی محاسبه‌شده با موجودی واقعی که کاربر وارد می‌کند
export function reconcile(state, accountId, actualBalance) {
  const acc = byId(state.accounts, accountId);
  if (!acc) throw new ValidationError('حساب پیدا نشد.', 'NOT_FOUND');
  const errors = [];
  if (!checkAmount(acc.currency, actualBalance, 'actualBalance', errors, { allowZero: true, allowNegative: true })) {
    throw new ValidationError(errors);
  }
  const computed = accountBalance(state, accountId);
  const difference = actualBalance - computed;
  return { currency: acc.currency, computed, actual: actualBalance, difference, status: difference === 0 ? 'match' : 'differs' };
}

// ---------- بدهی و طلب ----------
// direction: 'owe' = من بدهکارم، 'owed' = از دیگران طلب دارم

export function addDebt(state, input, ctx = defaultCtx()) {
  const errors = [];
  if (input.direction !== 'owe' && input.direction !== 'owed') errors.push(err('direction', 'نوع باید «بدهی» یا «طلب» باشد.'));
  const person = cleanName(input.person, 'person', 'نام طرف حساب', errors);
  const currency = input.currency ?? 'IRT';
  if (!M.CURRENCIES[currency]) errors.push(err('currency', 'واحد پول نامعتبر است.'));
  else checkAmount(currency, input.principal, 'principal', errors);
  const date = cleanDate(input.date, 'date', errors);
  let dueDate = null;
  if (input.dueDate !== undefined && input.dueDate !== null) {
    dueDate = cleanDate(input.dueDate, 'dueDate', errors);
    if (dueDate && date && dueDate < date) errors.push(err('dueDate', 'سررسید نمی‌تواند قبل از تاریخ ثبت باشد.'));
  }
  const note = cleanNote(input.note, errors);
  let accountId = null;
  if (input.accountId) {
    const a = byId(state.accounts, input.accountId);
    if (!a) errors.push(err('accountId', 'حساب انتخاب‌شده وجود ندارد.'));
    else if (a.archived) errors.push(err('accountId', 'حساب بایگانی شده است.'));
    else if (a.currency !== currency) errors.push(err('accountId', 'واحد پول حساب با بدهی/طلب یکی نیست.'));
    else accountId = a.id;
  }
  if (errors.length) throw new ValidationError(errors);
  const now = ctx.now();
  const debt = { id: ctx.id(), direction: input.direction, person, principal: input.principal, currency, date, dueDate, note, accountId, createdAt: now, updatedAt: now };
  return { state: put(state, 'debts', [...state.debts, debt]), debt };
}

export function updateDebt(state, id, patch, ctx = defaultCtx()) {
  const old = byId(state.debts, id);
  if (!old) throw new ValidationError('بدهی/طلب پیدا نشد.', 'NOT_FOUND');
  const errors = [];
  const next = { ...old };
  if (patch.person !== undefined) next.person = cleanName(patch.person, 'person', 'نام طرف حساب', errors);
  if (patch.note !== undefined) next.note = cleanNote(patch.note, errors);
  if (patch.dueDate !== undefined) {
    if (patch.dueDate === null) next.dueDate = null;
    else {
      next.dueDate = cleanDate(patch.dueDate, 'dueDate', errors);
      if (next.dueDate && next.date && next.dueDate < next.date) errors.push(err('dueDate', 'سررسید نمی‌تواند قبل از تاریخ ثبت باشد.'));
    }
  }
  if (patch.principal !== undefined) {
    if (checkAmount(old.currency, patch.principal, 'principal', errors)) {
      const paid = debtPaid(state, id);
      if (patch.principal < paid) errors.push(err('principal', `مبلغ کل نمی‌تواند کمتر از مجموع پرداخت‌شده (${M.formatAmount(old.currency, paid)}) باشد.`));
      else next.principal = patch.principal;
    }
  }
  if (errors.length) throw new ValidationError(errors);
  next.updatedAt = ctx.now();
  return { state: put(state, 'debts', state.debts.map((d) => (d.id === id ? next : d))), debt: next };
}

export function deleteDebt(state, id, { cascade = false } = {}) {
  if (!byId(state.debts, id)) throw new ValidationError('بدهی/طلب پیدا نشد.', 'NOT_FOUND');
  const payments = state.transactions.filter((t) => t.type === 'debt_payment' && t.debtId === id);
  if (payments.length > 0 && !cascade) {
    throw new ValidationError('این مورد پرداخت ثبت‌شده دارد؛ برای حذف، حذف پرداخت‌ها را هم تأیید کنید.', 'IN_USE', { payments: payments.length });
  }
  return {
    state: { ...state, debts: state.debts.filter((d) => d.id !== id), transactions: state.transactions.filter((t) => !(t.type === 'debt_payment' && t.debtId === id)) },
    removedPayments: payments.length,
  };
}

export function debtStatus(state, debtId, today = null) {
  const d = byId(state.debts, debtId);
  if (!d) throw new ValidationError('بدهی/طلب پیدا نشد.', 'NOT_FOUND');
  const paid = debtPaid(state, debtId);
  const remaining = d.principal - paid;
  let status = 'open';
  if (remaining === 0) status = 'settled';
  else if (today && d.dueDate && d.dueDate < today) status = 'overdue';
  return { debt: d, paid, remaining, status, progressBp: M.percentBp(paid, d.principal) };
}

export function debtTotals(state, today = null) {
  const out = { owe: {}, owed: {}, overdue: [] };
  for (const d of state.debts) {
    const s = debtStatus(state, d.id, today);
    out[d.direction][d.currency] = M.safeAdd(out[d.direction][d.currency] ?? 0, s.remaining);
    if (s.status === 'overdue') out.overdue.push(s);
  }
  return out;
}

// ---------- اهداف پس‌انداز ----------
// مشارکت‌های پس‌انداز فقط «تخصیص» هستند: نه هزینه حساب می‌شوند و نه موجودی حساب را تغییر می‌دهند.

export function addGoal(state, input, ctx = defaultCtx()) {
  const errors = [];
  const name = cleanName(input.name, 'name', 'نام هدف', errors);
  const currency = input.currency ?? 'IRT';
  if (!M.CURRENCIES[currency]) errors.push(err('currency', 'واحد پول نامعتبر است.'));
  else checkAmount(currency, input.targetAmount, 'targetAmount', errors);
  let targetDate = null;
  if (input.targetDate !== undefined && input.targetDate !== null) targetDate = cleanDate(input.targetDate, 'targetDate', errors);
  if (name && state.goals.some((g) => sameName(g.name, name))) errors.push(err('name', 'هدفی با این نام وجود دارد.'));
  if (errors.length) throw new ValidationError(errors);
  const now = ctx.now();
  const goal = { id: ctx.id(), name, currency, targetAmount: input.targetAmount, targetDate, contributions: [], createdAt: now, updatedAt: now };
  return { state: put(state, 'goals', [...state.goals, goal]), goal };
}

export function updateGoal(state, id, patch, ctx = defaultCtx()) {
  const old = byId(state.goals, id);
  if (!old) throw new ValidationError('هدف پیدا نشد.', 'NOT_FOUND');
  const errors = [];
  const next = { ...old };
  if (patch.name !== undefined) next.name = cleanName(patch.name, 'name', 'نام هدف', errors);
  if (patch.targetAmount !== undefined && checkAmount(old.currency, patch.targetAmount, 'targetAmount', errors)) next.targetAmount = patch.targetAmount;
  if (patch.targetDate !== undefined) next.targetDate = patch.targetDate === null ? null : cleanDate(patch.targetDate, 'targetDate', errors);
  if (next.name && state.goals.some((g) => g.id !== id && sameName(g.name, next.name))) errors.push(err('name', 'هدفی با این نام وجود دارد.'));
  if (errors.length) throw new ValidationError(errors);
  next.updatedAt = ctx.now();
  return { state: put(state, 'goals', state.goals.map((g) => (g.id === id ? next : g))), goal: next };
}

export function deleteGoal(state, id) {
  if (!byId(state.goals, id)) throw new ValidationError('هدف پیدا نشد.', 'NOT_FOUND');
  return { state: put(state, 'goals', state.goals.filter((g) => g.id !== id)) };
}

export function goalSaved(goal) {
  let saved = 0;
  for (const c of goal.contributions) saved = M.safeAdd(saved, c.kind === 'withdraw' ? -c.amount : c.amount);
  return saved;
}

export function addGoalContribution(state, goalId, input, ctx = defaultCtx()) {
  const goal = byId(state.goals, goalId);
  if (!goal) throw new ValidationError('هدف پیدا نشد.', 'NOT_FOUND');
  const errors = [];
  const kind = input.kind ?? 'add';
  if (kind !== 'add' && kind !== 'withdraw') errors.push(err('kind', 'نوع مشارکت نامعتبر است.'));
  checkAmount(goal.currency, input.amount, 'amount', errors);
  const date = cleanDate(input.date, 'date', errors);
  const note = cleanNote(input.note, errors);
  if (!errors.length && kind === 'withdraw' && input.amount > goalSaved(goal)) {
    errors.push(err('amount', 'مبلغ برداشت از مبلغ پس‌انداز شده بیشتر است.'));
  }
  if (errors.length) throw new ValidationError(errors);
  const contribution = { id: ctx.id(), kind, amount: input.amount, date, note };
  const next = { ...goal, contributions: [...goal.contributions, contribution], updatedAt: ctx.now() };
  return { state: put(state, 'goals', state.goals.map((g) => (g.id === goalId ? next : g))), goal: next, contribution };
}

export function removeGoalContribution(state, goalId, contributionId, ctx = defaultCtx()) {
  const goal = byId(state.goals, goalId);
  if (!goal) throw new ValidationError('هدف پیدا نشد.', 'NOT_FOUND');
  if (!goal.contributions.some((c) => c.id === contributionId)) throw new ValidationError('مشارکت پیدا نشد.', 'NOT_FOUND');
  const next = { ...goal, contributions: goal.contributions.filter((c) => c.id !== contributionId), updatedAt: ctx.now() };
  if (goalSaved(next) < 0) throw new ValidationError('حذف این مشارکت باعث منفی شدن پس‌انداز می‌شود.');
  return { state: put(state, 'goals', state.goals.map((g) => (g.id === goalId ? next : g))), goal: next };
}

export function goalProgress(goal, today = null) {
  const saved = goalSaved(goal);
  const remaining = Math.max(goal.targetAmount - saved, 0);
  const out = {
    goal,
    saved,
    remaining,
    progressBp: M.percentBp(Math.min(saved, goal.targetAmount), goal.targetAmount),
    reached: saved >= goal.targetAmount,
    daysLeft: null,
    overdue: false,
  };
  if (today && goal.targetDate) {
    out.daysLeft = J.diffDays(goal.targetDate, today);
    out.overdue = out.daysLeft < 0 && !out.reached;
  }
  return out;
}

// ---------- بودجه ----------
// هر بودجه نسخه‌دار است: تغییر سقف، نسخه‌ی قبلی را (با effectiveTo) می‌بندد و نسخه‌ی جدید می‌سازد.
// تراکنش‌ها هیچ‌وقت دست نمی‌خورند و بودجه‌ی گذشته با سقف همان زمان سنجیده می‌شود.
// categoryId = null یعنی بودجه‌ی کل هزینه‌ها.

export const BUDGET_PERIODS = Object.freeze(['daily', 'weekly', 'monthly']);

export function setBudget(state, input, ctx = defaultCtx()) {
  const errors = [];
  if (!BUDGET_PERIODS.includes(input.period)) errors.push(err('period', 'دوره‌ی بودجه نامعتبر است.'));
  const categoryId = input.categoryId ?? null;
  if (categoryId !== null) {
    const c = byId(state.categories, categoryId);
    if (!c) errors.push(err('categoryId', 'دسته‌بندی وجود ندارد.'));
    else if (c.kind !== 'expense') errors.push(err('categoryId', 'بودجه فقط برای دسته‌های هزینه تعریف می‌شود.'));
  }
  checkAmount('IRT', input.limit, 'limit', errors);
  const effectiveFrom = cleanDate(input.effectiveFrom, 'effectiveFrom', errors);
  const warnBp = input.warnBp ?? 8000;
  if (!Number.isInteger(warnBp) || warnBp < 1 || warnBp > 10000) errors.push(err('warnBp', 'آستانه‌ی هشدار نامعتبر است.'));
  if (errors.length) throw new ValidationError(errors);
  const sameKey = (b) => b.categoryId === categoryId && b.period === input.period;
  const active = state.budgets.find((b) => sameKey(b) && !b.effectiveTo);
  let budgets = state.budgets;
  if (active) {
    if (effectiveFrom <= active.effectiveFrom) {
      // هم‌روز یا قبل‌تر: همان نسخه به‌روزرسانی می‌شود
      budgets = budgets.filter((b) => b.id !== active.id);
    } else {
      budgets = budgets.map((b) => (b.id === active.id ? { ...b, effectiveTo: J.addDays(effectiveFrom, -1) } : b));
    }
  }
  const budget = { id: ctx.id(), categoryId, period: input.period, limit: input.limit, currency: 'IRT', warnBp, effectiveFrom, effectiveTo: null, createdAt: ctx.now() };
  return { state: put(state, 'budgets', [...budgets, budget]), budget };
}

export function removeBudget(state, id, today) {
  const b = byId(state.budgets, id);
  if (!b) throw new ValidationError('بودجه پیدا نشد.', 'NOT_FOUND');
  if (b.effectiveTo) return { state };
  const to = J.addDays(today, -1);
  if (to < b.effectiveFrom) return { state: put(state, 'budgets', state.budgets.filter((x) => x.id !== id)) };
  return { state: put(state, 'budgets', state.budgets.map((x) => (x.id === id ? { ...x, effectiveTo: to } : x))) };
}

export function budgetsActiveOn(state, date) {
  return state.budgets.filter((b) => b.effectiveFrom <= date && (!b.effectiveTo || b.effectiveTo >= date));
}
