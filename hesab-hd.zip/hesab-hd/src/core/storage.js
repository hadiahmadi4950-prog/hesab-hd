// حساب HD — ذخیره‌سازی ماندگار روی دستگاه
//
// - داده‌ها فقط روی همین دستگاه می‌مانند (IndexedDB)؛ هیچ‌چیز به سرور فرستاده نمی‌شود.
// - هر ذخیره «اتمیک» است: state جدید و نسخه‌ی قبلی در یک تراکنش نوشته می‌شوند؛ اگر چیزی شکست بخورد،
//   تراکنش لغو می‌شود و داده‌ی قبلی دست‌نخورده می‌ماند.
// - state در حافظه فقط پس از ذخیره‌ی موفق عوض می‌شود؛ شکست ذخیره به کاربر اعلام می‌شود و تغییری اعمال نمی‌شود.
// - اگر داده‌ی ذخیره‌شده خراب باشد: ابتدا از نسخه‌ی قبلی بازیابی می‌شود؛ اگر آن هم خراب بود، چیزی بازنویسی
//   نمی‌شود تا کاربر تصمیم بگیرد (نسخه‌ی خراب برای بررسی نگه داشته می‌شود).

import { createEmptyState } from './ledger.js';
import { parseState } from './validate.js';

export const DB_NAME = 'hesab-hd';
export const DB_VERSION = 1;
const KV = 'kv';

export class StorageError extends Error {
  constructor(code, message, cause) {
    super(message);
    this.name = 'StorageError';
    this.code = code;
    if (cause) this.cause = cause;
  }
}

// ---------- آداپتور حافظه (برای تست و محیط‌های بدون IndexedDB) ----------

export function createMemoryAdapter({ delayMs = 0 } = {}) {
  const data = new Map();
  const wait = () => (delayMs > 0 ? new Promise((r) => setTimeout(r, Math.random() * delayMs)) : Promise.resolve());
  const adapter = {
    kind: 'memory',
    saves: 0,
    failNext: null,
    async load() {
      await wait();
      return { main: data.get('state') ?? null, previous: data.get('previous') ?? null, meta: data.get('meta') ?? null };
    },
    async save(state, { rollPrevious = true, savedAt = new Date().toISOString() } = {}) {
      await wait();
      if (adapter.failNext) {
        const e = adapter.failNext;
        adapter.failNext = null;
        throw e;
      }
      const copy = structuredClone(state); // مثل IndexedDB، با شکست روی داده‌ی غیرقابل‌ذخیره
      if (rollPrevious && data.has('state')) data.set('previous', data.get('state'));
      data.set('state', copy);
      data.set('meta', { savedAt });
      adapter.saves += 1;
    },
    async stash(raw) {
      data.set('corrupt', structuredClone(raw ?? null));
    },
    async readStash() {
      return data.get('corrupt') ?? null;
    },
    async clear() {
      data.clear();
    },
    // فقط برای تست: نوشتن مستقیم
    _raw: data,
  };
  return adapter;
}

// ---------- آداپتور IndexedDB ----------

function classify(err) {
  const name = err?.name ?? '';
  if (name === 'QuotaExceededError') return new StorageError('QUOTA', 'فضای ذخیره‌سازی دستگاه پر است؛ تغییر ذخیره نشد. جای خالی کنید یا از اطلاعات پشتیبان بگیرید.', err);
  if (name === 'DataCloneError') return new StorageError('SERIALIZE', 'داده‌ی این تغییر قابل ذخیره نبود و ذخیره نشد.', err);
  if (name === 'InvalidStateError' || name === 'SecurityError') return new StorageError('UNAVAILABLE', 'ذخیره‌سازی مرورگر در دسترس نیست (حالت خصوصی یا بسته‌شدن پایگاه داده).', err);
  return new StorageError('SAVE_FAILED', 'ذخیره‌سازی ناموفق بود و تغییر اعمال نشد.', err);
}

export function createIndexedDBAdapter({ idb = globalThis.indexedDB, dbName = DB_NAME } = {}) {
  if (!idb) throw new StorageError('UNAVAILABLE', 'IndexedDB در این محیط وجود ندارد.');
  let dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      let req;
      try {
        req = idb.open(dbName, DB_VERSION);
      } catch (e) {
        reject(classify(e));
        return;
      }
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(KV)) db.createObjectStore(KV);
      };
      req.onsuccess = () => {
        const db = req.result;
        db.onversionchange = () => {
          db.close();
          dbPromise = null;
        };
        db.onclose = () => {
          dbPromise = null;
        };
        resolve(db);
      };
      req.onerror = () => reject(classify(req.error));
      req.onblocked = () => reject(new StorageError('BLOCKED', 'باز کردن پایگاه داده مسدود شد؛ سایر پنجره‌های برنامه را ببندید.'));
    }).catch((e) => {
      dbPromise = null;
      throw e;
    });
    return dbPromise;
  }

  // اجرای یک تراکنش و منتظر ماندن برای «complete» (نه فقط success درخواست‌ها)
  async function run(mode, work) {
    const db = await open();
    return new Promise((resolve, reject) => {
      let tx;
      let result;
      let settled = false;
      const fail = (err) => {
        if (settled) return;
        settled = true;
        reject(classify(err));
      };
      try {
        tx = db.transaction(KV, mode);
        tx.oncomplete = () => {
          if (settled) return;
          settled = true;
          resolve(result);
        };
        tx.onerror = () => fail(tx.error);
        tx.onabort = () => fail(tx.error ?? new Error('تراکنش لغو شد'));
        result = work(tx.objectStore(KV), tx);
      } catch (e) {
        try {
          tx?.abort();
        } catch {
          /* تراکنش از قبل بسته شده */
        }
        fail(e);
      }
    });
  }

  const read = (store, key) =>
    new Promise((resolve, reject) => {
      const r = store.get(key);
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });

  return {
    kind: 'indexeddb',
    async load() {
      const db = await open();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(KV, 'readonly');
        const store = tx.objectStore(KV);
        const out = {};
        for (const [k, key] of [['main', 'state'], ['previous', 'previous'], ['meta', 'meta']]) {
          const r = store.get(key);
          r.onsuccess = () => {
            out[k] = r.result ?? null;
          };
        }
        tx.oncomplete = () => resolve(out);
        tx.onerror = () => reject(classify(tx.error));
        tx.onabort = () => reject(classify(tx.error));
      });
    },
    async save(state, { rollPrevious = true, savedAt = new Date().toISOString() } = {}) {
      // پیش‌بررسی: داده‌ی غیرقابل‌ذخیره قبل از شروع تراکنش شناسایی شود
      try {
        structuredClone(state);
      } catch (e) {
        throw classify(e);
      }
      await run('readwrite', (store) => {
        const getReq = store.get('state');
        getReq.onsuccess = () => {
          const old = getReq.result;
          if (rollPrevious && old !== undefined) store.put(old, 'previous');
          store.put(state, 'state');
          store.put({ savedAt }, 'meta');
        };
      });
    },
    async stash(raw) {
      await run('readwrite', (store) => {
        store.put(raw ?? null, 'corrupt');
      });
    },
    async readStash() {
      const db = await open();
      const tx = db.transaction(KV, 'readonly');
      return (await read(tx.objectStore(KV), 'corrupt')) ?? null;
    },
    async clear() {
      await run('readwrite', (store) => {
        store.clear();
      });
    },
    async close() {
      if (dbPromise) {
        const db = await dbPromise;
        db.close();
        dbPromise = null;
      }
    },
  };
}

// ---------- فروشگاه state ----------
// status: 'empty' | 'ok' | 'recovered' | 'corrupt'

export async function openStore({ adapter, validateOnCommit = false, now = () => new Date().toISOString() } = {}) {
  if (!adapter) throw new StorageError('NO_ADAPTER', 'آداپتور ذخیره‌سازی مشخص نشده است.');
  const loaded = await adapter.load();
  let state;
  let status;
  let recoveredNote = null;
  let rollPrevious = true;

  const tryParse = (raw) => (raw === null || raw === undefined ? null : parseState(raw));
  const main = tryParse(loaded.main);
  if (loaded.main === null && loaded.previous === null) {
    state = createEmptyState();
    status = 'empty';
  } else if (main?.ok) {
    state = main.state;
    status = 'ok';
  } else {
    const prev = tryParse(loaded.previous);
    if (prev?.ok) {
      state = prev.state;
      status = 'recovered';
      recoveredNote = 'اطلاعات اصلی ناقص یا خراب بود و از آخرین نسخه‌ی سالم قبلی بازیابی شد؛ ممکن است آخرین تغییرِ ثبت‌نشده از دست رفته باشد.';
      rollPrevious = false; // نسخه‌ی قبلی سالم است؛ با داده‌ی خراب اصلی جایگزین نشود
      await adapter.stash(loaded.main);
    } else {
      state = createEmptyState();
      status = 'corrupt';
      await adapter.stash(loaded.main ?? loaded.previous);
    }
  }

  const listeners = new Set();
  let queue = Promise.resolve();
  const store = {
    get state() {
      return state;
    },
    get status() {
      return status;
    },
    get recoveredNote() {
      return recoveredNote;
    },
    get savedAt() {
      return loaded.meta?.savedAt ?? null;
    },
    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },
    // updater(state) → state جدید یا { state, ...نتیجه }؛ فقط پس از ذخیره‌ی موفق اعمال می‌شود
    commit(updater) {
      const run = async () => {
        if (status === 'corrupt') {
          throw new StorageError('CORRUPT', 'اطلاعات ذخیره‌شده خراب است. ابتدا نحوه‌ی ادامه را انتخاب کنید (شروع از نو یا بازیابی از فایل پشتیبان).');
        }
        const out = updater(state); // خطای اعتبارسنجی همین‌جا به بالا می‌رسد و چیزی ذخیره نمی‌شود
        const next = out && typeof out === 'object' && out.state && Array.isArray(out.state.transactions) ? out.state : out;
        if (!next || typeof next !== 'object' || !Array.isArray(next.transactions)) {
          throw new StorageError('INVALID_STATE', 'تغییر درخواستی state معتبری نساخت.');
        }
        if (validateOnCommit) {
          const check = parseState(JSON.parse(JSON.stringify(next)));
          if (!check.ok) throw new StorageError('INVALID_STATE', `تغییر باعث ناسازگاری داده می‌شود و ذخیره نشد: ${check.errors[0]?.message ?? ''}`);
        }
        try {
          await adapter.save(next, { rollPrevious, savedAt: now() });
        } catch (e) {
          throw e instanceof StorageError ? e : classify(e);
        }
        rollPrevious = true;
        state = next;
        if (status === 'empty' || status === 'recovered') status = status === 'empty' ? 'ok' : 'ok';
        for (const fn of [...listeners]) {
          try {
            fn(state);
          } catch {
            /* خطای شنونده نباید ذخیره را خراب کند */
          }
        }
        return out;
      };
      const p = queue.then(run, run);
      queue = p.catch(() => {});
      return p;
    },
    // خروج از وضعیت خراب: فقط با انتخاب صریح کاربر
    async resolveCorruption({ action, state: restored } = {}) {
      if (status !== 'corrupt') return;
      if (action === 'startFresh') {
        await adapter.save(createEmptyState(), { rollPrevious: false, savedAt: now() });
        state = createEmptyState();
      } else if (action === 'restore') {
        const check = parseState(JSON.parse(JSON.stringify(restored ?? null)));
        if (!check.ok) throw new StorageError('INVALID_STATE', 'داده‌ی بازیابی نامعتبر است.');
        await adapter.save(check.state, { rollPrevious: false, savedAt: now() });
        state = check.state;
      } else {
        throw new StorageError('BAD_ACTION', 'انتخاب نامعتبر است.');
      }
      status = 'ok';
      for (const fn of [...listeners]) fn(state);
    },
    async corruptedRaw() {
      return adapter.readStash();
    },
  };
  return store;
}

// درخواست «ماندگاری»: مرورگر داده‌ی سایت را هنگام کمبود فضا خودکار پاک نمی‌کند (در صورت پشتیبانی)
export async function requestPersistence(nav = globalThis.navigator) {
  try {
    if (nav?.storage?.persisted && (await nav.storage.persisted())) return true;
    if (nav?.storage?.persist) return await nav.storage.persist();
  } catch {
    return null;
  }
  return null;
}

export async function storageEstimate(nav = globalThis.navigator) {
  try {
    if (!nav?.storage?.estimate) return null;
    const { usage, quota } = await nav.storage.estimate();
    return { usage: usage ?? null, quota: quota ?? null };
  } catch {
    return null;
  }
}
