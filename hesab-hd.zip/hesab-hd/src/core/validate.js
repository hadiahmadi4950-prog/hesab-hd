// حساب HD — اعتبارسنجی و پاک‌سازی ساختار کامل داده (state)
//
// هم هنگام بارگذاری از حافظه و هم هنگام ورود فایل پشتیبان استفاده می‌شود.
// parseState هر ورودی ناشناخته را «فقط با فیلدهای مجاز» بازسازی می‌کند (whitelist) و اگر حتی یک
// ناسازگاری پیدا کند، state را برنمی‌گرداند؛ پس فایل خراب هیچ‌وقت جای داده‌ی سالم نمی‌نشیند.

import * as J from './jalali.js';
import * as M from './money.js';
import { ACCOUNT_TYPES, BUDGET_PERIODS, DATE_MAX_YEAR, DATE_MIN_YEAR, MAX_NAME_LENGTH, MAX_NOTE_LENGTH, STATE_VERSION, TX_TYPES, normalizeFa } from './ledger.js';
import { USD_STATUS, createFxState } from './fx.js';

export const LIMITS = Object.freeze({ accounts: 200, categories: 500, transactions: 200_000, budgets: 5_000, goals: 1_000, debts: 10_000, contributions: 50_000, history: 100 });
const MAX_ERRORS = 50;

const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const isStr = (v, max = 200) => typeof v === 'string' && v.length <= max;
const isId = (v) => typeof v === 'string' && v.length >= 1 && v.length <= 100 && !/[\u0000-\u001f]/.test(v);
const isIso = (v) => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(v) && Number.isFinite(Date.parse(v));

function dateOk(v) {
  if (typeof v !== 'string') return false;
  const p = J.parseDate(v);
  if (!p || J.formatDate(p) !== v) return false;
  return p.jy >= DATE_MIN_YEAR && p.jy <= DATE_MAX_YEAR;
}

class Collector {
  constructor() {
    this.errors = [];
    this.total = 0;
  }

  add(path, message) {
    this.total += 1;
    if (this.errors.length < MAX_ERRORS) this.errors.push({ path, message });
  }
}

const label = { accounts: 'حساب', categories: 'دسته', transactions: 'تراکنش', budgets: 'بودجه', goals: 'هدف', debts: 'بدهی/طلب', contributions: 'مشارکت' };

function rateOk(r) {
  return isObj(r) && M.isValidRate(r.value) && isIso(r.at) && isStr(r.source, 100) && r.source.trim() !== '' && typeof r.manual === 'boolean';
}

function parseUsdField(t, c, at) {
  const u = t.usd;
  const expected = t.type === 'income' || t.type === 'expense' ? (t.currency === 'USD' ? USD_STATUS.NOT_APPLICABLE : null) : USD_STATUS.NOT_APPLICABLE;
  if (!isObj(u) || !Object.values(USD_STATUS).includes(u.status)) {
    c.add(at, 'وضعیت معادل دلاری نامعتبر است.');
    return { status: USD_STATUS.PENDING };
  }
  if (expected && u.status !== expected) c.add(at, 'وضعیت معادل دلاری با نوع تراکنش هم‌خوان نیست.');
  if (!expected && u.status === USD_STATUS.NOT_APPLICABLE) c.add(at, 'تراکنش تومانی نمی‌تواند «بدون نیاز به معادل دلاری» باشد.');
  const out = { status: u.status };
  const history = [];
  if (u.history !== undefined) {
    if (!Array.isArray(u.history) || u.history.length > LIMITS.history) c.add(at, 'تاریخچه‌ی معادل دلاری نامعتبر است.');
    else {
      for (const h of u.history) {
        if (isObj(h) && Number.isSafeInteger(h.cents) && M.isValidRate(h.rate) && isIso(h.rateAt) && isStr(h.source, 100) && typeof h.manual === 'boolean' && isIso(h.computedAt) && isIso(h.replacedAt)) {
          history.push({ cents: h.cents, rate: h.rate, rateAt: h.rateAt, source: h.source, manual: h.manual, computedAt: h.computedAt, replacedAt: h.replacedAt });
        } else c.add(at, 'یکی از ردیف‌های تاریخچه‌ی معادل دلاری نامعتبر است.');
      }
    }
  }
  if (u.status === USD_STATUS.DONE) {
    const ok = Number.isSafeInteger(u.cents) && u.cents >= 0 && rateOk({ value: u.rate, at: u.rateAt, source: u.source, manual: u.manual }) && isIso(u.computedAt);
    if (!ok) c.add(at, 'معادل دلاری محاسبه‌شده ناقص یا نامعتبر است.');
    else {
      if (t.currency === 'IRT' && Number.isSafeInteger(t.amount) && M.isValidAmount('IRT', t.amount) && u.cents !== M.tomanToUsdCents(t.amount, u.rate)) {
        c.add(at, 'معادل دلاری با مبلغ و نرخ ثبت‌شده هم‌خوان نیست.');
      }
      Object.assign(out, { cents: u.cents, rate: u.rate, rateAt: u.rateAt, source: u.source, manual: u.manual, computedAt: u.computedAt });
    }
  }
  if (history.length > 0 || u.history !== undefined) out.history = history;
  return out;
}

// خروجی: { ok, state, errors, errorCount }
export function parseState(raw) {
  const c = new Collector();
  const fail = () => ({ ok: false, state: null, errors: c.errors, errorCount: c.total });
  if (!isObj(raw)) {
    c.add('state', 'ساختار داده نامعتبر است.');
    return fail();
  }
  if (!Number.isInteger(raw.version) || raw.version < 1) {
    c.add('version', 'نسخه‌ی داده مشخص یا معتبر نیست.');
    return fail();
  }
  if (raw.version > STATE_VERSION) {
    c.add('version', 'این داده با نسخه‌ی جدیدتری از برنامه ساخته شده و در این نسخه خوانده نمی‌شود.');
    return fail();
  }
  for (const key of ['accounts', 'categories', 'transactions', 'budgets', 'goals', 'debts']) {
    if (!Array.isArray(raw[key])) c.add(key, `بخش «${label[key]}» وجود ندارد یا فهرست نیست.`);
    else if (raw[key].length > LIMITS[key]) c.add(key, `تعداد ${label[key]}‌ها بیش از حد مجاز است.`);
  }
  if (c.total > 0) return fail();

  const out = { version: STATE_VERSION, accounts: [], categories: [], transactions: [], budgets: [], goals: [], debts: [], fx: createFxState() };

  // ----- حساب‌ها
  const accById = new Map();
  raw.accounts.forEach((a, i) => {
    const at = `accounts[${i}]`;
    const name = isObj(a) && typeof a.name === 'string' ? a.name.trim() : '';
    if (!isObj(a)) return c.add(at, `${label.accounts} ${i + 1}: ساختار نامعتبر است.`);
    const p = `${label.accounts} ${i + 1}`;
    if (!isId(a.id)) c.add(at, `${p}: شناسه نامعتبر است.`);
    else if (accById.has(a.id)) c.add(at, `${p}: شناسه‌ی تکراری.`);
    if (name === '' || name.length > MAX_NAME_LENGTH) c.add(at, `${p}: نام نامعتبر است.`);
    if (!ACCOUNT_TYPES.includes(a.type)) c.add(at, `${p}: نوع حساب نامعتبر است.`);
    if (!M.CURRENCIES[a.currency]) c.add(at, `${p}: واحد پول نامعتبر است.`);
    else if (!(Number.isSafeInteger(a.openingBalance) && M.isValidAmount(a.currency, a.openingBalance))) c.add(at, `${p}: موجودی اولیه نامعتبر است.`);
    if (typeof a.archived !== 'boolean') c.add(at, `${p}: وضعیت بایگانی نامعتبر است.`);
    if (!isIso(a.createdAt) || !isIso(a.updatedAt)) c.add(at, `${p}: زمان ایجاد/ویرایش نامعتبر است.`);
    const clean = { id: a.id, name, type: a.type, currency: a.currency, openingBalance: a.openingBalance, archived: a.archived === true, createdAt: a.createdAt, updatedAt: a.updatedAt };
    if (isId(a.id)) accById.set(a.id, clean);
    out.accounts.push(clean);
  });
  const activeNames = new Set();
  for (const a of out.accounts) {
    if (a.archived) continue;
    const k = normalizeFa(a.name);
    if (activeNames.has(k)) c.add('accounts', `نام حساب «${a.name}» تکراری است.`);
    activeNames.add(k);
  }

  // ----- دسته‌ها
  const catById = new Map();
  const catNames = new Set();
  raw.categories.forEach((x, i) => {
    const at = `categories[${i}]`;
    const p = `${label.categories} ${i + 1}`;
    if (!isObj(x)) return c.add(at, `${p}: ساختار نامعتبر است.`);
    const name = typeof x.name === 'string' ? x.name.trim() : '';
    if (!isId(x.id)) c.add(at, `${p}: شناسه نامعتبر است.`);
    else if (catById.has(x.id)) c.add(at, `${p}: شناسه‌ی تکراری.`);
    if (name === '' || name.length > MAX_NAME_LENGTH) c.add(at, `${p}: نام نامعتبر است.`);
    if (x.kind !== 'income' && x.kind !== 'expense') c.add(at, `${p}: نوع دسته نامعتبر است.`);
    if (typeof x.color !== 'string' || !/^#[0-9a-fA-F]{6}$/.test(x.color)) c.add(at, `${p}: رنگ نامعتبر است.`);
    if (typeof x.icon !== 'string' || x.icon.length === 0 || x.icon.length > 8) c.add(at, `${p}: آیکون نامعتبر است.`);
    const key = `${x.kind}|${normalizeFa(name)}`;
    if (catNames.has(key)) c.add(at, `${p}: نام دسته‌ی تکراری.`);
    catNames.add(key);
    const clean = { id: x.id, name, kind: x.kind, icon: x.icon, color: x.color, builtin: x.builtin === true };
    if (isId(x.id)) catById.set(x.id, clean);
    out.categories.push(clean);
  });

  // ----- بدهی و طلب
  const debtById = new Map();
  raw.debts.forEach((d, i) => {
    const at = `debts[${i}]`;
    const p = `${label.debts} ${i + 1}`;
    if (!isObj(d)) return c.add(at, `${p}: ساختار نامعتبر است.`);
    if (!isId(d.id)) c.add(at, `${p}: شناسه نامعتبر است.`);
    else if (debtById.has(d.id)) c.add(at, `${p}: شناسه‌ی تکراری.`);
    if (d.direction !== 'owe' && d.direction !== 'owed') c.add(at, `${p}: نوع نامعتبر است.`);
    const person = typeof d.person === 'string' ? d.person.trim() : '';
    if (person === '' || person.length > MAX_NAME_LENGTH) c.add(at, `${p}: نام طرف حساب نامعتبر است.`);
    if (!M.CURRENCIES[d.currency]) c.add(at, `${p}: واحد پول نامعتبر است.`);
    else if (!(Number.isSafeInteger(d.principal) && d.principal > 0 && M.isValidAmount(d.currency, d.principal))) c.add(at, `${p}: مبلغ نامعتبر است.`);
    if (!dateOk(d.date)) c.add(at, `${p}: تاریخ نامعتبر است.`);
    if (d.dueDate !== null && d.dueDate !== undefined && (!dateOk(d.dueDate) || d.dueDate < d.date)) c.add(at, `${p}: سررسید نامعتبر است.`);
    if (d.note !== undefined && d.note !== '' && !isStr(d.note, MAX_NOTE_LENGTH)) c.add(at, `${p}: یادداشت نامعتبر است.`);
    if (d.accountId !== null && d.accountId !== undefined) {
      const a = accById.get(d.accountId);
      if (!a) c.add(at, `${p}: حساب مرتبط وجود ندارد.`);
      else if (a.currency !== d.currency) c.add(at, `${p}: واحد پول حساب با بدهی/طلب یکی نیست.`);
    }
    if (!isIso(d.createdAt) || !isIso(d.updatedAt)) c.add(at, `${p}: زمان ایجاد/ویرایش نامعتبر است.`);
    const clean = { id: d.id, direction: d.direction, person, principal: d.principal, currency: d.currency, date: d.date, dueDate: d.dueDate ?? null, note: d.note ?? '', accountId: d.accountId ?? null, createdAt: d.createdAt, updatedAt: d.updatedAt };
    if (isId(d.id)) debtById.set(d.id, clean);
    out.debts.push(clean);
  });

  // ----- تراکنش‌ها
  const txIds = new Set();
  const paidByDebt = new Map();
  raw.transactions.forEach((t, i) => {
    const at = `transactions[${i}]`;
    const p = `${label.transactions} ${i + 1}`;
    if (!isObj(t)) return c.add(at, `${p}: ساختار نامعتبر است.`);
    if (!isId(t.id)) c.add(at, `${p}: شناسه نامعتبر است.`);
    else if (txIds.has(t.id)) c.add(at, `${p}: شناسه‌ی تکراری.`);
    else txIds.add(t.id);
    if (!TX_TYPES.includes(t.type)) {
      c.add(at, `${p}: نوع تراکنش نامعتبر است.`);
      return;
    }
    if (!dateOk(t.date)) c.add(at, `${p}: تاریخ نامعتبر است.`);
    if (t.note !== undefined && t.note !== '' && !isStr(t.note, MAX_NOTE_LENGTH)) c.add(at, `${p}: یادداشت نامعتبر است.`);
    if (t.method !== null && t.method !== undefined && !isStr(t.method, 40)) c.add(at, `${p}: روش پرداخت نامعتبر است.`);
    if (t.requestId !== null && t.requestId !== undefined && !isId(t.requestId)) c.add(at, `${p}: شناسه‌ی درخواست نامعتبر است.`);
    if (!isIso(t.createdAt) || !isIso(t.updatedAt)) c.add(at, `${p}: زمان ایجاد/ویرایش نامعتبر است.`);
    const clean = {
      id: t.id, type: t.type, amount: t.amount, currency: t.currency, date: t.date, note: typeof t.note === 'string' ? t.note : '', method: t.method ?? null,
      accountId: null, fromAccountId: null, toAccountId: null, toAmount: null, categoryId: null, debtId: null, requestId: t.requestId ?? null, createdAt: t.createdAt, updatedAt: t.updatedAt,
    };
    const amountOk = (cur, v) => Number.isSafeInteger(v) && v > 0 && M.isValidAmount(cur, v);
    if (t.type === 'income' || t.type === 'expense' || t.type === 'debt_payment') {
      const a = accById.get(t.accountId);
      if (!a) c.add(at, `${p}: حساب وجود ندارد.`);
      else {
        clean.accountId = t.accountId;
        if (t.currency !== a.currency) c.add(at, `${p}: واحد پول تراکنش با حساب یکی نیست.`);
        if (!amountOk(a.currency, t.amount)) c.add(at, `${p}: مبلغ نامعتبر است.`);
      }
      if (t.type !== 'debt_payment') {
        const cat = catById.get(t.categoryId);
        if (!cat) c.add(at, `${p}: دسته‌بندی وجود ندارد.`);
        else if (cat.kind !== t.type) c.add(at, `${p}: نوع دسته با نوع تراکنش هم‌خوان نیست.`);
        else clean.categoryId = t.categoryId;
      } else {
        const d = debtById.get(t.debtId);
        if (!d) c.add(at, `${p}: بدهی/طلب وجود ندارد.`);
        else {
          clean.debtId = t.debtId;
          if (a && d.currency !== a.currency) c.add(at, `${p}: واحد پول بدهی/طلب با حساب یکی نیست.`);
          if (Number.isSafeInteger(t.amount) && t.amount > 0) paidByDebt.set(d.id, (paidByDebt.get(d.id) ?? 0) + t.amount);
        }
      }
    } else {
      const from = accById.get(t.fromAccountId);
      const to = accById.get(t.toAccountId);
      if (!from) c.add(at, `${p}: حساب مبدأ وجود ندارد.`);
      if (!to) c.add(at, `${p}: حساب مقصد وجود ندارد.`);
      if (from && to) {
        clean.fromAccountId = t.fromAccountId;
        clean.toAccountId = t.toAccountId;
        if (from.id === to.id) c.add(at, `${p}: حساب مبدأ و مقصد یکی است.`);
        if (t.currency !== from.currency) c.add(at, `${p}: واحد پول انتقال با حساب مبدأ یکی نیست.`);
        if (t.toCurrency !== to.currency) c.add(at, `${p}: واحد پول مقصد با حساب مقصد یکی نیست.`);
        if (!amountOk(from.currency, t.amount)) c.add(at, `${p}: مبلغ نامعتبر است.`);
        if (!amountOk(to.currency, t.toAmount)) c.add(at, `${p}: مبلغ مقصد نامعتبر است.`);
        else if (from.currency === to.currency && t.toAmount !== t.amount) c.add(at, `${p}: در انتقال هم‌ارز مبلغ مبدأ و مقصد باید برابر باشد.`);
        clean.toAmount = t.toAmount;
        clean.toCurrency = t.toCurrency;
      }
    }
    clean.amount = t.amount;
    clean.currency = t.currency;
    clean.usd = parseUsdField(t, c, at);
    out.transactions.push(clean);
  });
  for (const [id, paid] of paidByDebt) {
    const d = debtById.get(id);
    if (d && paid > d.principal) c.add('debts', `مجموع پرداخت‌های «${d.person}» از مبلغ بدهی/طلب بیشتر است.`);
  }

  // ----- بودجه‌ها
  const budgetIds = new Set();
  raw.budgets.forEach((b, i) => {
    const at = `budgets[${i}]`;
    const p = `${label.budgets} ${i + 1}`;
    if (!isObj(b)) return c.add(at, `${p}: ساختار نامعتبر است.`);
    if (!isId(b.id)) c.add(at, `${p}: شناسه نامعتبر است.`);
    else if (budgetIds.has(b.id)) c.add(at, `${p}: شناسه‌ی تکراری.`);
    budgetIds.add(b.id);
    if (!BUDGET_PERIODS.includes(b.period)) c.add(at, `${p}: دوره نامعتبر است.`);
    if (b.categoryId !== null && b.categoryId !== undefined && !catById.has(b.categoryId) && b.categoryRemoved !== true) c.add(at, `${p}: دسته‌بندی وجود ندارد.`);
    if (b.categoryId && catById.get(b.categoryId)?.kind === 'income') c.add(at, `${p}: بودجه برای دسته‌ی درآمد معنا ندارد.`);
    if (!(Number.isSafeInteger(b.limit) && b.limit > 0 && M.isValidAmount('IRT', b.limit))) c.add(at, `${p}: سقف نامعتبر است.`);
    if (b.currency !== 'IRT') c.add(at, `${p}: واحد پول بودجه باید تومان باشد.`);
    if (!Number.isInteger(b.warnBp) || b.warnBp < 1 || b.warnBp > 10000) c.add(at, `${p}: آستانه‌ی هشدار نامعتبر است.`);
    if (!dateOk(b.effectiveFrom)) c.add(at, `${p}: تاریخ شروع نامعتبر است.`);
    if (b.effectiveTo !== null && b.effectiveTo !== undefined && (!dateOk(b.effectiveTo) || b.effectiveTo < b.effectiveFrom)) c.add(at, `${p}: تاریخ پایان نامعتبر است.`);
    if (!isIso(b.createdAt)) c.add(at, `${p}: زمان ایجاد نامعتبر است.`);
    const clean = { id: b.id, categoryId: b.categoryId ?? null, period: b.period, limit: b.limit, currency: 'IRT', warnBp: b.warnBp, effectiveFrom: b.effectiveFrom, effectiveTo: b.effectiveTo ?? null, createdAt: b.createdAt };
    if (b.categoryRemoved === true) clean.categoryRemoved = true;
    out.budgets.push(clean);
  });

  // ----- اهداف
  const goalIds = new Set();
  const goalNames = new Set();
  raw.goals.forEach((g, i) => {
    const at = `goals[${i}]`;
    const p = `${label.goals} ${i + 1}`;
    if (!isObj(g)) return c.add(at, `${p}: ساختار نامعتبر است.`);
    if (!isId(g.id)) c.add(at, `${p}: شناسه نامعتبر است.`);
    else if (goalIds.has(g.id)) c.add(at, `${p}: شناسه‌ی تکراری.`);
    goalIds.add(g.id);
    const name = typeof g.name === 'string' ? g.name.trim() : '';
    if (name === '' || name.length > MAX_NAME_LENGTH) c.add(at, `${p}: نام نامعتبر است.`);
    if (goalNames.has(normalizeFa(name))) c.add(at, `${p}: نام هدف تکراری است.`);
    goalNames.add(normalizeFa(name));
    if (!M.CURRENCIES[g.currency]) c.add(at, `${p}: واحد پول نامعتبر است.`);
    else if (!(Number.isSafeInteger(g.targetAmount) && g.targetAmount > 0 && M.isValidAmount(g.currency, g.targetAmount))) c.add(at, `${p}: مبلغ هدف نامعتبر است.`);
    if (g.targetDate !== null && g.targetDate !== undefined && !dateOk(g.targetDate)) c.add(at, `${p}: تاریخ هدف نامعتبر است.`);
    if (!isIso(g.createdAt) || !isIso(g.updatedAt)) c.add(at, `${p}: زمان ایجاد/ویرایش نامعتبر است.`);
    const contributions = [];
    if (!Array.isArray(g.contributions) || g.contributions.length > LIMITS.contributions) c.add(at, `${p}: فهرست مشارکت‌ها نامعتبر است.`);
    else {
      const ids = new Set();
      let saved = 0;
      for (const k of g.contributions) {
        const ok = isObj(k) && isId(k.id) && !ids.has(k.id) && (k.kind === 'add' || k.kind === 'withdraw') && M.CURRENCIES[g.currency] && Number.isSafeInteger(k.amount) && k.amount > 0 && M.isValidAmount(g.currency, k.amount) && dateOk(k.date);
        if (!ok) {
          c.add(at, `${p}: یکی از مشارکت‌ها نامعتبر یا تکراری است.`);
          continue;
        }
        ids.add(k.id);
        saved += k.kind === 'withdraw' ? -k.amount : k.amount;
        contributions.push({ id: k.id, kind: k.kind, amount: k.amount, date: k.date, note: typeof k.note === 'string' ? k.note : '' });
      }
      if (saved < 0) c.add(at, `${p}: مبلغ پس‌انداز شده منفی می‌شود.`);
    }
    out.goals.push({ id: g.id, name, currency: g.currency, targetAmount: g.targetAmount, targetDate: g.targetDate ?? null, contributions, createdAt: g.createdAt, updatedAt: g.updatedAt });
  });

  // ----- وضعیت نرخ دلار (اختیاری)
  if (raw.fx !== undefined && raw.fx !== null) {
    const f = raw.fx;
    if (!isObj(f)) c.add('fx', 'وضعیت نرخ دلار نامعتبر است.');
    else {
      const fx = createFxState();
      if (f.lastRate !== null && f.lastRate !== undefined) {
        if (rateOk(f.lastRate)) fx.lastRate = { value: f.lastRate.value, at: f.lastRate.at, source: f.lastRate.source, manual: f.lastRate.manual };
        else c.add('fx', 'آخرین نرخ ذخیره‌شده نامعتبر است.');
      }
      if (f.lastError !== null && f.lastError !== undefined) {
        if (isObj(f.lastError) && isIso(f.lastError.at) && isStr(f.lastError.message, 300)) fx.lastError = { at: f.lastError.at, message: f.lastError.message };
        else c.add('fx', 'خطای ذخیره‌شده‌ی نرخ نامعتبر است.');
      }
      if (f.maxAgeMinutes !== undefined) {
        if (Number.isInteger(f.maxAgeMinutes) && f.maxAgeMinutes >= 1 && f.maxAgeMinutes <= 1440) fx.maxAgeMinutes = f.maxAgeMinutes;
        else c.add('fx', 'حداکثر عمر نرخ نامعتبر است.');
      }
      out.fx = fx;
    }
  }

  if (c.total > 0) return fail();
  return { ok: true, state: out, errors: [], errorCount: 0 };
}

export function validateState(state) {
  const r = parseState(state);
  return { ok: r.ok, errors: r.errors, errorCount: r.errorCount };
}
