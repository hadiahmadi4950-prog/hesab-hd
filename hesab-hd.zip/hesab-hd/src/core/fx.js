// حساب HD — ماژول نرخ دلار و محاسبه‌ی ارزش دلاری با تأخیر
//
// سیاست تأییدشده: معادل دلاری با «قیمت لحظه‌ای دلار در لحظه‌ی محاسبه» ساخته می‌شود،
// نه نرخ تاریخی روز تراکنش. نرخ، زمان نرخ، منبع و دستی‌بودن کنار هر مبلغ ذخیره می‌شود.
//
// اصل: ثبت تراکنش هرگز به این ماژول، اینترنت یا نرخ وابسته نیست. مبلغ اصلی (amount)
// هیچ‌وقت توسط این ماژول تغییر نمی‌کند؛ فقط فیلد usd تراکنش پر می‌شود.
//
// شکل فیلد usd روی هر تراکنش:
//   { status: 'pending' }                              ← در انتظار محاسبه (فقط تراکنش تومانی)
//   { status: 'not_applicable' }                       ← تراکنش دلاری؛ مبلغش از اول دلار است
//   { status: 'done', cents, rate, rateAt, source, manual, computedAt, history: [...] }

import { tomanToUsdCents, isValidRate, MoneyError } from './money.js';

export const USD_STATUS = Object.freeze({
  PENDING: 'pending',
  DONE: 'done',
  NOT_APPLICABLE: 'not_applicable',
});

export const DEFAULT_MAX_AGE_MS = 30 * 60 * 1000; // نرخ قدیمی‌تر از ۳۰ دقیقه «لحظه‌ای» محسوب نمی‌شود
export const CLOCK_SKEW_MS = 5 * 60 * 1000;
export const MANUAL_SOURCE = 'دستی';

export function createFxState() {
  return { lastRate: null, lastError: null, maxAgeMinutes: 30 };
}

export function initialUsdField(currency) {
  return currency === 'USD' ? { status: USD_STATUS.NOT_APPLICABLE } : { status: USD_STATUS.PENDING };
}

function snapshot(usd, replacedAt) {
  return {
    cents: usd.cents,
    rate: usd.rate,
    rateAt: usd.rateAt,
    source: usd.source,
    manual: usd.manual,
    computedAt: usd.computedAt,
    replacedAt,
  };
}

// وقتی مبلغ یا واحد پول تراکنش ویرایش می‌شود، معادل دلاری قبلی دیگر معتبر نیست.
// مقدار قبلی در history می‌ماند و تراکنش دوباره در انتظار محاسبه قرار می‌گیرد.
export function invalidateUsdField(oldUsd, newCurrency, nowIso) {
  const base = initialUsdField(newCurrency);
  const history = [...(oldUsd?.history ?? [])];
  if (oldUsd?.status === USD_STATUS.DONE) history.push(snapshot(oldUsd, nowIso));
  return history.length > 0 && base.status === USD_STATUS.PENDING ? { ...base, history } : base;
}

// ---------- اعتبارسنجی نرخ ----------

export function validateRateInfo(rate) {
  if (!rate || typeof rate !== 'object') return { ok: false, error: 'نرخ ثبت نشده است.' };
  if (!isValidRate(rate.value)) return { ok: false, error: 'نرخ دلار نامعتبر است.' };
  if (typeof rate.at !== 'string' || !Number.isFinite(Date.parse(rate.at))) {
    return { ok: false, error: 'زمان نرخ نامعتبر است.' };
  }
  if (typeof rate.source !== 'string' || rate.source.trim() === '') {
    return { ok: false, error: 'منبع نرخ مشخص نیست.' };
  }
  if (typeof rate.manual !== 'boolean') return { ok: false, error: 'نوع نرخ (دستی/خودکار) مشخص نیست.' };
  return { ok: true };
}

// آیا این نرخ هنوز «لحظه‌ای» است؟ نرخ قدیمی را می‌توان با برچسب زمان نشان داد، اما برای
// محاسبه‌ی خودکار به‌عنوان نرخ لحظه‌ای استفاده نمی‌شود.
export function isFresh(rate, nowMs, maxAgeMs = DEFAULT_MAX_AGE_MS) {
  if (!validateRateInfo(rate).ok) return false;
  const age = nowMs - Date.parse(rate.at);
  return age >= -CLOCK_SKEW_MS && age <= maxAgeMs;
}

export function makeManualRate(value, nowIso) {
  const rate = { value, at: nowIso, source: MANUAL_SOURCE, manual: true };
  const v = validateRateInfo(rate);
  if (!v.ok) throw new MoneyError('BAD_RATE', v.error);
  return rate;
}

// ---------- محاسبه ----------

function withUsd(tx, rate, nowIso) {
  const cents = tomanToUsdCents(tx.amount, rate.value);
  const prev = tx.usd?.status === USD_STATUS.DONE ? [snapshot(tx.usd, nowIso)] : [];
  return {
    ...tx,
    usd: {
      status: USD_STATUS.DONE,
      cents,
      rate: rate.value,
      rateAt: rate.at,
      source: rate.source,
      manual: rate.manual,
      computedAt: nowIso,
      history: [...(tx.usd?.history ?? []), ...prev],
    },
  };
}

// فقط فیلد usd را عوض می‌کند؛ amount و بقیه‌ی فیلدها دست‌نخورده می‌مانند.
export function computeUsd(tx, rate, nowIso, { force = false } = {}) {
  if (tx.currency !== 'IRT') return tx;
  const v = validateRateInfo(rate);
  if (!v.ok) throw new MoneyError('BAD_RATE', v.error);
  if (tx.usd?.status === USD_STATUS.DONE && !force) return tx;
  return withUsd(tx, rate, nowIso);
}

export function pendingTransactions(state) {
  return state.transactions.filter((t) => t.currency === 'IRT' && t.usd?.status === USD_STATUS.PENDING);
}

function mapTransactions(state, fn) {
  let updated = 0;
  const transactions = state.transactions.map((t) => {
    const next = fn(t);
    if (next !== t) updated += 1;
    return next;
  });
  return { state: updated > 0 ? { ...state, transactions } : state, updated };
}

// محاسبه‌ی معوق‌ها با یک نرخ لحظه‌ای تازه.
// اگر نرخ معتبر یا تازه نباشد، هیچ چیز تغییر نمی‌کند و تراکنش‌ها در انتظار می‌مانند.
export function processPending(state, rate, nowIso, { maxAgeMs = DEFAULT_MAX_AGE_MS } = {}) {
  const v = validateRateInfo(rate);
  if (!v.ok) return { state, updated: 0, reason: 'no_rate', message: v.error };
  const nowMs = Date.parse(nowIso);
  if (!rate.manual && !isFresh(rate, nowMs, maxAgeMs)) {
    return { state, updated: 0, reason: 'stale_rate', message: 'نرخ دریافت‌شده قدیمی است و به‌عنوان نرخ لحظه‌ای استفاده نشد.' };
  }
  const r = mapTransactions(state, (t) =>
    t.currency === 'IRT' && t.usd?.status === USD_STATUS.PENDING ? withUsd(t, rate, nowIso) : t,
  );
  return { state: r.state, updated: r.updated, reason: r.updated > 0 ? 'ok' : 'nothing_pending' };
}

// کاربر خودش نرخ دستی می‌دهد. فقط روی موارد در انتظار (یا شناسه‌های مشخص) اعمال می‌شود.
export function applyManualRate(state, value, nowIso, { txIds = null, includeDone = false } = {}) {
  const rate = makeManualRate(value, nowIso);
  const wanted = txIds ? new Set(txIds) : null;
  const r = mapTransactions(state, (t) => {
    if (t.currency !== 'IRT') return t;
    if (wanted && !wanted.has(t.id)) return t;
    if (t.usd?.status === USD_STATUS.PENDING) return withUsd(t, rate, nowIso);
    if (includeDone && t.usd?.status === USD_STATUS.DONE) return withUsd(t, rate, nowIso);
    return t;
  });
  return { state: r.state, updated: r.updated, rate };
}

// محاسبه‌ی مجدد تراکنش‌های انجام‌شده (درخواست صریح کاربر)؛ نرخ قبلی در history می‌ماند.
export function recalculate(state, txIds, rate, nowIso) {
  const v = validateRateInfo(rate);
  if (!v.ok) throw new MoneyError('BAD_RATE', v.error);
  const wanted = new Set(txIds);
  const r = mapTransactions(state, (t) =>
    t.currency === 'IRT' && wanted.has(t.id) && t.usd?.status === USD_STATUS.DONE ? withUsd(t, rate, nowIso) : t,
  );
  return { state: r.state, updated: r.updated };
}

// ---------- دریافت نرخ از اینترنت ----------
// adapter: { id, name, market, url, parse(json) → { value } }  (value به تومان، عدد صحیح)
// هیچ‌وقت exception بیرون نمی‌دهد؛ قطع اینترنت یا پاسخ خراب فقط به‌صورت {ok:false} برمی‌گردد.

export async function fetchLiveRate(adapter, { fetchFn = globalThis.fetch, nowIso, timeoutMs = 8000 } = {}) {
  if (typeof fetchFn !== 'function') return { ok: false, error: 'امکان اتصال به اینترنت در این محیط نیست.' };
  const controller = typeof AbortController === 'function' ? new AbortController() : null;
  const timer = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
  try {
    const res = await fetchFn(adapter.url, { signal: controller?.signal, headers: { accept: 'application/json' } });
    if (!res || !res.ok) return { ok: false, error: 'منبع نرخ پاسخ معتبر نداد.' };
    const json = await res.json();
    const parsed = adapter.parse(json, { nowIso });
    if (parsed?.error) return { ok: false, error: parsed.error };
    if (!parsed || !isValidRate(parsed.value)) return { ok: false, error: 'پاسخ منبع نرخ قابل‌استفاده نبود.' };
    const rate = { value: parsed.value, at: nowIso, source: adapter.name, manual: false };
    return { ok: true, rate };
  } catch {
    return { ok: false, error: 'دریافت نرخ ممکن نشد (اینترنت یا منبع در دسترس نیست).' };
  } finally {
    if (timer) clearTimeout(timer);
  }
}

// همگام‌سازی: دریافت نرخ ← محاسبه‌ی معوق‌ها. در صورت شکست، همه‌چیز در انتظار می‌ماند.
export async function syncPending(state, adapter, { fetchFn, nowIso, timeoutMs } = {}) {
  const fx = state.fx ?? createFxState();
  if (pendingTransactions(state).length === 0) {
    return { state, status: 'nothing_pending', updated: 0 };
  }
  const res = await fetchLiveRate(adapter, { fetchFn, nowIso, timeoutMs });
  if (!res.ok) {
    return {
      state: { ...state, fx: { ...fx, lastError: { at: nowIso, message: res.error } } },
      status: 'fetch_failed',
      updated: 0,
      message: res.error,
    };
  }
  const processed = processPending({ ...state, fx: { ...fx, lastRate: res.rate, lastError: null } }, res.rate, nowIso, {
    maxAgeMs: (fx.maxAgeMinutes ?? 30) * 60 * 1000,
  });
  return { state: processed.state, status: processed.reason, updated: processed.updated, rate: res.rate };
}
