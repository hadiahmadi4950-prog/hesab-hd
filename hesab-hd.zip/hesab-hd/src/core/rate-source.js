// منبع نرخ دلار آزاد (تومان). تنها تماس اینترنتی برنامه همین است.
// منبع: پروژه‌ی عمومی «iran-market» روی GitHub که داده‌ی TGJU را هر ~۳۰ دقیقه منتشر می‌کند.
// بدون تضمین است؛ اگر قطع یا کهنه بود، برنامه با نرخ دستی کار می‌کند و هیچ عددی حدس زده نمی‌شود.

export const IRAN_MARKET_URL = 'https://raw.githubusercontent.com/iran-market/iran-market.github.io/main/data/popular.json';
// بازار روزهای تعطیل بسته است؛ قیمتی که بیش از این مدت از آخرین تغییرش گذشته «کهنه» حساب می‌شود
export const MAX_PRICE_AGE_MS = 4 * 24 * 60 * 60 * 1000;

export const iranMarketAdapter = {
  id: 'iran-market',
  name: 'iran-market (TGJU)',
  market: 'بازار آزاد',
  url: IRAN_MARKET_URL,
  parse(json, { nowIso } = {}) {
    const rec = Array.isArray(json?.data) ? json.data.find((r) => r?.symbol === 'USD_IRR_FREE') : null;
    if (!rec) return { error: 'نرخ دلار در پاسخ منبع پیدا نشد.' };
    if (rec.currency !== 'IRT') return { error: 'واحد نرخ منبع تومان نیست؛ برای جلوگیری از خطا استفاده نشد.' };
    if (rec.stale === true) return { error: 'منبع نرخ را کهنه اعلام کرده است.' };
    const price = rec.price;
    if (typeof price !== 'number' || !Number.isInteger(price) || price <= 0) return { error: 'عدد نرخ در پاسخ منبع معتبر نبود.' };
    const t = Date.parse(rec.timestamp);
    const now = Date.parse(nowIso ?? '');
    if (Number.isFinite(t) && Number.isFinite(now) && now - t > MAX_PRICE_AGE_MS) {
      return { error: 'نرخ منبع چند روز است به‌روز نشده؛ نرخ دستی وارد کنید.' };
    }
    return { value: price };
  },
};
