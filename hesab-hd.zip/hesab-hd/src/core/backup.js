// حساب HD — پشتیبان‌گیری و بازیابی
//
// - خروجی JSON: پاکت (envelope) شامل نسخه‌ی قالب، شمارش رکوردها و checksum برای تشخیص فایل ناقص یا دست‌خورده.
// - خروجی CSV: برای اکسل؛ UTF-8 با BOM، سطر پایان CRLF، ارقام لاتین، ایمن در برابر تزریق فرمول.
// - ورود: هیچ‌وقت مستقیم state فعلی را عوض نمی‌کند. ابتدا فایل کاملاً اعتبارسنجی و پیش‌نمایش می‌شود،
//   سپس «ادغام» (افزودن موارد جدید بدون تکرار) یا «جایگزینی کامل» (فقط با تأیید صریح) انجام می‌شود.
// - فایل خراب هرگز جای داده‌ی سالم را نمی‌گیرد؛ هر ناسازگاری یعنی رد کامل فایل.

import * as J from './jalali.js';
import * as M from './money.js';
import * as L from './ledger.js';
import { parseState } from './validate.js';

export const BACKUP_FORMAT = 'hesab-hd-backup';
export const BACKUP_FORMAT_VERSION = 1;
export const MAX_BACKUP_BYTES = 50 * 1024 * 1024;
export const APP_NAME = 'حساب HD';

export class BackupError extends Error {
  constructor(code, message, extra = {}) {
    super(message);
    this.name = 'BackupError';
    this.code = code;
    Object.assign(this, extra);
  }
}

// ---------- checksum ----------

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();

export function crc32(text) {
  const bytes = new TextEncoder().encode(text);
  let crc = 0xffffffff;
  for (const b of bytes) crc = CRC_TABLE[(crc ^ b) & 0xff] ^ (crc >>> 8);
  return ((crc ^ 0xffffffff) >>> 0).toString(16).padStart(8, '0');
}

// ---------- خلاصه‌ی state ----------

export function summarizeState(state) {
  let from = null;
  let to = null;
  for (const t of state.transactions) {
    if (from === null || t.date < from) from = t.date;
    if (to === null || t.date > to) to = t.date;
  }
  return {
    accounts: state.accounts.length,
    categories: state.categories.length,
    transactions: state.transactions.length,
    debts: state.debts.length,
    goals: state.goals.length,
    budgets: state.budgets.length,
    pendingUsd: state.transactions.filter((t) => t.usd?.status === 'pending').length,
    dateRange: from ? { from, to } : null,
    balances: L.totalBalances(state),
  };
}

const countsOf = (state) => ({
  accounts: state.accounts.length,
  categories: state.categories.length,
  transactions: state.transactions.length,
  debts: state.debts.length,
  goals: state.goals.length,
  budgets: state.budgets.length,
});

// ---------- خروجی JSON ----------

export function exportJSON(state, { now = new Date().toISOString(), appVersion = '0.1.0' } = {}) {
  const check = parseState(state);
  if (!check.ok) {
    throw new BackupError('STATE_INVALID', 'داده‌ی فعلی ناسازگار است و نمی‌توان از آن پشتیبان معتبر ساخت.', { errors: check.errors });
  }
  const data = check.state;
  const envelope = {
    format: BACKUP_FORMAT,
    formatVersion: BACKUP_FORMAT_VERSION,
    appName: APP_NAME,
    appVersion,
    exportedAt: now,
    counts: countsOf(data),
    checksum: { algo: 'crc32', value: crc32(JSON.stringify(data)) },
    data,
  };
  return JSON.stringify(envelope, null, 1);
}

// ---------- ورود: خواندن و اعتبارسنجی فایل ----------

function bad(message, extra = {}) {
  return { ok: false, state: null, meta: null, errors: [{ path: 'file', message }], errorCount: 1, ...extra };
}

export function parseBackup(text) {
  if (typeof text !== 'string') return bad('محتوای فایل خوانده نشد.');
  if (text.length === 0) return bad('فایل خالی است.');
  if (text.length > MAX_BACKUP_BYTES) return bad('فایل بیش از حد بزرگ است.');
  const clean = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
  let env;
  try {
    env = JSON.parse(clean);
  } catch {
    return bad('فایل JSON معتبر نیست؛ ممکن است ناقص یا خراب باشد.');
  }
  if (env === null || typeof env !== 'object' || Array.isArray(env)) return bad('ساختار فایل پشتیبان نامعتبر است.');
  if (env.format !== BACKUP_FORMAT) return bad('این فایل، پشتیبان «حساب HD» نیست.');
  if (!Number.isInteger(env.formatVersion) || env.formatVersion < 1) return bad('نسخه‌ی قالب فایل مشخص نیست.');
  if (env.formatVersion > BACKUP_FORMAT_VERSION) return bad('این پشتیبان با نسخه‌ی جدیدتری از برنامه ساخته شده است.');
  if (env.data === null || typeof env.data !== 'object' || Array.isArray(env.data)) return bad('بخش داده‌ی فایل وجود ندارد.');
  if (!env.checksum || env.checksum.algo !== 'crc32' || typeof env.checksum.value !== 'string') return bad('checksum فایل وجود ندارد؛ فایل معتبر نیست.');
  if (crc32(JSON.stringify(env.data)) !== env.checksum.value) {
    return bad('محتوای فایل با checksum هم‌خوان نیست؛ فایل ناقص، خراب یا دستی ویرایش شده است.');
  }
  const parsed = parseState(env.data);
  if (!parsed.ok) {
    return { ok: false, state: null, meta: null, errors: parsed.errors, errorCount: parsed.errorCount };
  }
  const counts = countsOf(parsed.state);
  if (!env.counts || Object.keys(counts).some((k) => env.counts[k] !== counts[k])) {
    return bad('تعداد رکوردهای ثبت‌شده در فایل با محتوای آن هم‌خوان نیست.');
  }
  return {
    ok: true,
    state: parsed.state,
    meta: { exportedAt: typeof env.exportedAt === 'string' ? env.exportedAt : null, appVersion: typeof env.appVersion === 'string' ? env.appVersion : null, counts },
    errors: [],
    errorCount: 0,
  };
}

// ---------- ادغام ----------

const IMPORTED_SUFFIX = ' (واردشده)';

function uniqueName(name, taken) {
  let candidate = `${name}${IMPORTED_SUFFIX}`;
  let n = 2;
  while (taken.has(L.normalizeFa(candidate))) {
    candidate = `${name}${IMPORTED_SUFFIX} ${n}`;
    n += 1;
  }
  return candidate.length > L.MAX_NAME_LENGTH ? `${name.slice(0, L.MAX_NAME_LENGTH - IMPORTED_SUFFIX.length - 3)}${IMPORTED_SUFFIX} ${n}` : candidate;
}

// موارد جدید فایل را به state فعلی اضافه می‌کند. هیچ مورد موجودی بازنویسی یا حذف نمی‌شود.
export function mergeStates(current, incoming, { skipContentDuplicates = true } = {}) {
  const report = {
    added: { accounts: 0, categories: 0, transactions: 0, debts: 0, goals: 0, budgets: 0 },
    skippedExisting: { accounts: 0, categories: 0, transactions: 0, debts: 0, goals: 0, budgets: 0 },
    skippedDuplicates: 0,
    skippedBudgetConflicts: 0,
    renamed: [],
    mappedCategories: 0,
    conflicts: [],
  };
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);

  // حساب‌ها
  const accounts = [...current.accounts];
  const accIds = new Set(accounts.map((a) => a.id));
  const activeNames = new Set(accounts.filter((a) => !a.archived).map((a) => L.normalizeFa(a.name)));
  for (const a of incoming.accounts) {
    if (accIds.has(a.id)) {
      report.skippedExisting.accounts += 1;
      const cur = accounts.find((x) => x.id === a.id);
      if (cur.openingBalance !== a.openingBalance || cur.currency !== a.currency) report.conflicts.push(`حساب «${a.name}» در فایل با نسخه‌ی فعلی تفاوت دارد؛ نسخه‌ی فعلی حفظ شد.`);
      continue;
    }
    let next = a;
    if (!a.archived && activeNames.has(L.normalizeFa(a.name))) {
      const name = uniqueName(a.name, activeNames);
      report.renamed.push({ kind: 'account', from: a.name, to: name });
      next = { ...a, name };
    }
    if (!next.archived) activeNames.add(L.normalizeFa(next.name));
    accIds.add(next.id);
    accounts.push(next);
    report.added.accounts += 1;
  }

  // دسته‌ها (هم‌نام و هم‌نوع با دسته‌ی موجود، یکی حساب می‌شود و ارجاع‌ها منتقل می‌شوند)
  const categories = [...current.categories];
  const catIds = new Set(categories.map((c) => c.id));
  const catByKey = new Map(categories.map((c) => [`${c.kind}|${L.normalizeFa(c.name)}`, c]));
  const catMap = new Map();
  for (const c of incoming.categories) {
    if (catIds.has(c.id)) {
      report.skippedExisting.categories += 1;
      catMap.set(c.id, c.id);
      continue;
    }
    const twin = catByKey.get(`${c.kind}|${L.normalizeFa(c.name)}`);
    if (twin) {
      catMap.set(c.id, twin.id);
      report.mappedCategories += 1;
      continue;
    }
    catMap.set(c.id, c.id);
    catIds.add(c.id);
    catByKey.set(`${c.kind}|${L.normalizeFa(c.name)}`, c);
    categories.push(c);
    report.added.categories += 1;
  }
  const mapCat = (id) => (id === null ? null : catMap.get(id) ?? id);

  // بدهی/طلب
  const debts = [...current.debts];
  const debtIds = new Set(debts.map((d) => d.id));
  for (const d of incoming.debts) {
    if (debtIds.has(d.id)) {
      report.skippedExisting.debts += 1;
      if (!same(debts.find((x) => x.id === d.id), d)) report.conflicts.push(`بدهی/طلب «${d.person}» در فایل با نسخه‌ی فعلی تفاوت دارد؛ نسخه‌ی فعلی حفظ شد.`);
      continue;
    }
    debtIds.add(d.id);
    debts.push(d);
    report.added.debts += 1;
  }

  // تراکنش‌ها
  const transactions = [...current.transactions];
  const txIds = new Set(transactions.map((t) => t.id));
  const keys = new Set(transactions.map((t) => L.dupKey(t)));
  const requestIds = new Set(transactions.map((t) => t.requestId).filter(Boolean));
  for (const t0 of incoming.transactions) {
    if (txIds.has(t0.id)) {
      report.skippedExisting.transactions += 1;
      continue;
    }
    const t = { ...t0, categoryId: mapCat(t0.categoryId) };
    if (t.requestId && requestIds.has(t.requestId)) {
      report.skippedDuplicates += 1;
      continue;
    }
    if (skipContentDuplicates && keys.has(L.dupKey(t))) {
      report.skippedDuplicates += 1;
      continue;
    }
    txIds.add(t.id);
    keys.add(L.dupKey(t));
    if (t.requestId) requestIds.add(t.requestId);
    transactions.push(t);
    report.added.transactions += 1;
  }

  // بودجه‌ها: همزمان دو نسخه‌ی «باز» برای یک دسته و دوره مجاز نیست
  const budgets = [...current.budgets];
  const budgetIds = new Set(budgets.map((b) => b.id));
  for (const b0 of incoming.budgets) {
    if (budgetIds.has(b0.id)) {
      report.skippedExisting.budgets += 1;
      continue;
    }
    const b = { ...b0, categoryId: mapCat(b0.categoryId) };
    if (!b.effectiveTo && budgets.some((x) => !x.effectiveTo && x.categoryId === b.categoryId && x.period === b.period)) {
      report.skippedBudgetConflicts += 1;
      report.conflicts.push('یک بودجه‌ی فعال هم‌دسته و هم‌دوره در فایل با بودجه‌ی فعلی تداخل داشت؛ بودجه‌ی فعلی حفظ شد.');
      continue;
    }
    budgetIds.add(b.id);
    budgets.push(b);
    report.added.budgets += 1;
  }

  // اهداف
  const goals = [...current.goals];
  const goalIds = new Set(goals.map((g) => g.id));
  const goalNames = new Set(goals.map((g) => L.normalizeFa(g.name)));
  for (const g of incoming.goals) {
    if (goalIds.has(g.id)) {
      report.skippedExisting.goals += 1;
      continue;
    }
    let next = g;
    if (goalNames.has(L.normalizeFa(g.name))) {
      const name = uniqueName(g.name, goalNames);
      report.renamed.push({ kind: 'goal', from: g.name, to: name });
      next = { ...g, name };
    }
    goalNames.add(L.normalizeFa(next.name));
    goalIds.add(next.id);
    goals.push(next);
    report.added.goals += 1;
  }

  const merged = { ...current, accounts, categories, debts, transactions, budgets, goals };
  const check = parseState(JSON.parse(JSON.stringify(merged)));
  if (!check.ok) {
    throw new BackupError('MERGE_INVALID', 'ادغام باعث ناسازگاری داده می‌شود و انجام نشد؛ اطلاعات فعلی دست‌نخورده ماند.', { errors: check.errors });
  }
  return { state: check.state, report };
}

// ---------- پیش‌نمایش و بازیابی ----------

export function previewRestore(current, incoming, { skipContentDuplicates = true } = {}) {
  const merge = (() => {
    try {
      const m = mergeStates(current, incoming, { skipContentDuplicates });
      return { ok: true, report: m.report, result: summarizeState(m.state) };
    } catch (e) {
      if (e instanceof BackupError) return { ok: false, error: e.message, errors: e.errors };
      throw e;
    }
  })();
  return {
    current: summarizeState(current),
    incoming: summarizeState(incoming),
    currentHasData: current.accounts.length > 0 || current.transactions.length > 0 || current.debts.length > 0 || current.goals.length > 0,
    merge,
    replace: { willRemove: summarizeState(current) },
  };
}

// جایگزینی کامل فقط با تأیید صریح؛ نسخه‌ی پشتیبان خودکارِ داده‌ی فعلی هم برگردانده می‌شود
export function restoreReplace(current, incoming, { confirm = false, now, appVersion } = {}) {
  if (confirm !== true) {
    throw new BackupError('CONFIRM_REQUIRED', 'جایگزینی کامل، اطلاعات فعلی را پاک می‌کند و نیاز به تأیید صریح دارد.');
  }
  const check = parseState(JSON.parse(JSON.stringify(incoming)));
  if (!check.ok) throw new BackupError('INCOMING_INVALID', 'داده‌ی ورودی نامعتبر است و جایگزین نشد.', { errors: check.errors });
  const hasCurrent = current.accounts.length > 0 || current.transactions.length > 0 || current.debts.length > 0 || current.goals.length > 0;
  const safetyBackup = hasCurrent ? exportJSON(current, { now, appVersion }) : null;
  return { state: check.state, safetyBackup, removed: summarizeState(current) };
}

// ---------- خروجی CSV ----------

const TX_TYPE_LABEL = { income: 'درآمد', expense: 'هزینه', transfer: 'انتقال', debt_payment: 'پرداخت/دریافت بدهی' };
const USD_LABEL = { pending: 'در انتظار', done: 'محاسبه‌شده', not_applicable: 'بدون نیاز' };

function csvCell(value, { text = false } = {}) {
  let s = value === null || value === undefined ? '' : String(value);
  // جلوگیری از اجرای فرمول در اکسل/شیت: متن‌هایی که با این نویسه‌ها شروع می‌شوند، با ' آغاز می‌شوند
  if (text && /^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  if (/[",\r\n]/.test(s) || s !== s.trim()) s = `"${s.replace(/"/g, '""')}"`;
  return s;
}

function csvLine(cells) {
  return cells.join(',');
}

const amountString = (currency, value) => (value === null || value === undefined ? '' : M.toEditableString(currency, value));

export function exportCSV(state, { kind = 'transactions' } = {}) {
  const accName = (id) => state.accounts.find((a) => a.id === id)?.name ?? '';
  const catName = (id) => state.categories.find((c) => c.id === id)?.name ?? '';
  const lines = [];
  if (kind === 'transactions') {
    lines.push(csvLine(['شناسه', 'نوع', 'تاریخ شمسی', 'مبلغ', 'واحد', 'حساب', 'حساب مقصد', 'مبلغ مقصد', 'واحد مقصد', 'دسته', 'طرف بدهی/طلب', 'یادداشت', 'روش پرداخت', 'معادل دلاری (دلار)', 'وضعیت دلار', 'نرخ دلار (تومان)', 'زمان نرخ', 'منبع نرخ', 'نرخ دستی', 'زمان ایجاد', 'آخرین ویرایش'].map((h) => csvCell(h))));
    const sorted = [...state.transactions].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : a.createdAt < b.createdAt ? -1 : a.createdAt > b.createdAt ? 1 : a.id < b.id ? -1 : 1));
    for (const t of sorted) {
      const isTransfer = t.type === 'transfer';
      const debt = t.debtId ? state.debts.find((d) => d.id === t.debtId) : null;
      const u = t.usd ?? {};
      lines.push(
        csvLine([
          csvCell(t.id),
          csvCell(TX_TYPE_LABEL[t.type] ?? t.type),
          csvCell(t.date),
          csvCell(amountString(t.currency, t.amount)),
          csvCell(M.CURRENCIES[t.currency]?.name ?? t.currency),
          csvCell(isTransfer ? accName(t.fromAccountId) : accName(t.accountId), { text: true }),
          csvCell(isTransfer ? accName(t.toAccountId) : '', { text: true }),
          csvCell(isTransfer ? amountString(t.toCurrency, t.toAmount) : ''),
          csvCell(isTransfer ? (M.CURRENCIES[t.toCurrency]?.name ?? t.toCurrency) : ''),
          csvCell(catName(t.categoryId), { text: true }),
          csvCell(debt ? `${debt.person} (${debt.direction === 'owe' ? 'بدهی من' : 'طلب من'})` : '', { text: true }),
          csvCell(t.note, { text: true }),
          csvCell(t.method, { text: true }),
          csvCell(u.status === 'done' ? M.toEditableString('USD', u.cents) : t.currency === 'USD' ? M.toEditableString('USD', t.amount) : ''),
          csvCell(USD_LABEL[u.status] ?? ''),
          csvCell(u.status === 'done' ? u.rate : ''),
          csvCell(u.status === 'done' ? u.rateAt : ''),
          csvCell(u.status === 'done' ? u.source : '', { text: true }),
          csvCell(u.status === 'done' ? (u.manual ? 'بله' : 'خیر') : ''),
          csvCell(t.createdAt),
          csvCell(t.updatedAt),
        ]),
      );
    }
  } else if (kind === 'accounts') {
    lines.push(csvLine(['نام', 'نوع', 'واحد', 'موجودی اولیه', 'موجودی فعلی', 'بایگانی‌شده'].map((h) => csvCell(h))));
    for (const { account, balance } of L.accountBalances(state)) {
      lines.push(csvLine([csvCell(account.name, { text: true }), csvCell(L.ACCOUNT_TYPE_LABELS[account.type]), csvCell(M.CURRENCIES[account.currency].name), csvCell(amountString(account.currency, account.openingBalance)), csvCell(amountString(account.currency, balance)), csvCell(account.archived ? 'بله' : 'خیر')]));
    }
  } else {
    throw new BackupError('BAD_KIND', 'نوع خروجی CSV نامعتبر است.');
  }
  return `﻿${lines.join('\r\n')}\r\n`;
}

export function backupFileName(now = new Date().toISOString(), ext = 'json', kind = 'backup') {
  // تاریخ شمسی بر پایه‌ی ساعت تهران (نه UTC) تا نزدیک نیمه‌شب نام فایل یک روز عقب نیفتد
  const date = J.todayJalali(new Date(now), 'Asia/Tehran');
  return `hesab-hd-${kind}-${date}.${ext}`;
}
