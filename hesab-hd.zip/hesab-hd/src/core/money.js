// حساب HD — ماژول پول
// قرارداد: هر عددی که کاربر وارد می‌کند «تومان» است و عیناً ذخیره می‌شود.
// هیچ تبدیل ریال/تومان در برنامه وجود ندارد.
// تومان: عدد صحیح تومان. دلار: عدد صحیح سنت. هیچ مبلغی به‌صورت اعشاری ذخیره یا جمع نمی‌شود.

export const CURRENCIES = Object.freeze({
  IRT: Object.freeze({ code: 'IRT', name: 'تومان', decimals: 0 }),
  USD: Object.freeze({ code: 'USD', name: 'دلار', decimals: 2 }),
});

// سقف مبلغ: برای جلوگیری از خطای ورود (مثلاً چسباندن شماره‌ی کارت) و تضمین دقت عدد صحیح
export const MAX_TOMAN = 1_000_000_000_000_000; // ۱ کوادریلیون تومان
export const MAX_USD_CENTS = 10_000_000_000_000; // ۱۰۰ میلیارد دلار
export const MIN_RATE = 1;
export const MAX_RATE = 10_000_000; // تومان به‌ازای هر دلار

export class MoneyError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'MoneyError';
    this.code = code;
  }
}

export function normalizeDigits(str) {
  return String(str)
    .replace(/[۰-۹]/g, (c) => String(c.charCodeAt(0) - 0x06f0))
    .replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 0x0660))
    .replace(/٫/g, '.') // ممیز عربی
    .replace(/[٬،,\s‌‏‎]/g, ''); // جداکننده‌ی هزارگان، فاصله، نیم‌فاصله
}

export function toPersianDigits(value) {
  return String(value).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
}

function groupThousands(digits) {
  return digits.replace(/\B(?=(\d{3})+(?!\d))/g, '٬');
}

// ---------- تجزیه‌ی ورودی کاربر ----------
// خروجی: { ok: true, value } یا { ok: false, error }  (هرگز عدد اشتباه نمی‌دهد)

function fail(error) {
  return { ok: false, error };
}

export function parseToman(input, { allowZero = false, allowNegative = false } = {}) {
  if (input === null || input === undefined) return fail('مبلغ را وارد کنید.');
  let text;
  if (typeof input === 'number') {
    if (!Number.isFinite(input)) return fail('مبلغ نامعتبر است.');
    if (!Number.isInteger(input)) return fail('مبلغ تومان باید عدد صحیح باشد.');
    text = String(input);
    if (/e/i.test(text)) return fail('مبلغ خیلی بزرگ است.');
  } else if (typeof input === 'string') {
    text = normalizeDigits(input);
  } else {
    return fail('مبلغ نامعتبر است.');
  }
  if (text === '') return fail('مبلغ را وارد کنید.');
  const m = /^([+-])?(\d+)$/.exec(text);
  if (!m) {
    if (/^[+-]?\d+\.\d+$/.test(text)) return fail('مبلغ تومان باید عدد صحیح باشد.');
    return fail('مبلغ باید فقط شامل رقم باشد.');
  }
  if (m[2].length > 16) return fail('مبلغ خیلی بزرگ است.');
  const abs = Number(m[2]);
  const negative = m[1] === '-' && abs !== 0;
  if (abs > MAX_TOMAN) return fail('مبلغ خیلی بزرگ است.');
  if (negative && !allowNegative) return fail('مبلغ نمی‌تواند منفی باشد.');
  if (abs === 0 && !allowZero) return fail('مبلغ باید بیشتر از صفر باشد.');
  return { ok: true, value: negative ? -abs : abs };
}

export function parseUsd(input, { allowZero = false, allowNegative = false } = {}) {
  if (input === null || input === undefined) return fail('مبلغ را وارد کنید.');
  let text;
  if (typeof input === 'number') {
    if (!Number.isFinite(input)) return fail('مبلغ نامعتبر است.');
    text = String(input);
    if (/e/i.test(text)) return fail('مبلغ خیلی بزرگ یا کوچک است.');
  } else if (typeof input === 'string') {
    text = normalizeDigits(input);
  } else {
    return fail('مبلغ نامعتبر است.');
  }
  if (text === '') return fail('مبلغ را وارد کنید.');
  const m = /^([+-])?(\d+)(?:\.(\d+))?$/.exec(text);
  if (!m) return fail('مبلغ باید فقط شامل رقم باشد.');
  const fraction = m[3] ?? '';
  if (fraction.length > 2) return fail('مبلغ دلار حداکثر دو رقم اعشار دارد.');
  if (m[2].length > 12) return fail('مبلغ خیلی بزرگ است.');
  const cents = Number(m[2]) * 100 + Number(fraction.padEnd(2, '0') || '0');
  const negative = m[1] === '-' && cents !== 0;
  if (cents > MAX_USD_CENTS) return fail('مبلغ خیلی بزرگ است.');
  if (negative && !allowNegative) return fail('مبلغ نمی‌تواند منفی باشد.');
  if (cents === 0 && !allowZero) return fail('مبلغ باید بیشتر از صفر باشد.');
  return { ok: true, value: negative ? -cents : cents };
}

export function parseAmount(currency, input, options) {
  if (currency === 'IRT') return parseToman(input, options);
  if (currency === 'USD') return parseUsd(input, options);
  return fail('واحد پول نامعتبر است.');
}

// نرخ: تومان به‌ازای هر ۱ دلار، عدد صحیح
export function parseRate(input) {
  const r = parseToman(input);
  if (!r.ok) return fail(r.error.replace('مبلغ', 'نرخ'));
  if (r.value < MIN_RATE || r.value > MAX_RATE) return fail('نرخ دلار خارج از محدوده‌ی معتبر است.');
  return r;
}

export function isValidRate(rate) {
  return Number.isInteger(rate) && rate >= MIN_RATE && rate <= MAX_RATE;
}

export function isValidAmount(currency, value) {
  if (!Number.isSafeInteger(value)) return false;
  if (currency === 'IRT') return Math.abs(value) <= MAX_TOMAN;
  if (currency === 'USD') return Math.abs(value) <= MAX_USD_CENTS;
  return false;
}

// ---------- گرد کردن و تبدیل ----------
// قانون گرد کردن در کل برنامه: نیم به سمت دورتر از صفر (half away from zero)

export function roundDiv(numerator, denominator) {
  const n = BigInt(numerator);
  const d = BigInt(denominator);
  if (d === 0n) throw new MoneyError('DIV_ZERO', 'تقسیم بر صفر');
  const neg = n < 0n !== d < 0n;
  const absN = n < 0n ? -n : n;
  const absD = d < 0n ? -d : d;
  const q = (2n * absN + absD) / (2n * absD);
  const result = neg ? -q : q;
  if (result > BigInt(Number.MAX_SAFE_INTEGER) || result < -BigInt(Number.MAX_SAFE_INTEGER)) {
    throw new MoneyError('OVERFLOW', 'نتیجه خارج از محدوده‌ی عدد صحیح امن است.');
  }
  return Number(result);
}

// تومان → سنت دلار با نرخ (تومان به‌ازای هر دلار)
export function tomanToUsdCents(toman, rate) {
  if (!Number.isSafeInteger(toman)) throw new MoneyError('BAD_AMOUNT', 'مبلغ تومان باید عدد صحیح باشد.');
  if (!isValidRate(rate)) throw new MoneyError('BAD_RATE', 'نرخ دلار نامعتبر است.');
  return roundDiv(BigInt(toman) * 100n, rate);
}

// سنت دلار → تومان با نرخ
export function usdCentsToToman(cents, rate) {
  if (!Number.isSafeInteger(cents)) throw new MoneyError('BAD_AMOUNT', 'مبلغ دلار (سنت) باید عدد صحیح باشد.');
  if (!isValidRate(rate)) throw new MoneyError('BAD_RATE', 'نرخ دلار نامعتبر است.');
  return roundDiv(BigInt(cents) * BigInt(rate), 100);
}

// درصد به‌صورت «نقطه‌ی پایه» (basis points، ۱۰۰ = ۱٪)؛ بدون عدد اعشاری شناور
export function percentBp(part, whole) {
  if (!Number.isSafeInteger(part) || !Number.isSafeInteger(whole)) {
    throw new MoneyError('BAD_AMOUNT', 'مقدارها باید عدد صحیح باشند.');
  }
  if (whole === 0) return null;
  return roundDiv(BigInt(part) * 10000n, whole);
}

export function safeAdd(a, b) {
  const r = a + b;
  if (!Number.isSafeInteger(a) || !Number.isSafeInteger(b) || !Number.isSafeInteger(r)) {
    throw new MoneyError('OVERFLOW', 'جمع مبالغ از محدوده‌ی عدد صحیح امن بیشتر شد.');
  }
  return r;
}

export function sumAmounts(values) {
  let total = 0;
  for (const v of values) total = safeAdd(total, v);
  return total;
}

// ---------- نمایش ----------

const MINUS = '−';

function formatInt(n) {
  if (!Number.isSafeInteger(n)) throw new MoneyError('BAD_AMOUNT', 'مبلغ باید عدد صحیح باشد.');
  const abs = Math.abs(n);
  return `${n < 0 ? MINUS : ''}${toPersianDigits(groupThousands(String(abs)))}`;
}

export function formatToman(n, { withUnit = true } = {}) {
  const body = formatInt(n);
  return withUnit ? `${body} تومان` : body;
}

export function formatUsd(cents, { withUnit = true } = {}) {
  if (!Number.isSafeInteger(cents)) throw new MoneyError('BAD_AMOUNT', 'مبلغ باید عدد صحیح باشد.');
  const abs = Math.abs(cents);
  const whole = Math.trunc(abs / 100);
  const frac = String(abs % 100).padStart(2, '0');
  const body = `${cents < 0 ? MINUS : ''}${toPersianDigits(groupThousands(String(whole)))}٫${toPersianDigits(frac)}`;
  return withUnit ? `${body} دلار` : body;
}

export function formatAmount(currency, value, options) {
  if (currency === 'IRT') return formatToman(value, options);
  if (currency === 'USD') return formatUsd(value, options);
  throw new MoneyError('BAD_CURRENCY', 'واحد پول نامعتبر است.');
}

// عدد صحیح تومان را برای نمایش «ورودی» (بدون واحد، با ارقام لاتین) برمی‌گرداند؛ برای ویرایش
export function toEditableString(currency, value) {
  if (currency === 'IRT') return String(value);
  const abs = Math.abs(value);
  return `${value < 0 ? '-' : ''}${Math.trunc(abs / 100)}.${String(abs % 100).padStart(2, '0')}`;
}
