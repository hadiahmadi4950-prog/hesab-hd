// حساب HD — ماژول تقویم هجری شمسی
// تمام تاریخ‌ها به‌صورت رشته‌ی «YYYY-MM-DD» شمسی ذخیره می‌شوند (نه Date و نه ساعت)،
// تا باز شدن برنامه یا تغییر منطقه زمانی هرگز تاریخ تراکنش را جابه‌جا نکند.
// الگوریتم: چرخه‌ی ۳۳ ساله (مبتنی بر jalaali-js، دامنه‌ی سال‌های -61 تا 3177).

const BREAKS = [
  -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394,
  2456, 3178,
];

export const MONTH_NAMES = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
];

// ایندکس ۰ = شنبه
export const WEEKDAY_NAMES = [
  'شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه',
];

const div = (a, b) => Math.trunc(a / b);
const mod = (a, b) => a - Math.trunc(a / b) * b;

function jalCal(jy) {
  const bl = BREAKS.length;
  const gy = jy + 621;
  let leapJ = -14;
  let jp = BREAKS[0];
  if (jy < jp || jy >= BREAKS[bl - 1]) throw new RangeError(`سال شمسی خارج از محدوده: ${jy}`);
  let jump = 0;
  for (let i = 1; i < bl; i += 1) {
    const jm = BREAKS[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ += div(jump, 33) * 8 + div(mod(jump, 33), 4);
    jp = jm;
  }
  let n = jy - jp;
  leapJ += div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
  if (mod(jump, 33) === 4 && jump - n === 4) leapJ += 1;
  const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
  const march = 20 + leapJ - leapG;
  if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
  let leap = mod(mod(n + 1, 33) - 1, 4);
  if (leap === -1) leap = 4;
  return { leap, gy, march };
}

function g2d(gy, gm, gd) {
  let d =
    div((gy + div(gm - 8, 6) + 100100) * 1461, 4) +
    div(153 * mod(gm + 9, 12) + 2, 5) +
    gd -
    34840408;
  d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}

function d2g(jdn) {
  let j = 4 * jdn + 139361631;
  j += div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  const i = div(mod(j, 1461), 4) * 5 + 308;
  const gd = div(mod(i, 153), 5) + 1;
  const gm = mod(div(i, 153), 12) + 1;
  const gy = div(j, 1461) - 100100 + div(8 - gm, 6);
  return { gy, gm, gd };
}

function j2d(jy, jm, jd) {
  const r = jalCal(jy);
  return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1;
}

function d2j(jdn) {
  const gy = d2g(jdn).gy;
  let jy = gy - 621;
  const r = jalCal(jy);
  const jdn1f = g2d(gy, 3, r.march);
  let k = jdn - jdn1f;
  if (k >= 0) {
    if (k <= 185) {
      return { jy, jm: 1 + div(k, 31), jd: mod(k, 31) + 1 };
    }
    k -= 186;
  } else {
    jy -= 1;
    k += 179;
    if (r.leap === 1) k += 1;
  }
  return { jy, jm: 7 + div(k, 30), jd: mod(k, 30) + 1 };
}

// ---------- API عمومی ----------

export function isLeapYear(jy) {
  return jalCal(jy).leap === 0;
}

export function monthLength(jy, jm) {
  if (!Number.isInteger(jm) || jm < 1 || jm > 12) throw new RangeError(`ماه نامعتبر: ${jm}`);
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isLeapYear(jy) ? 30 : 29;
}

export function isValidJalali(jy, jm, jd) {
  if (![jy, jm, jd].every(Number.isInteger)) return false;
  if (jy < -61 || jy >= 3177) return false;
  if (jm < 1 || jm > 12) return false;
  return jd >= 1 && jd <= monthLength(jy, jm);
}

export function toJalali(gy, gm, gd) {
  if (![gy, gm, gd].every(Number.isInteger)) throw new TypeError('تاریخ میلادی نامعتبر');
  return d2j(g2d(gy, gm, gd));
}

export function toGregorian(jy, jm, jd) {
  if (!isValidJalali(jy, jm, jd)) throw new RangeError(`تاریخ شمسی نامعتبر: ${jy}/${jm}/${jd}`);
  const { gy, gm, gd } = d2g(j2d(jy, jm, jd));
  return { gy, gm, gd };
}

const pad = (n, w = 2) => String(n).padStart(w, '0');

export function formatDate({ jy, jm, jd }) {
  return `${pad(jy, 4)}-${pad(jm)}-${pad(jd)}`;
}

// ورودی: «1405-07-19» یا «1405/7/19» (ارقام فارسی و عربی هم پذیرفته می‌شود)
export function parseDate(str) {
  if (typeof str !== 'string') return null;
  const latin = str
    .replace(/[۰-۹]/g, (c) => String(c.charCodeAt(0) - 0x06f0))
    .replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 0x0660))
    .trim();
  const m = /^(\d{3,4})[-/](\d{1,2})[-/](\d{1,2})$/.exec(latin);
  if (!m) return null;
  const jy = Number(m[1]);
  const jm = Number(m[2]);
  const jd = Number(m[3]);
  return isValidJalali(jy, jm, jd) ? { jy, jm, jd } : null;
}

export function isValidDateString(str) {
  return parseDate(str) !== null;
}

function toJdn(dateStr) {
  const p = parseDate(dateStr);
  if (!p) throw new RangeError(`تاریخ نامعتبر: ${dateStr}`);
  return j2d(p.jy, p.jm, p.jd);
}

function fromJdn(jdn) {
  return formatDate(d2j(jdn));
}

export function compareDates(a, b) {
  const x = toJdn(a);
  const y = toJdn(b);
  return x === y ? 0 : x < y ? -1 : 1;
}

export function addDays(dateStr, n) {
  return fromJdn(toJdn(dateStr) + n);
}

export function diffDays(a, b) {
  return toJdn(a) - toJdn(b);
}

// ۰ = شنبه ... ۶ = جمعه
export function weekdayIndex(dateStr) {
  return mod(toJdn(dateStr) + 2, 7);
}

export function weekdayName(dateStr) {
  return WEEKDAY_NAMES[weekdayIndex(dateStr)];
}

// هفته‌ی شمسی از شنبه شروع می‌شود و به جمعه ختم می‌شود
export function weekRange(dateStr) {
  const start = addDays(dateStr, -weekdayIndex(dateStr));
  return { from: start, to: addDays(start, 6) };
}

export function monthRange(jy, jm) {
  return { from: formatDate({ jy, jm, jd: 1 }), to: formatDate({ jy, jm, jd: monthLength(jy, jm) }) };
}

export function yearRange(jy) {
  return { from: formatDate({ jy, jm: 1, jd: 1 }), to: formatDate({ jy, jm: 12, jd: monthLength(jy, 12) }) };
}

export function addMonths(dateStr, n) {
  const p = parseDate(dateStr);
  if (!p) throw new RangeError(`تاریخ نامعتبر: ${dateStr}`);
  const total = p.jy * 12 + (p.jm - 1) + n;
  const jy = Math.floor(total / 12);
  const jm = mod(total, 12) + 1;
  const jd = Math.min(p.jd, monthLength(jy, jm));
  return formatDate({ jy, jm, jd });
}

export function formatLong(dateStr) {
  const p = parseDate(dateStr);
  if (!p) throw new RangeError(`تاریخ نامعتبر: ${dateStr}`);
  return `${weekdayName(dateStr)} ${p.jd} ${MONTH_NAMES[p.jm - 1]} ${p.jy}`;
}

export function listDates(from, to) {
  const out = [];
  const end = toJdn(to);
  for (let j = toJdn(from); j <= end; j += 1) out.push(fromJdn(j));
  return out;
}

// تاریخ «امروز» در یک منطقه‌ی زمانی مشخص (پیش‌فرض: تهران). فقط هنگام ثبت محاسبه می‌شود
// و بعد از ذخیره، تاریخ تراکنش یک رشته‌ی ثابت است.
export function todayJalali(now = new Date(), timeZone = 'Asia/Tehran') {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(now);
  const get = (t) => Number(parts.find((p) => p.type === t).value);
  const { jy, jm, jd } = toJalali(get('year'), get('month'), get('day'));
  return formatDate({ jy, jm, jd });
}

export function fromGregorianDate(gy, gm, gd) {
  return formatDate(toJalali(gy, gm, gd));
}
