import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as J from '../src/core/jalali.js';

test('تبدیل نقاط مرجع شمسی ↔ میلادی', () => {
  const anchors = [
    [[1405, 1, 1], [2026, 3, 21]],
    [[1404, 1, 1], [2025, 3, 21]],
    [[1403, 1, 1], [2024, 3, 20]],
    [[1400, 1, 1], [2021, 3, 21]],
    [[1378, 10, 11], [2000, 1, 1]],
    [[1357, 11, 22], [1979, 2, 11]],
    [[1405, 7, 19], [2026, 10, 11]],
  ];
  for (const [[jy, jm, jd], [gy, gm, gd]] of anchors) {
    assert.deepEqual(J.toGregorian(jy, jm, jd), { gy, gm, gd }, `${jy}/${jm}/${jd} → میلادی`);
    assert.deepEqual(J.toJalali(gy, gm, gd), { jy, jm, jd }, `${gy}-${gm}-${gd} → شمسی`);
  }
});

test('سال کبیسه شمسی', () => {
  const leaps = [1375, 1379, 1383, 1387, 1391, 1395, 1399, 1403, 1408, 1412];
  for (const y of leaps) assert.equal(J.isLeapYear(y), true, `${y} باید کبیسه باشد`);
  for (const y of [1400, 1401, 1402, 1404, 1405, 1406, 1407, 1409, 1410, 1411]) {
    assert.equal(J.isLeapYear(y), false, `${y} نباید کبیسه باشد`);
  }
});

test('طول ماه‌ها و روز ۳۰ اسفند', () => {
  assert.equal(J.monthLength(1405, 1), 31);
  assert.equal(J.monthLength(1405, 6), 31);
  assert.equal(J.monthLength(1405, 7), 30);
  assert.equal(J.monthLength(1405, 11), 30);
  assert.equal(J.monthLength(1403, 12), 30);
  assert.equal(J.monthLength(1404, 12), 29);
  assert.equal(J.isValidJalali(1403, 12, 30), true);
  assert.equal(J.isValidJalali(1404, 12, 30), false);
  assert.equal(J.isValidJalali(1405, 7, 31), false);
  assert.equal(J.isValidJalali(1405, 13, 1), false);
  assert.equal(J.isValidJalali(1405, 0, 1), false);
  assert.equal(J.isValidJalali(1405, 1, 0), false);
});

test('گذر از آخر سال کبیسه و غیرکبیسه', () => {
  assert.equal(J.addDays('1403-12-29', 1), '1403-12-30');
  assert.equal(J.addDays('1403-12-30', 1), '1404-01-01');
  assert.equal(J.addDays('1404-12-29', 1), '1405-01-01');
  assert.equal(J.addDays('1405-01-01', -1), '1404-12-29');
  assert.equal(J.addDays('1404-01-01', -1), '1403-12-30');
  assert.deepEqual(J.toGregorian(1403, 12, 30), { gy: 2025, gm: 3, gd: 20 });
});

test('رفت‌وبرگشت روزبه‌روز در بازه‌ی ۱۳۰۰ تا ۱۵۰۰ و پیوستگی روزها', () => {
  let date = '1300-01-01';
  let prev = J.toGregorian(1300, 1, 1);
  let weekday = J.weekdayIndex(date);
  const prevUtc = Date.UTC(prev.gy, prev.gm - 1, prev.gd);
  let lastUtc = prevUtc;
  let count = 0;
  while (date !== '1501-01-01') {
    const p = J.parseDate(date);
    const g = J.toGregorian(p.jy, p.jm, p.jd);
    assert.deepEqual(J.toJalali(g.gy, g.gm, g.gd), p, `رفت‌وبرگشت ${date}`);
    const utc = Date.UTC(g.gy, g.gm - 1, g.gd);
    if (count > 0) assert.equal(utc - lastUtc, 86400000, `پیوستگی میلادی در ${date}`);
    lastUtc = utc;
    assert.equal(J.weekdayIndex(date), weekday, `چرخه‌ی هفته در ${date}`);
    weekday = (weekday + 1) % 7;
    date = J.addDays(date, 1);
    count += 1;
  }
  // مجموع روزها = ۲۰۱ سال × ۳۶۵ + تعداد سال‌های کبیسه
  let leaps = 0;
  for (let y = 1300; y <= 1500; y += 1) if (J.isLeapYear(y)) leaps += 1;
  assert.equal(count, 201 * 365 + leaps);
});

test('طول هر سال برابر فاصله‌ی نوروزها است', () => {
  for (let y = 1350; y < 1450; y += 1) {
    const len = J.diffDays(`${y + 1}-01-01`, `${y}-01-01`);
    assert.equal(len, J.isLeapYear(y) ? 366 : 365, `طول سال ${y}`);
  }
});

test('روز هفته (شنبه = ۰)', () => {
  assert.equal(J.weekdayIndex('1378-10-11'), 0); // شنبه، ۱ ژانویه ۲۰۰۰
  assert.equal(J.weekdayName('1378-10-11'), 'شنبه');
  assert.equal(J.weekdayName('1405-07-19'), 'یکشنبه'); // ۱۱ اکتبر ۲۰۲۶
  assert.equal(J.weekdayName('1400-01-01'), 'یکشنبه'); // ۲۱ مارس ۲۰۲۱
  assert.equal(J.weekdayName('1405-07-24'), 'جمعه');
});

test('مرز هفته، ماه و سال', () => {
  assert.deepEqual(J.weekRange('1405-07-19'), { from: '1405-07-18', to: '1405-07-24' });
  assert.deepEqual(J.weekRange('1405-07-18'), { from: '1405-07-18', to: '1405-07-24' }); // شنبه
  assert.deepEqual(J.weekRange('1405-07-24'), { from: '1405-07-18', to: '1405-07-24' }); // جمعه
  // هفته‌ای که از سال قبل شروع می‌شود
  const w = J.weekRange('1405-01-01'); // ۲۱ مارس ۲۰۲۶ = شنبه
  assert.equal(J.weekdayName('1405-01-01'), 'شنبه');
  assert.deepEqual(w, { from: '1405-01-01', to: '1405-01-07' });
  // آخرین روز سال ۱۴۰۴ جمعه است؛ هفته‌اش از ۲۳ اسفند شروع می‌شود و با سال جدید قاطی نمی‌شود
  assert.equal(J.weekdayName('1404-12-29'), 'جمعه');
  assert.deepEqual(J.weekRange('1404-12-29'), { from: '1404-12-23', to: '1404-12-29' });
  // هفته‌ای که از وسط یک ماه به ماه بعد می‌رسد
  assert.deepEqual(J.weekRange('1405-07-28'), { from: '1405-07-25', to: '1405-08-01' });
  assert.deepEqual(J.monthRange(1405, 7), { from: '1405-07-01', to: '1405-07-30' });
  assert.deepEqual(J.monthRange(1403, 12), { from: '1403-12-01', to: '1403-12-30' });
  assert.deepEqual(J.monthRange(1404, 12), { from: '1404-12-01', to: '1404-12-29' });
  assert.deepEqual(J.yearRange(1403), { from: '1403-01-01', to: '1403-12-30' });
  assert.deepEqual(J.yearRange(1404), { from: '1404-01-01', to: '1404-12-29' });
});

test('افزودن ماه با حفظ پایان ماه', () => {
  assert.equal(J.addMonths('1405-06-31', 1), '1405-07-30');
  assert.equal(J.addMonths('1405-01-31', 1), '1405-02-31');
  assert.equal(J.addMonths('1403-12-30', 12), '1404-12-29');
  assert.equal(J.addMonths('1405-07-15', -7), '1404-12-15');
  assert.equal(J.addMonths('1405-12-01', 1), '1406-01-01');
});

test('تجزیه و قالب‌بندی تاریخ، ارقام فارسی و عربی', () => {
  assert.deepEqual(J.parseDate('1405-07-19'), { jy: 1405, jm: 7, jd: 19 });
  assert.deepEqual(J.parseDate('1405/7/19'), { jy: 1405, jm: 7, jd: 19 });
  assert.deepEqual(J.parseDate('۱۴۰۵/۰۷/۱۹'), { jy: 1405, jm: 7, jd: 19 });
  assert.deepEqual(J.parseDate('١٤٠٥-٠٧-١٩'), { jy: 1405, jm: 7, jd: 19 });
  for (const bad of ['1404-12-30', '1405-13-01', '1405-00-10', 'abc', '', '1405-07', null, undefined, 14050719]) {
    assert.equal(J.parseDate(bad), null, `باید نامعتبر باشد: ${String(bad)}`);
  }
  assert.equal(J.formatDate({ jy: 1405, jm: 7, jd: 9 }), '1405-07-09');
  assert.equal(J.formatLong('1405-07-19'), 'یکشنبه 19 مهر 1405');
});

test('مقایسه و فاصله‌ی تاریخ‌ها', () => {
  assert.equal(J.compareDates('1405-07-19', '1405-07-19'), 0);
  assert.equal(J.compareDates('1405-07-18', '1405-07-19'), -1);
  assert.equal(J.compareDates('1406-01-01', '1405-12-29'), 1);
  assert.equal(J.diffDays('1405-07-19', '1405-07-01'), 18);
  assert.throws(() => J.compareDates('xx', '1405-01-01'), RangeError);
});

test('فهرست روزهای یک بازه', () => {
  const days = J.listDates('1404-12-28', '1405-01-02');
  assert.deepEqual(days, ['1404-12-28', '1404-12-29', '1405-01-01', '1405-01-02']);
  assert.equal(J.listDates('1405-07-01', '1405-07-30').length, 30);
});

test('«امروز» با منطقه‌ی زمانی تهران (مرز نیمه‌شب)', () => {
  // نیمه‌شب تهران = ۲۰:۳۰ UTC (ساعت تابستانی در ایران حذف شده است)
  assert.equal(J.todayJalali(new Date('2026-03-20T20:29:59Z'), 'Asia/Tehran'), '1404-12-29');
  assert.equal(J.todayJalali(new Date('2026-03-20T20:30:00Z'), 'Asia/Tehran'), '1405-01-01');
  assert.equal(J.todayJalali(new Date('2026-10-11T09:00:00Z'), 'Asia/Tehran'), '1405-07-19');
  // همان لحظه در UTC یک روز عقب‌تر است؛ تاریخ ذخیره‌شده نباید به منطقه‌ی زمانی دستگاه وابسته باشد
  assert.equal(J.todayJalali(new Date('2026-03-20T22:00:00Z'), 'UTC'), '1404-12-29');
});

test('خطا برای ورودی نامعتبر', () => {
  assert.throws(() => J.toGregorian(1404, 12, 30), RangeError);
  assert.throws(() => J.monthLength(1405, 13), RangeError);
  assert.throws(() => J.toJalali(2026.5, 1, 1), TypeError);
  assert.throws(() => J.isLeapYear(5000), RangeError);
});
