import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as L from '../src/core/ledger.js';
import * as R from '../src/core/reports.js';
import * as FX from '../src/core/fx.js';
import * as J from '../src/core/jalali.js';
import * as M from '../src/core/money.js';
import { Book } from './helpers.js';

const FOOD = 'cat-expense-food';
const TRANSPORT = 'cat-expense-transport';
const BILLS = 'cat-expense-bills';
const SALARY = 'cat-income-salary';

// سناریوی ثابت (مهر ۱۴۰۵؛ ۱۸ مهر شنبه است):
//  نقد  : اولیه ۱٬۰۰۰٬۰۰۰ | بانک: اولیه ۵٬۰۰۰٬۰۰۰ | ارزی: اولیه ۱۰۰٫۰۰ دلار
function scenario() {
  const b = new Book();
  const cash = b.account('نقد', { opening: 1_000_000 });
  const bank = b.account('بانک', { opening: 5_000_000, type: 'bank' });
  const usd = b.account('ارزی', { currency: 'USD', type: 'fx', opening: 10_000 });
  const t = {};
  t.salary = b.tx({ type: 'income', amount: 10_000_000, date: '1405-07-18', accountId: bank.id, categoryId: SALARY, note: 'حقوق' });
  t.food1 = b.tx({ type: 'expense', amount: 150_000, date: '1405-07-18', accountId: cash.id, categoryId: FOOD });
  t.food2 = b.tx({ type: 'expense', amount: 250_000, date: '1405-07-19', accountId: cash.id, categoryId: FOOD });
  t.bus = b.tx({ type: 'expense', amount: 100_000, date: '1405-07-19', accountId: cash.id, categoryId: TRANSPORT });
  t.transfer = b.tx({ type: 'transfer', amount: 2_000_000, date: '1405-07-20', fromAccountId: bank.id, toAccountId: cash.id });
  t.bills = b.tx({ type: 'expense', amount: 700_000, date: '1405-07-25', accountId: bank.id, categoryId: BILLS });
  t.old = b.tx({ type: 'expense', amount: 400_000, date: '1405-06-30', accountId: cash.id, categoryId: FOOD });
  t.fun = b.tx({ type: 'expense', amount: 1_500, date: '1405-07-19', accountId: usd.id, categoryId: 'cat-expense-fun' });
  const debt = b.debt({ direction: 'owe', person: 'علی', principal: 1_000_000, date: '1405-07-10' });
  t.pay = b.tx({ type: 'debt_payment', amount: 300_000, date: '1405-07-21', accountId: bank.id, debtId: debt.id });
  return { b, cash, bank, usd, debt, t };
}

const MEHR = { from: '1405-07-01', to: '1405-07-30' };

test('خلاصه‌ی ماه: انتقال، پرداخت بدهی و ارز دیگر دوباره‌شماری نمی‌شوند', () => {
  const { b } = scenario();
  const s = R.summarize(b.state, MEHR);
  assert.equal(s.income, 10_000_000);
  assert.equal(s.expense, 1_200_000); // ۱۵۰ + ۲۵۰ + ۱۰۰ + ۷۰۰ هزار (نه ۴۰۰ هزار شهریور، نه دلار، نه انتقال، نه پرداخت بدهی)
  assert.equal(s.net, 8_800_000);
  assert.equal(s.incomeCount, 1);
  assert.equal(s.expenseCount, 4);
  assert.equal(s.days, 30);
  assert.equal(s.avgDailyExpense, 40_000);
  assert.equal(s.avgDailyIncome, 333_333);
  assert.equal(s.excludedTransfers, 1);
  assert.equal(s.debtPaidOut, 300_000);
  assert.equal(s.debtReceived, 0);
  assert.equal(s.hasData, true);
  assert.deepEqual(
    s.expenseByCategory.map((c) => [c.categoryId, c.total, c.count, c.shareBp]),
    [[BILLS, 700_000, 1, 5833], [FOOD, 400_000, 2, 3333], [TRANSPORT, 100_000, 1, 833]],
  );
  assert.deepEqual(s.incomeByCategory.map((c) => [c.categoryId, c.total, c.shareBp]), [[SALARY, 10_000_000, 10000]]);
  assert.equal(s.expenseByCategory[0].name, 'قبوض');
});

test('خلاصه‌ی هفته، روز، ماه قبل، ماه بدون تراکنش و ارز دلار', () => {
  const { b } = scenario();
  const week = R.summarize(b.state, { from: '1405-07-18', to: '1405-07-24' });
  assert.equal(week.income, 10_000_000);
  assert.equal(week.expense, 500_000);
  assert.equal(week.net, 9_500_000);
  assert.equal(week.excludedTransfers, 1);
  const day = R.summarize(b.state, { from: '1405-07-19', to: '1405-07-19' });
  assert.equal(day.expense, 350_000);
  assert.equal(day.income, 0);
  assert.equal(day.days, 1);
  const prev = R.summarize(b.state, J.monthRange(1405, 6));
  assert.equal(prev.expense, 400_000);
  assert.equal(prev.income, 0);
  // ماه بدون هیچ تراکنش
  const empty = R.summarize(b.state, J.monthRange(1405, 8));
  assert.equal(empty.hasData, false);
  assert.equal(empty.expense, 0);
  assert.equal(empty.income, 0);
  assert.equal(empty.net, 0);
  assert.deepEqual(empty.expenseByCategory, []);
  assert.equal(empty.avgDailyExpense, 0);
  // ارز دلار جداگانه است و با تومان جمع نمی‌شود
  const usd = R.summarize(b.state, { ...MEHR, currency: 'USD' });
  assert.equal(usd.expense, 1_500);
  assert.equal(usd.income, 0);
  assert.equal(usd.currency, 'USD');
  // فیلتر دسته و حساب
  assert.equal(R.summarize(b.state, { ...MEHR, categoryId: FOOD }).expense, 400_000);
  const cashId = b.state.accounts[0].id;
  assert.equal(R.summarize(b.state, { ...MEHR, accountId: cashId }).expense, 500_000);
});

test('موجودی حساب‌ها و جمع کل به تفکیک ارز، و همانی حسابداری', () => {
  const { b, cash, bank, usd } = scenario();
  assert.equal(b.balance(cash.id), 2_100_000);
  assert.equal(b.balance(bank.id), 12_000_000);
  assert.equal(b.balance(usd.id), 8_500);
  assert.deepEqual(L.totalBalances(b.state), { IRT: 14_100_000, USD: 8_500 });
  // همانی: جمع موجودی = موجودی‌های اولیه + درآمد − هزینه − پرداخت بدهی (انتقال اثر خالص صفر)
  const all = R.summarize(b.state, { from: '1405-01-01', to: '1405-12-29' });
  assert.equal(6_000_000 + all.income - all.expense - all.debtPaidOut, 14_100_000);
});

test('سری روزانه: همه‌ی روزها حتی بدون تراکنش و جمع برابر خلاصه', () => {
  const { b } = scenario();
  const days = R.series(b.state, { from: '1405-07-18', to: '1405-07-24', granularity: 'day' });
  assert.equal(days.length, 7);
  assert.deepEqual(days.map((d) => d.expense), [150_000, 350_000, 0, 0, 0, 0, 0]);
  assert.deepEqual(days.map((d) => d.income), [10_000_000, 0, 0, 0, 0, 0, 0]);
  assert.deepEqual(days.map((d) => d.net), [9_850_000, -350_000, 0, 0, 0, 0, 0]);
  const sum = (k) => days.reduce((a, d) => a + d[k], 0);
  const week = R.summarize(b.state, { from: '1405-07-18', to: '1405-07-24' });
  assert.equal(sum('income'), week.income);
  assert.equal(sum('expense'), week.expense);
});

test('سری هفتگی (شروع شنبه)، ماهانه و سالانه', () => {
  const { b } = scenario();
  const weeks = R.series(b.state, { ...MEHR, granularity: 'week' });
  assert.deepEqual(weeks.map((w) => w.key), ['1405-06-28', '1405-07-04', '1405-07-11', '1405-07-18', '1405-07-25']);
  assert.ok(weeks.every((w) => J.weekdayName(w.from) === 'شنبه' && J.weekdayName(w.to) === 'جمعه'));
  assert.deepEqual(weeks.map((w) => w.expense), [0, 0, 0, 500_000, 700_000]);
  assert.deepEqual(weeks.map((w) => w.income), [0, 0, 0, 10_000_000, 0]);
  const month = R.summarize(b.state, MEHR);
  assert.equal(weeks.reduce((a, w) => a + w.expense, 0), month.expense);
  // هفته‌ی نیمه‌کاره فقط تراکنش‌های داخل بازه را می‌شمارد
  const clipped = R.series(b.state, { from: '1405-07-19', to: '1405-07-19', granularity: 'week' });
  assert.equal(clipped.length, 1);
  assert.equal(clipped[0].expense, 350_000);
  const months = R.series(b.state, { from: '1405-06-01', to: '1405-08-30', granularity: 'month' });
  assert.deepEqual(months.map((m) => m.key), ['1405-06', '1405-07', '1405-08']);
  assert.deepEqual(months.map((m) => m.expense), [400_000, 1_200_000, 0]);
  assert.deepEqual(months.map((m) => m.count), [1, 5, 0]);
  const years = R.series(b.state, { from: '1405-01-01', to: '1405-12-29', granularity: 'year' });
  assert.equal(years.length, 1);
  assert.equal(years[0].expense, 1_600_000);
  assert.equal(years[0].income, 10_000_000);
  assert.throws(() => R.series(b.state, { from: '1405-07-10', to: '1405-07-01', granularity: 'day' }), RangeError);
  assert.throws(() => R.series(b.state, { ...MEHR, granularity: 'hour' }), RangeError);
});

test('تغییر موجودی در طول زمان و انتقال داخلی با اثر صفر', () => {
  const { b } = scenario();
  const pts = R.balanceOverTime(b.state, { from: '1405-07-17', to: '1405-07-25' });
  assert.deepEqual(
    pts.map((p) => [p.date, p.balance]),
    [
      ['1405-07-17', 5_600_000],
      ['1405-07-18', 15_450_000],
      ['1405-07-19', 15_100_000],
      ['1405-07-20', 15_100_000], // انتقال بین دو حساب خودم، مجموع را تغییر نمی‌دهد
      ['1405-07-21', 14_800_000],
      ['1405-07-22', 14_800_000],
      ['1405-07-23', 14_800_000],
      ['1405-07-24', 14_800_000],
      ['1405-07-25', 14_100_000],
    ],
  );
  assert.equal(pts[pts.length - 1].balance, L.totalBalances(b.state).IRT);
  const usd = R.balanceOverTime(b.state, { from: '1405-07-18', to: '1405-07-20', currency: 'USD' });
  assert.deepEqual(usd.map((p) => p.balance), [10_000, 8_500, 8_500]);
  // فقط یک حساب
  const cashOnly = R.balanceOverTime(b.state, { from: '1405-07-20', to: '1405-07-20', accountIds: [b.state.accounts[0].id] });
  assert.equal(cashOnly[0].balance, 2_100_000);
});

test('مقایسه‌ی ماه جاری با ماه‌های قبل', () => {
  const { b } = scenario();
  const c = R.monthComparison(b.state, { jy: 1405, jm: 7, months: 3 });
  assert.deepEqual(c.rows.map((r) => [r.jm, r.expense, r.income]), [[5, 0, 0], [6, 400_000, 0], [7, 1_200_000, 10_000_000]]);
  assert.equal(c.rows[2].label, 'مهر 1405');
  assert.equal(c.expenseDelta, 800_000);
  assert.equal(c.incomeDelta, 10_000_000);
  assert.deepEqual(c.rows.map((r) => r.hasData), [false, true, true]);
  // عبور از مرز سال
  const y = R.monthComparison(b.state, { jy: 1405, jm: 1, months: 2 });
  assert.deepEqual(y.rows.map((r) => [r.jy, r.jm]), [[1404, 12], [1405, 1]]);
});

test('بودجه: مصرف، باقی‌مانده، درصد، هشدار و مرزها', () => {
  const { b } = scenario();
  b.budget({ categoryId: null, period: 'monthly', limit: 2_000_000, effectiveFrom: '1405-07-01' });
  b.budget({ categoryId: FOOD, period: 'monthly', limit: 450_000, effectiveFrom: '1405-07-01' });
  b.budget({ categoryId: FOOD, period: 'weekly', limit: 300_000, effectiveFrom: '1405-07-01' });
  b.budget({ categoryId: TRANSPORT, period: 'daily', limit: 100_000, effectiveFrom: '1405-07-01' });
  const st = R.budgetStatuses(b.state, '1405-07-19');
  const by = (cat, period) => st.find((s) => s.budget.categoryId === cat && s.budget.period === period);
  const total = by(null, 'monthly');
  assert.equal(total.title, 'کل هزینه‌ها');
  assert.equal(total.spent, 1_200_000);
  assert.equal(total.remaining, 800_000);
  assert.equal(total.usedBp, 6000);
  assert.equal(total.level, 'ok');
  const foodM = by(FOOD, 'monthly');
  assert.equal(foodM.spent, 400_000);
  assert.equal(foodM.remaining, 50_000);
  assert.equal(foodM.usedBp, 8889);
  assert.equal(foodM.level, 'warning');
  const foodW = by(FOOD, 'weekly');
  assert.deepEqual(foodW.range, { from: '1405-07-18', to: '1405-07-24' });
  assert.equal(foodW.spent, 400_000);
  assert.equal(foodW.remaining, -100_000);
  assert.equal(foodW.overBy, 100_000);
  assert.equal(foodW.level, 'exceeded');
  const busD = by(TRANSPORT, 'daily');
  assert.equal(busD.spent, 100_000);
  assert.equal(busD.usedBp, 10000);
  assert.equal(busD.level, 'warning'); // دقیقاً برابر سقف: هنوز «بیش از سقف» نیست
  assert.equal(busD.overBy, 0);
  // روزی که تراکنشی ندارد
  const quiet = R.budgetStatuses(b.state, '1405-07-22').find((s) => s.budget.categoryId === TRANSPORT);
  assert.equal(quiet.spent, 0);
  assert.equal(quiet.usedBp, 0);
  assert.equal(quiet.level, 'ok');
});

test('بودجه: تغییر سقف گذشته را با سقف همان زمان می‌سنجد', () => {
  const { b } = scenario();
  b.budget({ categoryId: FOOD, period: 'monthly', limit: 450_000, effectiveFrom: '1405-07-01' });
  b.budget({ categoryId: FOOD, period: 'monthly', limit: 600_000, effectiveFrom: '1405-07-25' });
  const early = R.budgetStatuses(b.state, '1405-07-20')[0];
  const late = R.budgetStatuses(b.state, '1405-07-26')[0];
  assert.equal(early.limit, 450_000);
  assert.equal(early.level, 'warning');
  assert.equal(late.limit, 600_000);
  assert.equal(late.level, 'ok');
  assert.equal(early.spent, late.spent); // تراکنش‌ها دست‌نخورده‌اند
  assert.equal(R.budgetStatuses(b.state, '1405-06-15').length, 0);
});

test('ارزش دلاری: محاسبه‌شده از در انتظار جدا و نرخ‌ها مشخص است', () => {
  const { b } = scenario();
  let r = R.usdReport(b.state);
  assert.equal(r.doneCount, 0);
  assert.equal(r.pendingCount, 6); // ۱ درآمد + ۵ هزینه‌ی تومانی
  assert.equal(r.pendingToman, 10_000_000 + 150_000 + 250_000 + 100_000 + 700_000 + 400_000);
  assert.equal(r.nativeUsdExpenseCents, 1_500);
  assert.deepEqual(r.rates, []);
  // محاسبه با نرخ دستی
  const a = FX.applyManualRate(b.state, 100_000, '2026-10-11T10:00:00.000Z');
  b.set(a.state);
  assert.equal(a.updated, 6);
  r = R.usdReport(b.state);
  assert.equal(r.doneCount, 6);
  assert.equal(r.pendingCount, 0);
  assert.equal(r.incomeCents, 10_000);
  assert.equal(r.expenseCents, 150 + 250 + 100 + 700 + 400);
  assert.equal(r.rates.length, 1);
  assert.deepEqual({ ...r.rates[0] }, { rate: 100_000, rateAt: '2026-10-11T10:00:00.000Z', source: 'دستی', manual: true, count: 6 });
  // تراکنش جدید در انتظار می‌ماند و با نرخ دیگری محاسبه می‌شود
  const cashId = b.state.accounts[0].id;
  b.tx({ type: 'expense', amount: 123_456, date: '1405-07-26', accountId: cashId, categoryId: FOOD });
  r = R.usdReport(b.state);
  assert.equal(r.pendingCount, 1);
  assert.equal(r.pendingToman, 123_456);
  b.set(FX.applyManualRate(b.state, 125_000, '2026-10-11T12:00:00.000Z').state);
  r = R.usdReport(b.state);
  assert.equal(r.rates.length, 2);
  assert.equal(r.rates[0].rate, 125_000); // جدیدترین نرخ اول
  assert.equal(r.expenseCents, 1600 + 99); // ۱۲۳٬۴۵۶ ÷ ۱۲۵٬۰۰۰ = ۰٫۹۸۷۶۵ دلار → ۹۹ سنت
  // بازه‌ی محدود
  const only = R.usdReport(b.state, { from: '1405-07-26', to: '1405-07-26' });
  assert.equal(only.doneCount, 1);
  assert.equal(only.expenseCents, 99);
});

test('داشبورد: حالت خالی بدون عدد ساختگی', () => {
  const b = new Book();
  const d = R.dashboard(b.state, '1405-07-19');
  assert.equal(d.isEmpty, true);
  assert.deepEqual(d.totals, {});
  assert.deepEqual(d.accounts, []);
  assert.deepEqual(d.recent, []);
  assert.deepEqual(d.budgets, []);
  assert.deepEqual(d.goals, []);
  assert.equal(d.pendingUsdCount, 0);
  assert.equal(d.byCurrency.IRT.today.expense, 0);
  assert.equal(d.byCurrency.IRT.month.hasData, false);
  assert.deepEqual(d.topCategories, []);
  assert.equal(d.trend.rows.length, 6);
  assert.ok(d.trend.rows.every((r) => r.income === 0 && r.expense === 0 && !r.hasData));
});

test('داشبورد: اعداد دقیقاً از داده‌ی ذخیره‌شده محاسبه می‌شوند', () => {
  const { b } = scenario();
  b.budget({ categoryId: null, period: 'monthly', limit: 2_000_000, effectiveFrom: '1405-07-01' });
  const g = b.goal({ name: 'سفر', targetAmount: 1_000_000 });
  b.set(L.addGoalContribution(b.state, g.id, { amount: 250_000, date: '1405-07-19' }, b.ctx).state);
  const d = R.dashboard(b.state, '1405-07-19');
  assert.equal(d.isEmpty, false);
  assert.deepEqual(d.totals, { IRT: 14_100_000, USD: 8_500 });
  assert.equal(d.accounts.length, 3);
  assert.equal(d.byCurrency.IRT.today.expense, 350_000);
  assert.equal(d.byCurrency.IRT.today.income, 0);
  assert.equal(d.byCurrency.IRT.today.net, -350_000);
  assert.equal(d.byCurrency.IRT.week.expense, 500_000);
  assert.equal(d.byCurrency.IRT.week.income, 10_000_000);
  assert.equal(d.byCurrency.IRT.month.expense, 1_200_000);
  assert.equal(d.byCurrency.USD.month.expense, 1_500);
  assert.equal(d.budgets.length, 1);
  assert.equal(d.budgets[0].usedBp, 6000);
  assert.equal(d.goals[0].saved, 250_000);
  assert.equal(d.goals[0].progressBp, 2500);
  assert.deepEqual(d.debts.owe, { IRT: 700_000 });
  assert.equal(d.recent.length, 9); // سناریو ۹ تراکنش دارد (کمتر از سقف ۱۰ تایی)
  assert.ok(d.recent.every((t, i, a) => i === 0 || a[i - 1].date >= t.date));
  assert.equal(R.dashboard(b.state, '1405-07-19', { recent: 3 }).recent.length, 3);
  assert.equal(d.topCategories[0].categoryId, BILLS);
  assert.equal(d.pendingUsdCount, 6);
  assert.equal(d.trend.rows.length, 6);
});

test('ویرایش و حذف، همه‌ی اعداد وابسته را درست به‌روز می‌کند', () => {
  const { b, cash, bank, t } = scenario();
  // ویرایش مبلغ هزینه
  b.update(t.food2.id, { amount: 300_000 });
  assert.equal(R.summarize(b.state, MEHR).expense, 1_250_000);
  assert.equal(b.balance(cash.id), 2_050_000);
  assert.equal(R.summarize(b.state, MEHR).expenseByCategory.find((c) => c.categoryId === FOOD).total, 450_000);
  // ویرایش انتقال: درآمد/هزینه عوض نمی‌شود، موجودی دو حساب عوض می‌شود
  const before = R.summarize(b.state, MEHR);
  b.update(t.transfer.id, { amount: 1_000_000 });
  const after = R.summarize(b.state, MEHR);
  assert.equal(after.income, before.income);
  assert.equal(after.expense, before.expense);
  assert.equal(b.balance(bank.id), 13_000_000);
  assert.equal(b.balance(cash.id), 1_050_000);
  assert.deepEqual(L.totalBalances(b.state), { IRT: 14_050_000, USD: 8_500 });
  // حذف تراکنش‌ها
  b.remove(t.bills.id);
  assert.equal(R.summarize(b.state, MEHR).expense, 550_000);
  assert.equal(R.series(b.state, { ...MEHR, granularity: 'week' }).at(-1).expense, 0);
  b.remove(t.transfer.id);
  assert.equal(b.balance(cash.id), 50_000);
  assert.equal(b.balance(bank.id), 14_700_000);
  assert.equal(R.summarize(b.state, MEHR).excludedTransfers, 0);
  // تغییر نوع هزینه به درآمد
  b.update(t.bus.id, { type: 'income', categoryId: SALARY });
  const s = R.summarize(b.state, MEHR);
  assert.equal(s.income, 10_100_000);
  assert.equal(s.expense, 450_000);
});

// ---------- آزمون تصادفی با داده‌ی بذردار ----------

function lcg(seed) {
  let s = seed >>> 0;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 2 ** 32;
  };
}

function checkInvariants(b, openingTotal, label) {
  const from = '1405-01-01';
  const to = '1405-12-29';
  const all = R.summarize(b.state, { from, to });
  // ۱) جمع موجودی‌ها = اولیه + درآمد − هزینه (انتقال‌ها اثر خالص صفر دارند)
  assert.equal(L.totalBalances(b.state).IRT, openingTotal + all.income - all.expense, `${label}: همانی موجودی`);
  // ۲) هر سه گام سری با خلاصه‌ی کل برابر است
  for (const g of ['day', 'week', 'month', 'year']) {
    const s = R.series(b.state, { from, to, granularity: g });
    assert.equal(s.reduce((a, x) => a + x.income, 0), all.income, `${label}: درآمد ${g}`);
    assert.equal(s.reduce((a, x) => a + x.expense, 0), all.expense, `${label}: هزینه ${g}`);
    assert.equal(s.reduce((a, x) => a + x.count, 0), all.count, `${label}: تعداد ${g}`);
  }
  // ۳) مجموع دسته‌ها = کل هزینه/درآمد
  assert.equal(all.expenseByCategory.reduce((a, c) => a + c.total, 0), all.expense, `${label}: مجموع دسته‌های هزینه`);
  assert.equal(all.incomeByCategory.reduce((a, c) => a + c.total, 0), all.income, `${label}: مجموع دسته‌های درآمد`);
  // ۴) موجودی روز آخر نمودار = مجموع موجودی
  const pts = R.balanceOverTime(b.state, { from: '1405-12-28', to: '1405-12-29' });
  assert.equal(pts.at(-1).balance, L.totalBalances(b.state).IRT, `${label}: موجودی نمودار`);
}

test('تصادفی: ۳۰۰ تراکنش با انتقال، سپس ویرایش و حذف تصادفی؛ همانی‌ها همیشه برقرارند', () => {
  const rnd = lcg(20261011);
  const pick = (arr) => arr[Math.floor(rnd() * arr.length)];
  const b = new Book();
  const accounts = [b.account('الف', { opening: 1_000_000 }), b.account('ب', { opening: 250_000 }), b.account('ج', { opening: 0 })];
  const openingTotal = 1_250_000;
  const expenseCats = b.state.categories.filter((c) => c.kind === 'expense');
  const incomeCats = b.state.categories.filter((c) => c.kind === 'income');
  const randomDate = () => J.addDays('1405-01-01', Math.floor(rnd() * 365));
  const ids = [];
  for (let i = 0; i < 300; i += 1) {
    const kind = rnd();
    const amount = 1 + Math.floor(rnd() * 5_000_000);
    const date = randomDate();
    const note = `n${i}`;
    if (kind < 0.55) ids.push(b.tx({ type: 'expense', amount, date, accountId: pick(accounts).id, categoryId: pick(expenseCats).id, note }).id);
    else if (kind < 0.8) ids.push(b.tx({ type: 'income', amount, date, accountId: pick(accounts).id, categoryId: pick(incomeCats).id, note }).id);
    else {
      const from = pick(accounts);
      const to = pick(accounts.filter((a) => a.id !== from.id));
      ids.push(b.tx({ type: 'transfer', amount, date, fromAccountId: from.id, toAccountId: to.id, note }).id);
    }
  }
  assert.equal(b.state.transactions.length, 300);
  checkInvariants(b, openingTotal, 'پس از ثبت');
  // ویرایش تصادفی مبلغ/تاریخ/حساب
  for (let i = 0; i < 80; i += 1) {
    const id = pick(ids);
    const t = b.state.transactions.find((x) => x.id === id);
    if (!t) continue;
    const patch = { amount: 1 + Math.floor(rnd() * 5_000_000), date: randomDate(), note: `e${i}` };
    if (t.type === 'transfer') {
      const from = pick(accounts);
      patch.fromAccountId = from.id;
      patch.toAccountId = pick(accounts.filter((a) => a.id !== from.id)).id;
    } else {
      patch.accountId = pick(accounts).id;
    }
    b.update(id, patch, { allowDuplicate: true });
  }
  checkInvariants(b, openingTotal, 'پس از ویرایش');
  // حذف تصادفی
  for (let i = 0; i < 100; i += 1) {
    const id = pick(ids);
    if (b.state.transactions.some((x) => x.id === id)) b.remove(id);
  }
  assert.ok(b.state.transactions.length < 300);
  checkInvariants(b, openingTotal, 'پس از حذف');
  // هیچ تراکنشی ساختار نامعتبر ندارد
  for (const t of b.state.transactions) {
    assert.ok(Number.isSafeInteger(t.amount) && t.amount > 0);
    assert.ok(J.isValidDateString(t.date));
    assert.ok(M.isValidAmount(t.currency, t.amount));
  }
});
