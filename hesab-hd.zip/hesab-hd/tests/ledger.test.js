import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as L from '../src/core/ledger.js';
import * as FX from '../src/core/fx.js';
import { diffDays as J_DIFF } from '../src/core/jalali.js';
import { Book, deepFreeze, makeCtx } from './helpers.js';

const M_TOO_BIG = 1_000_000_000_000_001;

const throwsCode = (fn, code, field) => {
  try {
    fn();
  } catch (e) {
    assert.equal(e.name, 'ValidationError', `انتظار ValidationError بود، آمد: ${e.name}: ${e.message}`);
    assert.equal(e.code, code);
    if (field) assert.ok(e.errors.some((x) => x.field === field), `خطا برای فیلد ${field} نیامد: ${JSON.stringify(e.errors)}`);
    return e;
  }
  assert.fail('انتظار خطا بود ولی خطایی رخ نداد');
};

const FOOD = 'cat-expense-food';
const FUN = 'cat-expense-fun';
const SALARY = 'cat-income-salary';

test('وضعیت اولیه: بدون حساب و تراکنش ساختگی، فقط دسته‌های پیش‌فرض', () => {
  const s = L.createEmptyState();
  assert.equal(s.accounts.length, 0);
  assert.equal(s.transactions.length, 0);
  assert.equal(s.budgets.length, 0);
  assert.equal(s.goals.length, 0);
  assert.equal(s.debts.length, 0);
  assert.ok(s.categories.length >= 10);
  assert.ok(s.categories.every((c) => c.name && c.icon && /^#[0-9a-f]{6}$/i.test(c.color)));
  assert.ok(s.categories.some((c) => c.kind === 'income') && s.categories.some((c) => c.kind === 'expense'));
  assert.deepEqual(L.totalBalances(s), {});
  assert.equal(new Set(s.categories.map((c) => c.id)).size, s.categories.length);
});

test('حساب: اعتبارسنجی ورودی', () => {
  const ctx = makeCtx();
  const s = L.createEmptyState();
  throwsCode(() => L.addAccount(s, { name: '', type: 'cash' }, ctx), 'VALIDATION', 'name');
  throwsCode(() => L.addAccount(s, { name: '   ' }, ctx), 'VALIDATION', 'name');
  throwsCode(() => L.addAccount(s, { name: 'x'.repeat(41) }, ctx), 'VALIDATION', 'name');
  throwsCode(() => L.addAccount(s, { name: 'الف', type: 'crypto' }, ctx), 'VALIDATION', 'type');
  throwsCode(() => L.addAccount(s, { name: 'الف', currency: 'EUR' }, ctx), 'VALIDATION', 'currency');
  throwsCode(() => L.addAccount(s, { name: 'الف', openingBalance: 1.5 }, ctx), 'VALIDATION', 'openingBalance');
  throwsCode(() => L.addAccount(s, { name: 'الف', openingBalance: '1000' }, ctx), 'VALIDATION', 'openingBalance');
  throwsCode(() => L.addAccount(s, { name: 'الف', openingBalance: NaN }, ctx), 'VALIDATION', 'openingBalance');
  throwsCode(() => L.addAccount(s, { name: 'الف', openingBalance: M_TOO_BIG }, ctx), 'VALIDATION', 'openingBalance');
  const { state: s2, account } = L.addAccount(s, { name: ' نقد   من ', type: 'cash', openingBalance: -5000 }, ctx);
  assert.equal(account.name, 'نقد من');
  assert.equal(account.openingBalance, -5000); // موجودی اولیه‌ی منفی (کارت اعتباری) مجاز است
  assert.equal(account.currency, 'IRT');
  throwsCode(() => L.addAccount(s2, { name: 'نقد من' }, ctx), 'VALIDATION', 'name'); // نام تکراری
  throwsCode(() => L.addAccount(s2, { name: 'نقد  مَن'.replace('َ', '') }, ctx), 'VALIDATION', 'name');
});
test('موجودی = موجودی اولیه + درآمد − هزینه', () => {
  const b = new Book();
  const cash = b.account('نقد', { opening: 1_000_000 });
  assert.equal(b.balance(cash.id), 1_000_000);
  b.tx({ type: 'income', amount: 500_000, date: '1405-07-19', accountId: cash.id, categoryId: SALARY });
  assert.equal(b.balance(cash.id), 1_500_000);
  b.tx({ type: 'expense', amount: 200_000, date: '1405-07-19', accountId: cash.id, categoryId: FOOD });
  assert.equal(b.balance(cash.id), 1_300_000);
  assert.deepEqual(L.totalBalances(b.state), { IRT: 1_300_000 });
  // موجودی تا یک تاریخ مشخص
  b.tx({ type: 'expense', amount: 100_000, date: '1405-07-25', accountId: cash.id, categoryId: FOOD });
  assert.equal(L.accountBalance(b.state, cash.id, { upTo: '1405-07-20' }), 1_300_000);
  assert.equal(L.accountBalance(b.state, cash.id), 1_200_000);
});

test('ثبت تراکنش: اعتبارسنجی کامل ورودی', () => {
  const b = new Book();
  const cash = b.account('نقد', { opening: 100 });
  const ok = { type: 'expense', amount: 1000, date: '1405-07-19', accountId: cash.id, categoryId: FOOD };
  const bad = (patch, field) => throwsCode(() => L.addTransaction(b.state, { ...ok, ...patch }, b.ctx), 'VALIDATION', field);
  bad({ amount: 0 }, 'amount');
  bad({ amount: -5 }, 'amount');
  bad({ amount: 12.5 }, 'amount');
  bad({ amount: '1000' }, 'amount');
  bad({ amount: NaN }, 'amount');
  bad({ amount: Infinity }, 'amount');
  bad({ amount: undefined }, 'amount');
  bad({ amount: null }, 'amount');
  bad({ amount: 1_000_000_000_000_001 }, 'amount');
  bad({ date: '1404-12-30' }, 'date'); // ۳۰ اسفند سال غیرکبیسه
  bad({ date: '2026-10-11' }, 'date'); // تاریخ میلادی پذیرفته نمی‌شود
  bad({ date: '' }, 'date');
  bad({ date: undefined }, 'date');
  bad({ accountId: 'nope' }, 'accountId');
  bad({ accountId: undefined }, 'accountId');
  bad({ categoryId: 'nope' }, 'categoryId');
  bad({ categoryId: SALARY }, 'categoryId'); // دسته‌ی درآمد برای هزینه
  bad({ note: 'ی'.repeat(501) }, 'note');
  bad({ note: 123 }, 'note');
  bad({ type: 'refund' }, 'type');
  // هیچ‌کدام وارد دفتر نشده‌اند
  assert.equal(b.state.transactions.length, 0);
  // تاریخ با ارقام فارسی نرمال می‌شود
  const t = b.tx({ ...ok, date: '۱۴۰۵/۷/۱۹' });
  assert.equal(t.date, '1405-07-19');
  assert.equal(t.currency, 'IRT');
});

test('یادداشت فارسی دقیقاً حفظ می‌شود', () => {
  const b = new Book();
  const cash = b.account('نقد');
  const note = 'خرید نان و پنیر؛ ۱۲٬۵۰۰ تومان – «تازه» 😊';
  const t = b.tx({ type: 'expense', amount: 12_500, date: '1405-07-19', accountId: cash.id, categoryId: FOOD, note: `  ${note}  ` });
  assert.equal(t.note, note);
  assert.equal(b.state.transactions[0].note, note);
});

test('انتقال بین حساب‌ها: کم از مبدأ، اضافه به مقصد، جمع کل ثابت', () => {
  const b = new Book();
  const a = b.account('الف', { opening: 1_000_000 });
  const c = b.account('ب', { opening: 500_000 });
  const t = b.tx({ type: 'transfer', amount: 300_000, date: '1405-07-19', fromAccountId: a.id, toAccountId: c.id });
  assert.equal(b.state.transactions.length, 1); // یک رکورد، نه دو رکورد
  assert.equal(t.toAmount, 300_000);
  assert.equal(b.balance(a.id), 700_000);
  assert.equal(b.balance(c.id), 800_000);
  assert.deepEqual(L.totalBalances(b.state), { IRT: 1_500_000 });
  // ویرایش انتقال هر دو سمت را اصلاح می‌کند
  b.update(t.id, { amount: 400_000 });
  assert.equal(b.balance(a.id), 600_000);
  assert.equal(b.balance(c.id), 900_000);
  assert.equal(b.state.transactions[0].toAmount, 400_000);
  // تغییر مقصد
  const d = b.account('ج', { opening: 0 });
  b.update(t.id, { toAccountId: d.id });
  assert.equal(b.balance(c.id), 500_000);
  assert.equal(b.balance(d.id), 400_000);
  // حذف انتقال هر دو سمت را برمی‌گرداند
  b.remove(t.id);
  assert.equal(b.balance(a.id), 1_000_000);
  assert.equal(b.balance(c.id), 500_000);
  assert.equal(b.balance(d.id), 0);
  assert.deepEqual(L.totalBalances(b.state), { IRT: 1_500_000 });
});

test('انتقال: قواعد خطا و انتقال بین دو ارز', () => {
  const b = new Book();
  const a = b.account('الف', { opening: 10_000_000 });
  const c = b.account('ب');
  const usd = b.account('ارزی', { currency: 'USD', type: 'fx' });
  const base = { type: 'transfer', amount: 1_000_000, date: '1405-07-19', fromAccountId: a.id, toAccountId: c.id };
  throwsCode(() => L.addTransaction(b.state, { ...base, toAccountId: a.id }, b.ctx), 'VALIDATION', 'toAccountId');
  throwsCode(() => L.addTransaction(b.state, { ...base, toAccountId: 'nope' }, b.ctx), 'VALIDATION', 'toAccountId');
  throwsCode(() => L.addTransaction(b.state, { ...base, toAmount: 5 }, b.ctx), 'VALIDATION', 'toAmount');
  // بین دو ارز مختلف، مبلغ دریافتی باید صریحاً داده شود
  throwsCode(() => L.addTransaction(b.state, { ...base, toAccountId: usd.id }, b.ctx), 'VALIDATION', 'toAmount');
  throwsCode(() => L.addTransaction(b.state, { ...base, toAccountId: usd.id, toAmount: 0 }, b.ctx), 'VALIDATION', 'toAmount');
  b.tx({ ...base, toAccountId: usd.id, toAmount: 1000 });
  assert.equal(b.balance(a.id), 9_000_000);
  assert.equal(b.balance(usd.id), 1000);
  assert.deepEqual(L.totalBalances(b.state), { IRT: 9_000_000, USD: 1000 }); // ارزها جدا می‌مانند
  // حساب بایگانی‌شده برای تراکنش جدید پذیرفته نمی‌شود
  const r = L.setAccountArchived(b.state, c.id, true, b.ctx);
  throwsCode(() => L.addTransaction(r.state, { ...base, toAccountId: c.id, note: 'x' }, b.ctx), 'VALIDATION', 'toAccountId');
});

test('تراکنش تکراری: هشدار، تأیید آگاهانه و ثبت idempotent با requestId', () => {
  const b = new Book();
  const cash = b.account('نقد', { opening: 1_000_000 });
  const input = { type: 'expense', amount: 50_000, date: '1405-07-19', accountId: cash.id, categoryId: FOOD, note: 'نان' };
  const first = b.tx(input);
  const e = throwsCode(() => L.addTransaction(b.state, input, b.ctx), 'DUPLICATE');
  assert.equal(e.existingId, first.id);
  assert.equal(b.state.transactions.length, 1);
  // یادداشت با یای عربی/فارسی هم تکراری شناخته می‌شود
  throwsCode(() => L.addTransaction(b.state, { ...input, note: 'نان' }, b.ctx), 'DUPLICATE');
  // با تأیید کاربر ثبت می‌شود
  b.tx(input, { allowDuplicate: true });
  assert.equal(b.state.transactions.length, 2);
  assert.equal(b.balance(cash.id), 900_000);
  // دوبار فشردن دکمه (همان requestId) فقط یک تراکنش می‌سازد
  const req = { ...input, amount: 70_000, requestId: 'req-1' };
  const t1 = b.tx(req);
  const r2 = L.addTransaction(b.state, req, b.ctx);
  assert.equal(r2.repeated, true);
  assert.equal(r2.transaction.id, t1.id);
  assert.equal(r2.state.transactions.length, 3);
  assert.equal(r2.state, b.state);
});

test('ویرایش تراکنش: موجودی و معادل دلاری درست اصلاح می‌شود', () => {
  const b = new Book();
  const cash = b.account('نقد', { opening: 1_000_000 });
  const t = b.tx({ type: 'expense', amount: 200_000, date: '1405-07-19', accountId: cash.id, categoryId: FOOD, note: 'ناهار' });
  assert.equal(t.usd.status, 'pending');
  // محاسبه‌ی دلاری انجام می‌شود
  const applied = FX.applyManualRate(b.state, 100_000, '2026-10-11T10:00:00.000Z');
  b.set(applied.state);
  assert.equal(b.state.transactions[0].usd.status, 'done');
  assert.equal(b.state.transactions[0].usd.cents, 200);
  // ویرایش یادداشت، معادل دلاری را دست نمی‌زند
  b.update(t.id, { note: 'ناهار با دوستان' });
  assert.equal(b.state.transactions[0].usd.status, 'done');
  assert.equal(b.state.transactions[0].usd.cents, 200);
  // ویرایش مبلغ: موجودی عوض می‌شود و معادل دلاری قبلی در history می‌ماند و تراکنش دوباره در انتظار می‌شود
  b.ctx.setNow('2026-10-11T11:00:00.000Z');
  const u = b.update(t.id, { amount: 300_000 });
  assert.equal(b.balance(cash.id), 700_000);
  assert.equal(u.usd.status, 'pending');
  assert.equal(u.usd.history.length, 1);
  assert.equal(u.usd.history[0].cents, 200);
  assert.equal(u.usd.history[0].rate, 100_000);
  assert.equal(u.updatedAt, '2026-10-11T11:00:00.000Z');
  assert.equal(u.createdAt, '2026-10-11T09:00:00.000Z');
  // ویرایش نامعتبر هیچ چیز را تغییر نمی‌دهد
  const before = b.state;
  throwsCode(() => L.updateTransaction(b.state, t.id, { amount: -1 }, b.ctx), 'VALIDATION', 'amount');
  throwsCode(() => L.updateTransaction(b.state, t.id, { date: 'x' }, b.ctx), 'VALIDATION', 'date');
  throwsCode(() => L.updateTransaction(b.state, 'nope', { amount: 5 }, b.ctx), 'NOT_FOUND');
  assert.equal(b.state, before);
  // تغییر نوع درآمد/هزینه با دسته‌ی هم‌نوع
  const f = b.update(t.id, { type: 'income', categoryId: SALARY });
  assert.equal(f.type, 'income');
  assert.equal(b.balance(cash.id), 1_300_000);
  // تغییر نوع به انتقال مجاز نیست
  throwsCode(() => L.updateTransaction(b.state, t.id, { type: 'transfer' }, b.ctx), 'VALIDATION', 'type');
});

test('ویرایش به یک تراکنش تکراری هشدار می‌دهد', () => {
  const b = new Book();
  const cash = b.account('نقد');
  const base = { type: 'expense', date: '1405-07-19', accountId: cash.id, categoryId: FOOD };
  b.tx({ ...base, amount: 1000 });
  const t2 = b.tx({ ...base, amount: 2000 });
  throwsCode(() => L.updateTransaction(b.state, t2.id, { amount: 1000 }, b.ctx), 'DUPLICATE');
  // ویرایش به همان مقدار خودش تکراری حساب نمی‌شود
  assert.equal(L.updateTransaction(b.state, t2.id, { amount: 2000 }, b.ctx).transaction.amount, 2000);
});

test('حذف تراکنش', () => {
  const b = new Book();
  const cash = b.account('نقد', { opening: 1000 });
  const t = b.tx({ type: 'expense', amount: 400, date: '1405-07-19', accountId: cash.id, categoryId: FOOD });
  assert.equal(b.balance(cash.id), 600);
  b.remove(t.id);
  assert.equal(b.balance(cash.id), 1000);
  assert.equal(b.state.transactions.length, 0);
  throwsCode(() => L.deleteTransaction(b.state, t.id), 'NOT_FOUND');
});

test('توابع state ورودی را تغییر نمی‌دهند (state فریز‌شده)', () => {
  const b = new Book({ freeze: true });
  const a = b.account('الف', { opening: 1000 });
  const c = b.account('ب', { opening: 0 });
  const t = b.tx({ type: 'expense', amount: 100, date: '1405-07-19', accountId: a.id, categoryId: FOOD });
  const tr = b.tx({ type: 'transfer', amount: 200, date: '1405-07-19', fromAccountId: a.id, toAccountId: c.id });
  b.update(t.id, { amount: 150 });
  b.update(tr.id, { amount: 250 });
  const d = b.debt({ direction: 'owe', person: 'علی', principal: 1000, date: '1405-07-01' });
  b.tx({ type: 'debt_payment', amount: 100, date: '1405-07-19', accountId: a.id, debtId: d.id });
  const g = b.goal({ name: 'سفر', targetAmount: 5000 });
  const r = L.addGoalContribution(b.state, g.id, { amount: 100, date: '1405-07-19' }, b.ctx);
  b.set(r.state);
  b.budget({ categoryId: FOOD, period: 'monthly', limit: 1000, effectiveFrom: '1405-07-01' });
  b.remove(t.id);
  assert.ok(Object.isFrozen(b.state));
  assert.equal(b.balance(a.id), 1000 - 250 - 100);
});

test('جست‌وجو، فیلتر و مرتب‌سازی', () => {
  const b = new Book();
  const cash = b.account('نقد');
  const bank = b.account('بانک');
  b.tx({ type: 'expense', amount: 100, date: '1405-07-10', accountId: cash.id, categoryId: FOOD, note: 'پنير و نان' }); // یای عربی
  b.tx({ type: 'expense', amount: 500, date: '1405-07-12', accountId: bank.id, categoryId: FUN, note: 'سینما' });
  b.tx({ type: 'income', amount: 9000, date: '1405-07-12', accountId: bank.id, categoryId: SALARY });
  b.tx({ type: 'transfer', amount: 300, date: '1405-07-15', fromAccountId: bank.id, toAccountId: cash.id });
  const q = (f) => L.queryTransactions(b.state, f);
  assert.equal(q({}).length, 4);
  assert.equal(q({ text: 'پنیر' }).length, 1); // یای فارسی ← یای عربی در داده
  assert.equal(q({ text: 'سینما' }).length, 1);
  assert.equal(q({ text: 'تفریح' }).length, 1); // نام دسته هم جست‌وجو می‌شود
  assert.equal(q({ text: 'بانک' }).length, 3); // نام حساب (شامل انتقال)
  assert.equal(q({ from: '1405-07-11', to: '1405-07-14' }).length, 2);
  assert.equal(q({ type: 'expense' }).length, 2);
  assert.equal(q({ types: ['income', 'transfer'] }).length, 2);
  assert.equal(q({ accountId: cash.id }).length, 2); // یک هزینه + سمت مقصد انتقال
  assert.equal(q({ categoryId: FOOD }).length, 1);
  assert.equal(q({ minAmount: 300, maxAmount: 500 }).length, 2);
  assert.equal(q({ text: 'چیزی که نیست' }).length, 0);
  assert.deepEqual(q({ sort: 'date_desc' }).map((t) => t.date), ['1405-07-15', '1405-07-12', '1405-07-12', '1405-07-10']);
  assert.deepEqual(q({ sort: 'date_asc' }).map((t) => t.date), ['1405-07-10', '1405-07-12', '1405-07-12', '1405-07-15']);
  assert.deepEqual(q({ sort: 'amount_desc' }).map((t) => t.amount), [9000, 500, 300, 100]);
  assert.deepEqual(q({ sort: 'amount_asc' }).map((t) => t.amount), [100, 300, 500, 9000]);
});

test('تطبیق موجودی محاسبه‌شده با موجودی واقعی', () => {
  const b = new Book();
  const cash = b.account('نقد', { opening: 1_000_000 });
  b.tx({ type: 'expense', amount: 250_000, date: '1405-07-19', accountId: cash.id, categoryId: FOOD });
  assert.deepEqual(L.reconcile(b.state, cash.id, 750_000), { currency: 'IRT', computed: 750_000, actual: 750_000, difference: 0, status: 'match' });
  const r = L.reconcile(b.state, cash.id, 700_000);
  assert.equal(r.difference, -50_000);
  assert.equal(r.status, 'differs');
  throwsCode(() => L.reconcile(b.state, cash.id, 1.5), 'VALIDATION');
  throwsCode(() => L.reconcile(b.state, 'nope', 5), 'NOT_FOUND');
});

test('حذف و بایگانی حساب', () => {
  const b = new Book();
  const a = b.account('الف');
  const c = b.account('ب');
  b.tx({ type: 'expense', amount: 10, date: '1405-07-19', accountId: a.id, categoryId: FOOD });
  throwsCode(() => L.deleteAccount(b.state, a.id), 'IN_USE');
  throwsCode(() => L.updateAccount(b.state, a.id, { currency: 'USD' }, b.ctx), 'VALIDATION', 'currency');
  assert.equal(L.deleteAccount(b.state, c.id).state.accounts.length, 1);
  const arch = L.setAccountArchived(b.state, a.id, true, b.ctx).state;
  assert.deepEqual(L.totalBalances(arch), { IRT: 0 }); // حساب بایگانی‌شده در جمع نمی‌آید (فقط «ب»)
  assert.deepEqual(L.totalBalances(arch, { includeArchived: true }), { IRT: -10 });
  // تغییر موجودی اولیه
  const r = L.updateAccount(b.state, c.id, { openingBalance: 500 }, b.ctx);
  assert.equal(L.accountBalance(r.state, c.id), 500);
  throwsCode(() => L.updateAccount(b.state, c.id, { name: 'الف' }, b.ctx), 'VALIDATION', 'name');
});

test('دسته‌بندی: ساخت، ویرایش، تکراری‌نبودن و حذف با جایگزینی', () => {
  const b = new Book();
  const cash = b.account('نقد');
  const { state: s1, category } = L.addCategory(b.state, { name: 'قهوه', kind: 'expense', icon: '☕', color: '#8d6e4e' }, b.ctx);
  b.set(s1);
  assert.equal(category.builtin, false);
  throwsCode(() => L.addCategory(b.state, { name: 'قهوه', kind: 'expense' }, b.ctx), 'VALIDATION', 'name');
  throwsCode(() => L.addCategory(b.state, { name: 'خوراک', kind: 'expense' }, b.ctx), 'VALIDATION', 'name');
  L.addCategory(b.state, { name: 'قهوه', kind: 'income' }, b.ctx); // نام تکراری در نوع دیگر مجاز است
  throwsCode(() => L.addCategory(b.state, { name: 'الف', kind: 'other' }, b.ctx), 'VALIDATION', 'kind');
  throwsCode(() => L.addCategory(b.state, { name: 'الف', kind: 'expense', color: 'red' }, b.ctx), 'VALIDATION', 'color');
  const renamed = L.updateCategory(b.state, category.id, { name: 'کافه' }).category;
  assert.equal(renamed.name, 'کافه');
  // تراکنش‌های دارای این دسته
  b.tx({ type: 'expense', amount: 90, date: '1405-07-19', accountId: cash.id, categoryId: category.id });
  throwsCode(() => L.deleteCategory(b.state, category.id), 'IN_USE');
  throwsCode(() => L.deleteCategory(b.state, category.id, { reassignTo: SALARY }), 'IN_USE'); // نوع متفاوت
  throwsCode(() => L.deleteCategory(b.state, category.id, { reassignTo: category.id }), 'IN_USE');
  const del = L.deleteCategory(b.state, category.id, { reassignTo: FOOD });
  assert.equal(del.reassigned, 1);
  assert.equal(del.state.transactions[0].categoryId, FOOD);
  assert.ok(!del.state.categories.some((c) => c.id === category.id));
  // دسته‌ی بدون تراکنش مستقیم حذف می‌شود
  assert.ok(!L.deleteCategory(b.state, 'cat-expense-gift').state.categories.some((c) => c.id === 'cat-expense-gift'));
});

test('بدهی: پرداخت جزئی، مانده، بدون دوباره‌شماری در هزینه‌ها', () => {
  const b = new Book();
  const cash = b.account('نقد', { opening: 5_000_000 });
  const d = b.debt({ direction: 'owe', person: 'علی', principal: 1_000_000, date: '1405-07-01', dueDate: '1405-07-30' });
  assert.equal(b.balance(cash.id), 5_000_000); // ثبت بدهی بدون حساب، موجودی را عوض نمی‌کند
  b.tx({ type: 'debt_payment', amount: 400_000, date: '1405-07-10', accountId: cash.id, debtId: d.id });
  assert.equal(b.balance(cash.id), 4_600_000);
  let st = L.debtStatus(b.state, d.id, '1405-07-19');
  assert.equal(st.paid, 400_000);
  assert.equal(st.remaining, 600_000);
  assert.equal(st.status, 'open');
  assert.equal(st.progressBp, 4000);
  // پرداخت بیش از مانده رد می‌شود
  throwsCode(() => L.addTransaction(b.state, { type: 'debt_payment', amount: 700_000, date: '1405-07-11', accountId: cash.id, debtId: d.id }, b.ctx), 'VALIDATION', 'amount');
  const p2 = b.tx({ type: 'debt_payment', amount: 600_000, date: '1405-07-12', accountId: cash.id, debtId: d.id });
  st = L.debtStatus(b.state, d.id);
  assert.equal(st.remaining, 0);
  assert.equal(st.status, 'settled');
  assert.equal(b.balance(cash.id), 4_000_000);
  // ویرایش پرداخت: مانده دوباره باز می‌شود
  b.update(p2.id, { amount: 100_000 });
  assert.equal(L.debtStatus(b.state, d.id).remaining, 500_000);
  assert.equal(b.balance(cash.id), 4_500_000);
  // حذف بدهی با پرداخت‌ها نیاز به تأیید cascade دارد
  const e = throwsCode(() => L.deleteDebt(b.state, d.id), 'IN_USE');
  assert.equal(e.payments, 2);
  const del = L.deleteDebt(b.state, d.id, { cascade: true });
  assert.equal(del.removedPayments, 2);
  assert.equal(L.accountBalance(del.state, cash.id), 5_000_000);
});

test('طلب، اصل مبلغ روی حساب، سررسید و ارز ناهمخوان', () => {
  const b = new Book();
  const cash = b.account('نقد', { opening: 1_000_000 });
  const usd = b.account('ارزی', { currency: 'USD' });
  const d = b.debt({ direction: 'owed', person: 'رضا', principal: 500_000, date: '1405-07-05', dueDate: '1405-07-15', accountId: cash.id });
  assert.equal(b.balance(cash.id), 500_000); // پولی که قرض دادم از حساب رفته
  b.tx({ type: 'debt_payment', amount: 200_000, date: '1405-07-10', accountId: cash.id, debtId: d.id });
  assert.equal(b.balance(cash.id), 700_000); // دریافت قسط اول
  const st = L.debtStatus(b.state, d.id, '1405-07-19');
  assert.equal(st.remaining, 300_000);
  assert.equal(st.status, 'overdue');
  const totals = L.debtTotals(b.state, '1405-07-19');
  assert.deepEqual(totals.owed, { IRT: 300_000 });
  assert.deepEqual(totals.owe, {});
  assert.equal(totals.overdue.length, 1);
  throwsCode(() => L.addTransaction(b.state, { type: 'debt_payment', amount: 100, date: '1405-07-11', accountId: usd.id, debtId: d.id }, b.ctx), 'VALIDATION', 'accountId');
  throwsCode(() => L.addDebt(b.state, { direction: 'owed', person: 'ا', principal: 100, date: '1405-07-05', dueDate: '1405-07-01' }, b.ctx), 'VALIDATION', 'dueDate');
  throwsCode(() => L.addDebt(b.state, { direction: 'x', person: 'ا', principal: 100, date: '1405-07-05' }, b.ctx), 'VALIDATION', 'direction');
  throwsCode(() => L.addDebt(b.state, { direction: 'owe', person: '', principal: 100, date: '1405-07-05' }, b.ctx), 'VALIDATION', 'person');
  throwsCode(() => L.addDebt(b.state, { direction: 'owe', person: 'ا', principal: 0, date: '1405-07-05' }, b.ctx), 'VALIDATION', 'principal');
  throwsCode(() => L.updateDebt(b.state, d.id, { principal: 100_000 }, b.ctx), 'VALIDATION', 'principal'); // کمتر از پرداخت‌شده
  assert.equal(L.updateDebt(b.state, d.id, { principal: 800_000 }, b.ctx).debt.principal, 800_000);
});

test('اهداف پس‌انداز: تخصیص، برداشت، پیشرفت و بی‌اثر بودن روی هزینه و موجودی', () => {
  const b = new Book();
  const cash = b.account('نقد', { opening: 10_000_000 });
  const g = b.goal({ name: 'سفر', targetAmount: 10_000_000, targetDate: '1405-09-30' });
  throwsCode(() => L.addGoal(b.state, { name: 'سفر', targetAmount: 5 }, b.ctx), 'VALIDATION', 'name');
  throwsCode(() => L.addGoal(b.state, { name: 'ب', targetAmount: 0 }, b.ctx), 'VALIDATION', 'targetAmount');
  const before = L.totalBalances(b.state);
  let r = L.addGoalContribution(b.state, g.id, { amount: 3_000_000, date: '1405-07-19', note: 'اول' }, b.ctx);
  b.set(r.state);
  const p = L.goalProgress(b.state.goals[0], '1405-07-19');
  assert.equal(p.saved, 3_000_000);
  assert.equal(p.remaining, 7_000_000);
  assert.equal(p.progressBp, 3000);
  assert.equal(p.reached, false);
  assert.equal(p.daysLeft, J_DIFF('1405-09-30', '1405-07-19'));
  assert.deepEqual(L.totalBalances(b.state), before); // موجودی حساب‌ها تغییری نکرد
  assert.equal(b.state.transactions.length, 0); // هزینه‌ای ساخته نشد
  throwsCode(() => L.addGoalContribution(b.state, g.id, { amount: 4_000_000, date: '1405-07-20', kind: 'withdraw' }, b.ctx), 'VALIDATION', 'amount');
  r = L.addGoalContribution(b.state, g.id, { amount: 1_000_000, date: '1405-07-20', kind: 'withdraw' }, b.ctx);
  b.set(r.state);
  assert.equal(L.goalSaved(b.state.goals[0]), 2_000_000);
  // حذف مشارکت اولیه باعث منفی شدن می‌شد؛ رد می‌شود
  throwsCode(() => L.removeGoalContribution(b.state, g.id, b.state.goals[0].contributions[0].id, b.ctx), 'VALIDATION');
  // رسیدن به هدف (حتی بیش از هدف) و گذشتن سررسید
  r = L.addGoalContribution(b.state, g.id, { amount: 9_000_000, date: '1405-07-21' }, b.ctx);
  const done = L.goalProgress(r.state.goals[0], '1405-10-01');
  assert.equal(done.reached, true);
  assert.equal(done.progressBp, 10000);
  assert.equal(done.remaining, 0);
  assert.equal(done.overdue, false); // رسیده، پس عقب‌افتاده نیست
  const late = L.goalProgress(b.state.goals[0], '1405-10-01');
  assert.equal(late.overdue, true);
  assert.equal(late.daysLeft, -1);
  assert.ok(cash.id);
});
test('بودجه نسخه‌دار: تغییر سقف تاریخچه را حفظ می‌کند', () => {
  const b = new Book();
  b.account('نقد');
  const v1 = b.budget({ categoryId: FOOD, period: 'monthly', limit: 1_000_000, effectiveFrom: '1405-07-01' });
  const v2 = b.budget({ categoryId: FOOD, period: 'monthly', limit: 1_500_000, effectiveFrom: '1405-07-15' });
  assert.equal(b.state.budgets.length, 2);
  assert.equal(b.state.budgets.find((x) => x.id === v1.id).effectiveTo, '1405-07-14');
  assert.equal(b.state.budgets.find((x) => x.id === v2.id).effectiveTo, null);
  assert.equal(L.budgetsActiveOn(b.state, '1405-07-10')[0].limit, 1_000_000);
  assert.equal(L.budgetsActiveOn(b.state, '1405-07-14')[0].limit, 1_000_000);
  assert.equal(L.budgetsActiveOn(b.state, '1405-07-15')[0].limit, 1_500_000);
  assert.equal(L.budgetsActiveOn(b.state, '1405-06-30').length, 0);
  // بودجه‌ی کلی و دسته‌ای هم‌زمان؛ دوره‌های مختلف مستقل‌اند
  b.budget({ categoryId: null, period: 'monthly', limit: 8_000_000, effectiveFrom: '1405-07-01' });
  b.budget({ categoryId: FOOD, period: 'weekly', limit: 300_000, effectiveFrom: '1405-07-01' });
  assert.equal(L.budgetsActiveOn(b.state, '1405-07-20').length, 3);
  // ثبت دوباره در همان روز شروع، همان نسخه را جایگزین می‌کند
  b.budget({ categoryId: FOOD, period: 'weekly', limit: 350_000, effectiveFrom: '1405-07-01' });
  assert.equal(b.state.budgets.filter((x) => x.categoryId === FOOD && x.period === 'weekly').length, 1);
  assert.equal(b.state.budgets.find((x) => x.categoryId === FOOD && x.period === 'weekly').limit, 350_000);
  // حذف بودجه: از «امروز» بسته می‌شود و گذشته می‌ماند
  const active = b.state.budgets.find((x) => x.categoryId === null);
  const rm = L.removeBudget(b.state, active.id, '1405-07-20').state;
  assert.equal(L.budgetsActiveOn(rm, '1405-07-19').filter((x) => x.categoryId === null).length, 1);
  assert.equal(L.budgetsActiveOn(rm, '1405-07-20').filter((x) => x.categoryId === null).length, 0);
});

test('بودجه: اعتبارسنجی', () => {
  const b = new Book();
  const ok = { categoryId: FOOD, period: 'monthly', limit: 1000, effectiveFrom: '1405-07-01' };
  const bad = (patch, field) => throwsCode(() => L.setBudget(b.state, { ...ok, ...patch }, b.ctx), 'VALIDATION', field);
  bad({ period: 'yearly' }, 'period');
  bad({ categoryId: SALARY }, 'categoryId'); // دسته‌ی درآمد
  bad({ categoryId: 'nope' }, 'categoryId');
  bad({ limit: 0 }, 'limit');
  bad({ limit: -5 }, 'limit');
  bad({ limit: 1.5 }, 'limit');
  bad({ effectiveFrom: '1405-13-01' }, 'effectiveFrom');
  bad({ warnBp: 0 }, 'warnBp');
  bad({ warnBp: 10001 }, 'warnBp');
  throwsCode(() => L.removeBudget(b.state, 'nope', '1405-07-01'), 'NOT_FOUND');
});

test('حذف دسته، بودجه‌ی آن دسته را می‌بندد', () => {
  const b = new Book();
  b.account('نقد');
  b.budget({ categoryId: 'cat-expense-gift', period: 'monthly', limit: 1000, effectiveFrom: '1405-07-01' });
  const r = L.deleteCategory(b.state, 'cat-expense-gift', { today: '1405-07-20' });
  assert.equal(r.state.budgets[0].effectiveTo, '1405-07-19');
  assert.equal(L.budgetsActiveOn(r.state, '1405-07-20').length, 0);
});

test('مبالغ خیلی بزرگ بدون خطای دقت جمع می‌شوند', () => {
  const b = new Book();
  const a = b.account('بزرگ', { opening: 900_000_000_000_000 });
  b.tx({ type: 'income', amount: 99_999_999_999_999, date: '1405-07-19', accountId: a.id, categoryId: SALARY });
  b.tx({ type: 'expense', amount: 1, date: '1405-07-19', accountId: a.id, categoryId: FOOD });
  assert.equal(b.balance(a.id), 999_999_999_999_998);
  // سرریز عدد امن به‌جای عدد اشتباه، خطا می‌دهد
  const huge = b.account('بزرگ۲', { opening: 1_000_000_000_000_000 });
  for (let i = 0; i < 9; i += 1) {
    b.tx({ type: 'income', amount: 1_000_000_000_000_000, date: '1405-07-19', accountId: huge.id, categoryId: SALARY, note: `n${i}` });
  }
  assert.throws(() => L.accountBalance(b.state, huge.id), { code: 'OVERFLOW' });
});

test('تراکنش دلاری روی حساب دلاری: واحد سنت و بدون نیاز به معادل دلاری', () => {
  const b = new Book();
  const usd = b.account('ارزی', { currency: 'USD', type: 'fx', opening: 10_000 });
  const t = b.tx({ type: 'expense', amount: 1_599, date: '1405-07-19', accountId: usd.id, categoryId: FUN });
  assert.equal(t.currency, 'USD');
  assert.equal(t.usd.status, 'not_applicable');
  assert.equal(b.balance(usd.id), 8_401);
  assert.equal(FX.pendingTransactions(b.state).length, 0);
});

test('انتقال و پرداخت بدهی هیچ‌وقت در صف انتظار دلار نمی‌آیند', () => {
  const b = new Book();
  const a = b.account('الف', { opening: 1_000_000 });
  const c = b.account('ب');
  b.tx({ type: 'transfer', amount: 1000, date: '1405-07-19', fromAccountId: a.id, toAccountId: c.id });
  const d = b.debt({ direction: 'owe', person: 'ا', principal: 1000, date: '1405-07-01' });
  b.tx({ type: 'debt_payment', amount: 500, date: '1405-07-19', accountId: a.id, debtId: d.id });
  b.tx({ type: 'expense', amount: 500, date: '1405-07-19', accountId: a.id, categoryId: FOOD });
  assert.equal(FX.pendingTransactions(b.state).length, 1);
});

test('بازبینی ساختار اولیه با deepFreeze', () => {
  const s = deepFreeze(L.createEmptyState());
  assert.equal(Object.isFrozen(s.categories[0]), true);
  assert.equal(L.addAccount(s, { name: 'الف' }, makeCtx()).state.accounts.length, 1);
});
