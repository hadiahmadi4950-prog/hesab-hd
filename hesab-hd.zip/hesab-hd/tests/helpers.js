// ابزار مشترک تست‌ها (این فایل تست نیست و در اجرای تست‌ها شمرده نمی‌شود)
import * as L from '../src/core/ledger.js';

export function makeCtx(startIso = '2026-10-11T09:00:00.000Z') {
  let n = 0;
  let nowIso = startIso;
  return {
    now: () => nowIso,
    id: () => `id-${String(++n).padStart(4, '0')}`,
    setNow(iso) {
      nowIso = iso;
    },
  };
}

export function deepFreeze(o) {
  if (o && typeof o === 'object' && !Object.isFrozen(o)) {
    Object.freeze(o);
    for (const v of Object.values(o)) deepFreeze(v);
  }
  return o;
}

// دفتر آزمایشی: state را نگه می‌دارد و عملیات ledger را ساده می‌کند
export class Book {
  constructor({ freeze = false } = {}) {
    this.ctx = makeCtx();
    this.freeze = freeze;
    this.state = this.#keep(L.createEmptyState());
  }

  #keep(s) {
    return this.freeze ? deepFreeze(s) : s;
  }

  #apply(r) {
    this.state = this.#keep(r.state);
    return r;
  }

  account(name, { currency = 'IRT', opening = 0, type = 'cash' } = {}) {
    return this.#apply(L.addAccount(this.state, { name, type, currency, openingBalance: opening }, this.ctx)).account;
  }

  tx(input, opts) {
    return this.#apply(L.addTransaction(this.state, input, this.ctx, opts)).transaction;
  }

  update(id, patch, opts) {
    return this.#apply(L.updateTransaction(this.state, id, patch, this.ctx, opts)).transaction;
  }

  remove(id) {
    return this.#apply(L.deleteTransaction(this.state, id));
  }

  debt(input) {
    return this.#apply(L.addDebt(this.state, input, this.ctx)).debt;
  }

  goal(input) {
    return this.#apply(L.addGoal(this.state, input, this.ctx)).goal;
  }

  budget(input) {
    return this.#apply(L.setBudget(this.state, input, this.ctx)).budget;
  }

  set(newState) {
    this.state = this.#keep(newState);
  }

  balance(accountId) {
    return L.accountBalance(this.state, accountId);
  }
}
