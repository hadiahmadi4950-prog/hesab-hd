import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as M from '../src/core/money.js';

test('تجزیه‌ی تومان: ارقام فارسی/عربی، جداکننده‌ها و فاصله', () => {
  const ok = (input, value, opts) => assert.deepEqual(M.parseToman(input, opts), { ok: true, value }, String(input));
  ok('1500000', 1500000);
  ok('۱٬۵۰۰٬۰۰۰', 1500000);
  ok('1,500,000', 1500000);
  ok('۱،۵۰۰،۰۰۰', 1500000);
  ok(' ١٥٠٠ ', 1500);
  ok('۱ ۵۰۰', 1500);
  ok(1500, 1500);
  ok('0', 0, { allowZero: true });
  ok('۰', 0, { allowZero: true });
  ok('-2500', -2500, { allowNegative: true });
  ok('1000000000000000', 1_000_000_000_000_000); // دقیقاً سقف
});

test('تجزیه‌ی تومان: ورودی نامعتبر هرگز عدد نمی‌شود', () => {
  const bad = ['', '   ', 'abc', '12abc', '1e5', '0x10', '--5', '1.5.2', '١٢٫٥', '12.5', '0', '-5', '+', '-', null, undefined, {}, [], true];
  for (const b of bad) {
    const r = M.parseToman(b);
    assert.equal(r.ok, false, `باید رد شود: ${JSON.stringify(b)}`);
    assert.equal(typeof r.error, 'string');
    assert.ok(r.error.length > 0);
    assert.equal('value' in r, false);
  }
  for (const b of [NaN, Infinity, -Infinity, 12.5, 1e21, 2 ** 60, 1_000_000_000_000_001, '1000000000000001', '99999999999999999999']) {
    assert.equal(M.parseToman(b).ok, false, `باید رد شود: ${String(b)}`);
  }
  assert.equal(M.parseToman('-0', { allowZero: true }).value, 0);
});

test('تجزیه‌ی دلار: حداکثر دو رقم اعشار و بدون گرد کردن پنهان', () => {
  const ok = (input, value, opts) => assert.deepEqual(M.parseUsd(input, opts), { ok: true, value }, String(input));
  ok('12.34', 1234);
  ok('12.3', 1230);
  ok('12', 1200);
  ok('۱۲٫۵۰', 1250);
  ok('1,234.56', 123456);
  ok('0.05', 5);
  ok('0', 0, { allowZero: true });
  ok('-3.25', -325, { allowNegative: true });
  ok(7.5, 750);
  for (const b of ['12.345', '.5', '12.', '', 'x', '1e3', '-1', '0', null, NaN, Infinity, '10000000000000', '100000000000.01']) {
    assert.equal(M.parseUsd(b).ok, false, `باید رد شود: ${String(b)}`);
  }
});

test('parseAmount بر اساس واحد پول', () => {
  assert.equal(M.parseAmount('IRT', '۱۲٬۰۰۰').value, 12000);
  assert.equal(M.parseAmount('USD', '12.5').value, 1250);
  assert.equal(M.parseAmount('EUR', '5').ok, false);
});

test('نرخ دلار: فقط عدد صحیح مثبت در محدوده', () => {
  assert.deepEqual(M.parseRate('۱۲۰٬۰۰۰'), { ok: true, value: 120000 });
  for (const b of ['0', '-5', '1.5', '', 'abc', '10000001', 0, -1, 1.5]) {
    assert.equal(M.parseRate(b).ok, false, `باید رد شود: ${String(b)}`);
  }
  assert.equal(M.isValidRate(120000), true);
  assert.equal(M.isValidRate(0), false);
  assert.equal(M.isValidRate(1.5), false);
  assert.equal(M.isValidRate(NaN), false);
  assert.equal(M.isValidRate('120000'), false);
});

test('تبدیل تومان به سنت دلار: گرد کردن نیم به سمت دورتر از صفر', () => {
  assert.equal(M.tomanToUsdCents(1_000_000, 100_000), 1000); // ۱۰.۰۰ دلار
  assert.equal(M.tomanToUsdCents(1_250_000, 100_000), 1250);
  assert.equal(M.tomanToUsdCents(500, 100_000), 1); // ۰.۵ سنت → ۱
  assert.equal(M.tomanToUsdCents(499, 100_000), 0);
  assert.equal(M.tomanToUsdCents(1, 100_000), 0);
  assert.equal(M.tomanToUsdCents(-500, 100_000), -1);
  assert.equal(M.tomanToUsdCents(-499, 100_000), 0);
  assert.equal(M.tomanToUsdCents(0, 100_000), 0);
  assert.equal(M.tomanToUsdCents(333_333, 100_000), 333); // ۳.۳۳۳۳۳ دلار → ۳۳۳ سنت
  assert.equal(M.tomanToUsdCents(1_000_000_000_000_000, 100_000), 1_000_000_000_000); // مبلغ خیلی بزرگ، بدون خطای اعشاری
});

test('تبدیل سنت دلار به تومان', () => {
  assert.equal(M.usdCentsToToman(1000, 100_000), 1_000_000);
  assert.equal(M.usdCentsToToman(1, 100_000), 1000);
  assert.equal(M.usdCentsToToman(1, 150), 2); // ۱.۵ → ۲
  assert.equal(M.usdCentsToToman(1, 149), 1);
  assert.equal(M.usdCentsToToman(-1, 150), -2);
  assert.equal(M.usdCentsToToman(0, 150), 0);
});

test('تبدیل با ورودی یا نرخ نامعتبر خطا می‌دهد، نه عدد اشتباه', () => {
  assert.throws(() => M.tomanToUsdCents(100, 0), { code: 'BAD_RATE' });
  assert.throws(() => M.tomanToUsdCents(100, -5), { code: 'BAD_RATE' });
  assert.throws(() => M.tomanToUsdCents(100, 1.5), { code: 'BAD_RATE' });
  assert.throws(() => M.tomanToUsdCents(100, NaN), { code: 'BAD_RATE' });
  assert.throws(() => M.tomanToUsdCents(1.5, 100000), { code: 'BAD_AMOUNT' });
  assert.throws(() => M.tomanToUsdCents(NaN, 100000), { code: 'BAD_AMOUNT' });
  assert.throws(() => M.usdCentsToToman(1.5, 100000), { code: 'BAD_AMOUNT' });
  assert.throws(() => M.usdCentsToToman(5, 0), { code: 'BAD_RATE' });
  assert.throws(() => M.roundDiv(1, 0), { code: 'DIV_ZERO' });
});

test('تبدیل مبلغ اصلی را تغییر نمی‌دهد و محاسبات روی عدد صحیح دقیق است', () => {
  const original = 1_234_567;
  const cents = M.tomanToUsdCents(original, 123_456);
  assert.equal(original, 1_234_567);
  assert.equal(cents, 1000); // 1234567*100/123456 = 1000.0 تقریباً
  // مجموع مبالغ کوچک همان جمع دقیق عدد صحیح است (برخلاف ۰.۱ + ۰.۲ در اعشار)
  assert.equal(M.sumAmounts(Array(10).fill(1)), 10);
  assert.equal(M.sumAmounts([100, 200]), 300);
  assert.equal(M.sumAmounts([]), 0);
  assert.equal(M.sumAmounts([5, -5, 7]), 7);
});

test('سرریز عدد امن تشخیص داده می‌شود', () => {
  assert.throws(() => M.safeAdd(Number.MAX_SAFE_INTEGER, 1), { code: 'OVERFLOW' });
  assert.throws(() => M.safeAdd(1.5, 1), { code: 'OVERFLOW' });
  assert.throws(() => M.sumAmounts([Number.MAX_SAFE_INTEGER, 1]), { code: 'OVERFLOW' });
  assert.equal(M.safeAdd(Number.MAX_SAFE_INTEGER - 1, 1), Number.MAX_SAFE_INTEGER);
});

test('درصد به‌صورت نقطه‌ی پایه', () => {
  assert.equal(M.percentBp(50, 200), 2500);
  assert.equal(M.percentBp(1, 3), 3333);
  assert.equal(M.percentBp(2, 3), 6667);
  assert.equal(M.percentBp(0, 100), 0);
  assert.equal(M.percentBp(150, 100), 15000); // بیش از ۱۰۰٪
  assert.equal(M.percentBp(5, 0), null);
  assert.throws(() => M.percentBp(1.5, 3), { code: 'BAD_AMOUNT' });
});

test('نمایش تومان: ارقام فارسی با جداکننده‌ی هزارگان، بدون ریال', () => {
  assert.equal(M.formatToman(1234567), '۱٬۲۳۴٬۵۶۷ تومان');
  assert.equal(M.formatToman(0), '۰ تومان');
  assert.equal(M.formatToman(999), '۹۹۹ تومان');
  assert.equal(M.formatToman(1000), '۱٬۰۰۰ تومان');
  assert.equal(M.formatToman(-1500), '−۱٬۵۰۰ تومان');
  assert.equal(M.formatToman(1234567, { withUnit: false }), '۱٬۲۳۴٬۵۶۷');
  assert.equal(M.formatToman(1_000_000_000_000_000), '۱٬۰۰۰٬۰۰۰٬۰۰۰٬۰۰۰٬۰۰۰ تومان');
  assert.throws(() => M.formatToman(1.5), { code: 'BAD_AMOUNT' });
  assert.throws(() => M.formatToman(NaN), { code: 'BAD_AMOUNT' });
  for (const n of [0, 5, 1000, 123456789]) assert.ok(!M.formatToman(n).includes('ریال'));
});

test('نمایش دلار', () => {
  assert.equal(M.formatUsd(123456), '۱٬۲۳۴٫۵۶ دلار');
  assert.equal(M.formatUsd(5), '۰٫۰۵ دلار');
  assert.equal(M.formatUsd(0), '۰٫۰۰ دلار');
  assert.equal(M.formatUsd(100), '۱٫۰۰ دلار');
  assert.equal(M.formatUsd(-250), '−۲٫۵۰ دلار');
  assert.equal(M.formatUsd(1000, { withUnit: false }), '۱۰٫۰۰');
  assert.equal(M.formatAmount('IRT', 1000), '۱٬۰۰۰ تومان');
  assert.equal(M.formatAmount('USD', 1000), '۱۰٫۰۰ دلار');
  assert.throws(() => M.formatAmount('EUR', 1), { code: 'BAD_CURRENCY' });
});

test('رشته‌ی قابل‌ویرایش برای فرم', () => {
  assert.equal(M.toEditableString('IRT', 1500000), '1500000');
  assert.equal(M.toEditableString('USD', 1250), '12.50');
  assert.equal(M.toEditableString('USD', 5), '0.05');
  assert.equal(M.toEditableString('USD', -325), '-3.25');
  // رفت‌وبرگشت: نمایش ← تجزیه همان مقدار را برمی‌گرداند
  for (const v of [1, 99, 100, 123456, 9_999_999]) {
    assert.equal(M.parseUsd(M.toEditableString('USD', v)).value, v);
    assert.equal(M.parseToman(M.toEditableString('IRT', v)).value, v);
  }
});

test('مبالغ معتبر', () => {
  assert.equal(M.isValidAmount('IRT', 1000), true);
  assert.equal(M.isValidAmount('IRT', 1.5), false);
  assert.equal(M.isValidAmount('IRT', M.MAX_TOMAN + 1), false);
  assert.equal(M.isValidAmount('USD', 150), true);
  assert.equal(M.isValidAmount('USD', NaN), false);
  assert.equal(M.isValidAmount('EUR', 1), false);
});
