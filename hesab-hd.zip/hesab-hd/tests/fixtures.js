// دفتر نمونه‌ی کامل برای تست‌های ذخیره‌سازی و پشتیبان (این فایل تست نیست)
import * as L from '../src/core/ledger.js';
import * as FX from '../src/core/fx.js';
import { Book } from './helpers.js';

export const T0 = '2026-10-11T10:00:00.000Z';
export const T1 = '2026-10-11T10:10:00.000Z';

export function richBook() {
  const b = new Book();
  const cash = b.account('نقد', { opening: 1_000_000 });
  const bank = b.account('بانک', { opening: 5_000_000, type: 'bank' });
  const usd = b.account('ارزی', { currency: 'USD', type: 'fx', opening: 10_000 });
  const custom = L.addCategory(b.state, { name: 'قهوه', kind: 'expense', icon: '☕', color: '#8d6e4e' }, b.ctx);
  b.set(custom.state);
  const t = {};
  t.salary = b.tx({ type: 'income', amount: 10_000_000, date: '1405-07-18', accountId: bank.id, categoryId: 'cat-income-salary', note: 'حقوق مهر' });
  t.food = b.tx({ type: 'expense', amount: 150_000, date: '1405-07-18', accountId: cash.id, categoryId: 'cat-expense-food', note: 'نان، پنیر و "سبزی"\nخط دوم' });
  t.coffee = b.tx({ type: 'expense', amount: 90_000, date: '1405-07-19', accountId: cash.id, categoryId: custom.category.id, note: '=SUM(A1:A2)' });
  t.transfer = b.tx({ type: 'transfer', amount: 2_000_000, date: '1405-07-20', fromAccountId: bank.id, toAccountId: cash.id });
  t.exchange = b.tx({ type: 'transfer', amount: 1_000_000, date: '1405-07-20', fromAccountId: bank.id, toAccountId: usd.id, toAmount: 1000, note: 'خرید دلار' });
  t.fun = b.tx({ type: 'expense', amount: 1_599, date: '1405-07-21', accountId: usd.id, categoryId: 'cat-expense-fun', note: 'سینما 😊' });
  const owe = b.debt({ direction: 'owe', person: 'علی', principal: 1_000_000, date: '1405-07-10', dueDate: '1405-08-10', note: 'قرض' });
  t.pay = b.tx({ type: 'debt_payment', amount: 300_000, date: '1405-07-21', accountId: bank.id, debtId: owe.id });
  const owed = b.debt({ direction: 'owed', person: 'رضا', principal: 500_000, date: '1405-07-05', accountId: cash.id });
  t.recv = b.tx({ type: 'debt_payment', amount: 200_000, date: '1405-07-22', accountId: cash.id, debtId: owed.id });
  const goal = b.goal({ name: 'سفر', targetAmount: 10_000_000, targetDate: '1405-09-30' });
  b.set(L.addGoalContribution(b.state, goal.id, { amount: 3_000_000, date: '1405-07-19', note: 'اول' }, b.ctx).state);
  b.set(L.addGoalContribution(b.state, goal.id, { amount: 500_000, date: '1405-07-20', kind: 'withdraw' }, b.ctx).state);
  b.budget({ categoryId: 'cat-expense-food', period: 'monthly', limit: 1_000_000, effectiveFrom: '1405-07-01' });
  b.budget({ categoryId: 'cat-expense-food', period: 'monthly', limit: 1_500_000, effectiveFrom: '1405-07-15' });
  b.budget({ categoryId: null, period: 'monthly', limit: 8_000_000, effectiveFrom: '1405-07-01' });
  // معادل دلاری: بعضی با نرخ خودکار محاسبه می‌شوند، یکی بعد از ویرایش دوباره در انتظار می‌ماند
  const rate = { value: 100_000, at: T0, source: 'منبع آزمایشی', manual: false };
  b.set(FX.processPending(b.state, rate, T0).state);
  b.ctx.setNow(T1);
  b.update(t.food.id, { amount: 160_000 }); // معادل قبلی در history، دوباره در انتظار
  t.late = b.tx({ type: 'expense', amount: 55_000, date: '1405-07-23', accountId: cash.id, categoryId: 'cat-expense-food', note: 'ثبت بدون نت' });
  b.set({ ...b.state, fx: { ...b.state.fx, lastRate: rate, lastError: { at: T1, message: 'دریافت نرخ ممکن نشد (اینترنت یا منبع در دسترس نیست).' } } });
  return { b, cash, bank, usd, owe, owed, goal, t, custom: custom.category };
}

export const clone = (x) => JSON.parse(JSON.stringify(x));
