import { test } from 'node:test';
import assert from 'node:assert/strict';
import { h, esc, raw, join } from '../src/ui/dom.js';
import { resolveRoute } from '../src/ui/routes.js';
import { parseRoute } from '../src/ui/app.js';
import { buildTxInput } from '../src/ui/actions-core.js';
import { pendingTransactions } from '../src/core/fx.js';
import * as L from '../src/core/ledger.js';
import { richBook, clone } from './fixtures.js';
import { Book } from './helpers.js';

const TODAY = '1405-07-20';
const mkCtx = (state, query = {}, extra = {}) => ({ state, today: TODAY, nowMs: Date.parse('2026-10-12T08:00:00Z'), online: true, query, ui: {}, prefs: { theme: 'auto', pin: null }, pendingCount: pendingTransactions(state).length, form: null, formErrors: [], values: null, ...extra });
const render = (path, state, query) => {
  const r = resolveRoute(parseRoute(`#/${path}`), mkCtx(state, query ?? parseRoute(`#/${path}`).query));
  assert.ok(r && typeof r.title === 'string', path);
  return String(r.html);
};

test('h`` مقادیر را escape می‌کند و raw را نه', () => {
  assert.equal(String(h`<p>${'<script>alert(1)</script>'}</p>`), '<p>&lt;script&gt;alert(1)&lt;/script&gt;</p>');
  assert.equal(String(h`<p title="${'" onmouseover="x'}">`), '<p title="&quot; onmouseover=&quot;x">');
  assert.equal(String(h`${raw('<b>x</b>')}`), '<b>x</b>');
  assert.equal(String(h`${h`<i>${'<'}</i>`}`), '<i>&lt;</i>'); // خروجی h دوباره escape نمی‌شود
  assert.equal(String(h`${[1, h`<u>${'&'}</u>`, null, false, undefined]}`), '1<u>&amp;</u>');
  assert.equal(esc("a'b`c"), 'a&#39;b&#96;c');
  assert.equal(String(join(['<', raw('<')], '|')), '&lt;|<');
});

test('همه‌ی صفحه‌ها روی داده‌ی کامل و روی state خالی بدون خطا رندر می‌شوند', () => {
  const rich = richBook().b.state;
  const empty = L.createEmptyState();
  const id = rich.transactions[0].id;
  const acc = rich.accounts[0].id;
  const debt = rich.debts[0].id;
  const goal = rich.goals[0].id;
  const bud = rich.budgets[0].id;
  const cat = rich.categories[0].id;
  const paths = ['home', 'transactions', 'transactions?range=all&type=expense', 'transactions?q=قهوه&range=all', 'add', 'add?type=income', 'add?type=transfer', `tx/${id}`, `tx/${id}/edit`, 'accounts', 'accounts/new', `accounts/${acc}`, `accounts/${acc}/edit`, 'more', 'rate', 'settings', 'backup', 'categories', 'categories/new', `categories/${cat}/edit`, 'budgets', 'budgets/new', `budgets/${bud}/edit`, 'goals', 'goals/new', `goals/${goal}`, `goals/${goal}/edit`, 'debts', 'debts/new?dir=owed', `debts/${debt}`, `debts/${debt}/edit`, 'reports', 'reports?range=year', 'reports?range=all', 'reports?range=custom&from=1405-01-01&to=1405-07-01', 'reports?cur=USD', 'نامعتبر', 'tx/ghost', 'accounts/ghost', 'goals/ghost', 'debts/ghost'];
  for (const p of paths) {
    assert.ok(render(p, rich).length > 20, `rich:${p}`);
    assert.ok(render(p, empty).length > 20, `empty:${p}`);
  }
});

test('نام و یادداشت مخرب در هیچ صفحه‌ای به HTML فعال تبدیل نمی‌شود', () => {
  const evil = '<img src=x onerror=alert(1)>';
  const b = new Book();
  const a = b.account(evil, { opening: 5000 });
  b.tx({ type: 'expense', accountId: a.id, categoryId: 'cat-expense-food', amount: 1000, date: TODAY, note: evil });
  b.debt({ direction: 'owe', person: evil, principal: 5000, currency: 'IRT', date: TODAY, note: evil });
  b.goal({ name: evil, currency: 'IRT', targetAmount: 9000 });
  const st = L.addCategory(b.state, { name: evil, kind: 'expense', icon: '😀', color: '#112233' }).state;
  const t = st.transactions[0];
  for (const p of ['home', 'transactions?range=all', `tx/${t.id}`, `tx/${t.id}/edit`, 'accounts', `accounts/${a.id}`, 'debts', `debts/${st.debts[0].id}`, `debts/${st.debts[0].id}/edit`, 'goals', `goals/${st.goals[0].id}`, 'categories', 'reports?range=all', 'add']) {
    const html = render(p, st);
    assert.ok(!html.includes('<img src=x'), p);
  }
});

test('رنگ دسته‌ی نامعتبر در استایل نمی‌آید', () => {
  const st = clone(richBook().b.state);
  st.categories[0].color = 'red;background:url(//evil)'; // نباید از اعتبارسنجی بگذرد، اما نمایش هم نباید آسیب‌پذیر باشد
  const html = render('categories', st);
  assert.ok(!html.includes('url(//evil)'));
});

test('parseRoute', () => {
  assert.deepEqual(parseRoute('#/tx/abc/edit?x=1&y=%D8%A7'), { parts: ['tx', 'abc', 'edit'], query: { x: '1', y: 'ا' }, path: 'tx/abc/edit' });
  assert.deepEqual(parseRoute('').parts, []);
  assert.deepEqual(parseRoute('#/a?%E0%A4%A=1').query, {}); // پارامتر خراب نادیده گرفته می‌شود
});

test('buildTxInput: تبدیل ورودی فرم به ورودی ledger و خطاها', () => {
  const b = new Book();
  const w = b.account('نقد', { opening: 0 });
  const d = b.account('دلاری', { currency: 'USD', opening: 0 });
  const base = { type: 'expense', amount: '۱٬۲۵۰', accountId: w.id, categoryId: 'cat-expense-food', date: TODAY, note: ' x ' };
  let r = buildTxInput(b.state, base);
  assert.deepEqual(r.errors, []);
  assert.equal(r.input.amount, 1250);
  r = buildTxInput(b.state, { ...base, amount: '12.5' });
  assert.equal(r.errors[0].field, 'amount'); // تومان اعشاری ندارد
  r = buildTxInput(b.state, { ...base, categoryId: '' });
  assert.equal(r.errors[0].field, 'categoryId');
  r = buildTxInput(b.state, { ...base, date: 'ناقص' });
  assert.equal(r.errors[0].field, 'date');
  r = buildTxInput(b.state, { ...base, accountId: d.id, amount: '12.5' });
  assert.deepEqual(r.errors, []);
  assert.equal(r.input.amount, 1250); // سنت
  const tr = { type: 'transfer', amount: '1000', fromAccountId: w.id, toAccountId: d.id, toAmount: '', date: TODAY };
  r = buildTxInput(b.state, tr);
  assert.equal(r.errors[0].field, 'toAmount');
  r = buildTxInput(b.state, { ...tr, toAmount: '2' });
  assert.deepEqual(r.errors, []);
  assert.equal(r.input.toAmount, 200);
  r = buildTxInput(b.state, { ...tr, toAccountId: '' });
  assert.equal(r.errors[0].field, 'toAccountId');
});

test('هیچ‌جای رابط کلمه‌ی «ریال» نیست', async () => {
  const { readdirSync, readFileSync, statSync } = await import('node:fs');
  const { join: pj } = await import('node:path');
  const walk = (d) => readdirSync(d).flatMap((n) => (statSync(pj(d, n)).isDirectory() ? walk(pj(d, n)) : [pj(d, n)]));
  for (const f of [...walk('src/ui'), 'public/index.html', 'public/manifest.webmanifest']) {
    assert.ok(!readFileSync(f, 'utf8').includes('ریال'), f);
  }
});
