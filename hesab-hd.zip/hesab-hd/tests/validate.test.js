import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as L from '../src/core/ledger.js';
import { parseState, validateState } from '../src/core/validate.js';
import { richBook, clone } from './fixtures.js';

const base = () => clone(richBook().b.state);

test('state سالم و کامل بدون هیچ تغییری پذیرفته می‌شود (رفت‌وبرگشت JSON)', () => {
  const original = richBook().b.state;
  const r = parseState(clone(original));
  assert.equal(r.ok, true, JSON.stringify(r.errors));
  assert.deepEqual(r.state, original); // پاک‌سازی چیزی کم یا زیاد نمی‌کند
  assert.equal(validateState(original).ok, true);
});

test('state خالی پیش‌فرض معتبر است', () => {
  const r = parseState(clone(L.createEmptyState()));
  assert.equal(r.ok, true);
  assert.equal(r.state.accounts.length, 0);
  assert.ok(r.state.categories.length >= 10);
});

test('فیلدهای اضافی و ناشناخته حذف می‌شوند (whitelist)', () => {
  const s = base();
  s.evil = { x: 1 };
  s.accounts[0].password = 'secret';
  s.transactions[0].__extra = 'x';
  s.transactions[0].usd.hack = 1;
  const r = parseState(s);
  assert.equal(r.ok, true, JSON.stringify(r.errors));
  assert.equal('evil' in r.state, false);
  assert.equal('password' in r.state.accounts[0], false);
  assert.equal('__extra' in r.state.transactions[0], false);
  assert.equal('hack' in r.state.transactions[0].usd, false);
});

test('ساختار کلی نامعتبر', () => {
  for (const bad of [null, undefined, 5, 'x', [], true]) assert.equal(parseState(bad).ok, false, String(bad));
  const noVersion = base();
  delete noVersion.version;
  assert.equal(parseState(noVersion).ok, false);
  const future = base();
  future.version = 99;
  const r = parseState(future);
  assert.equal(r.ok, false);
  assert.match(r.errors[0].message, /جدیدتر/);
  for (const key of ['accounts', 'categories', 'transactions', 'budgets', 'goals', 'debts']) {
    const s = base();
    s[key] = 'x';
    assert.equal(parseState(s).ok, false, key);
    const s2 = base();
    delete s2[key];
    assert.equal(parseState(s2).ok, false, `${key} حذف‌شده`);
  }
});

// هر جهش باید دقیقاً به رد شدن منجر شود و پیام خطا فارسی و دارای شماره‌ی ردیف باشد
const corruptions = {
  'مبلغ اعشاری': (s) => { s.transactions[0].amount = 1000.5; },
  'مبلغ رشته‌ای': (s) => { s.transactions[0].amount = '1000'; },
  'مبلغ منفی': (s) => { s.transactions[1].amount = -5; },
  'مبلغ صفر': (s) => { s.transactions[1].amount = 0; },
  'مبلغ بسیار بزرگ': (s) => { s.transactions[1].amount = 2e15; },
  'مبلغ NaN (null در JSON)': (s) => { s.transactions[1].amount = null; },
  'تاریخ میلادی': (s) => { s.transactions[0].date = '2026-10-11'; },
  'تاریخ ۳۰ اسفند سال غیرکبیسه': (s) => { s.transactions[0].date = '1404-12-30'; },
  'تاریخ غیر استاندارد': (s) => { s.transactions[0].date = '1405-7-1'; },
  'نوع تراکنش ناشناخته': (s) => { s.transactions[0].type = 'refund'; },
  'حساب ناموجود': (s) => { s.transactions[0].accountId = 'ghost'; },
  'دسته ناموجود': (s) => { s.transactions[1].categoryId = 'ghost'; },
  'دسته‌ی ناهم‌نوع': (s) => { s.transactions[1].categoryId = 'cat-income-salary'; },
  'ارز تراکنش با حساب یکی نیست': (s) => { s.transactions[0].currency = 'USD'; },
  'شناسه‌ی تراکنش تکراری': (s) => { s.transactions[1].id = s.transactions[0].id; },
  'شناسه‌ی حساب تکراری': (s) => { s.accounts[1].id = s.accounts[0].id; },
  'نام حساب تکراری': (s) => { s.accounts[1].name = s.accounts[0].name; },
  'ارز حساب نامعتبر': (s) => { s.accounts[0].currency = 'EUR'; },
  'موجودی اولیه اعشاری': (s) => { s.accounts[0].openingBalance = 1.5; },
  'نوع حساب نامعتبر': (s) => { s.accounts[0].type = 'crypto'; },
  'زمان ایجاد نامعتبر': (s) => { s.accounts[0].createdAt = 'دیروز'; },
  'رنگ دسته نامعتبر': (s) => { s.categories[0].color = 'red'; },
  'نام دسته‌ی تکراری': (s) => { s.categories[1].name = s.categories[0].name; s.categories[1].kind = s.categories[0].kind; },
  'انتقال به همان حساب': (s) => { const t = s.transactions.find((x) => x.type === 'transfer'); t.toAccountId = t.fromAccountId; },
  'انتقال هم‌ارز با مبلغ مقصد متفاوت': (s) => { const t = s.transactions.find((x) => x.type === 'transfer' && x.currency === x.toCurrency); t.toAmount = t.amount + 1; },
  'انتقال دو ارزی بدون مبلغ مقصد': (s) => { const t = s.transactions.find((x) => x.type === 'transfer' && x.currency !== x.toCurrency); t.toAmount = null; },
  'پرداخت بدهی بدون بدهی': (s) => { s.transactions.find((x) => x.type === 'debt_payment').debtId = 'ghost'; },
  'پرداخت بیش از اصل بدهی': (s) => { s.transactions.find((x) => x.type === 'debt_payment').amount = 9_999_999; },
  'بدهی با حساب ناموجود': (s) => { s.debts[1].accountId = 'ghost'; },
  'سررسید قبل از ثبت بدهی': (s) => { s.debts[0].dueDate = '1405-01-01'; },
  'جهت بدهی نامعتبر': (s) => { s.debts[0].direction = 'x'; },
  'معادل دلاری با مبلغ و نرخ هم‌خوان نیست': (s) => { s.transactions.find((x) => x.usd.status === 'done').usd.cents += 1; },
  'وضعیت دلاری ناشناخته': (s) => { s.transactions[0].usd.status = 'maybe'; },
  'تراکنش دلاری با وضعیت pending': (s) => { s.transactions.find((x) => x.currency === 'USD' && x.type === 'expense').usd = { status: 'pending' }; },
  'تراکنش تومانی بدون نیاز به دلار': (s) => { s.transactions[0].usd = { status: 'not_applicable' }; },
  'نرخ ثبت‌شده صفر': (s) => { s.transactions.find((x) => x.usd.status === 'done').usd.rate = 0; },
  'نرخ ثبت‌شده بدون منبع': (s) => { s.transactions.find((x) => x.usd.status === 'done').usd.source = ''; },
  'تاریخچه‌ی دلاری خراب': (s) => { s.transactions.find((x) => x.usd.history?.length).usd.history[0].cents = 'x'; },
  'بودجه با دسته‌ی ناموجود': (s) => { s.budgets[0].categoryId = 'ghost'; },
  'بودجه با سقف صفر': (s) => { s.budgets[0].limit = 0; },
  'بودجه با دوره‌ی نامعتبر': (s) => { s.budgets[0].period = 'yearly'; },
  'پایان بودجه قبل از شروع': (s) => { s.budgets[0].effectiveTo = '1400-01-01'; },
  'هدف با مبلغ صفر': (s) => { s.goals[0].targetAmount = 0; },
  'برداشت بیش از پس‌انداز': (s) => { s.goals[0].contributions[1].amount = 99_000_000; },
  'مشارکت با شناسه‌ی تکراری': (s) => { s.goals[0].contributions[1].id = s.goals[0].contributions[0].id; },
  'نرخ ذخیره‌شده‌ی fx نامعتبر': (s) => { s.fx.lastRate.value = -1; },
  'تعداد fx نامعتبر': (s) => { s.fx.maxAgeMinutes = 0; },
  'ساختار حساب آرایه': (s) => { s.accounts[0] = []; },
  'ساختار تراکنش null': (s) => { s.transactions[0] = null; },
};

for (const [name, mutate] of Object.entries(corruptions)) {
  test(`داده‌ی خراب رد می‌شود: ${name}`, () => {
    const s = base();
    mutate(s);
    const r = parseState(s);
    assert.equal(r.ok, false, `باید رد می‌شد: ${name}`);
    assert.equal(r.state, null);
    assert.ok(r.errors.length > 0 && r.errorCount > 0);
    assert.ok(r.errors.every((e) => typeof e.message === 'string' && /[؀-ۿ]/.test(e.message)), 'پیام خطا باید فارسی باشد');
  });
}

test('سقف تعداد خطاها و سقف تعداد رکورد', () => {
  const s = base();
  const t = s.transactions[1];
  s.transactions = Array.from({ length: 200 }, (_, i) => ({ ...t, id: `x${i}`, amount: -1 }));
  const r = parseState(s);
  assert.equal(r.ok, false);
  assert.ok(r.errorCount >= 200);
  assert.equal(r.errors.length, 50); // فقط ۵۰ خطای اول نشان داده می‌شود
  const big = base();
  big.accounts = Array.from({ length: 201 }, (_, i) => ({ ...big.accounts[0], id: `a${i}`, name: `h${i}` }));
  assert.equal(parseState(big).ok, false);
});

test('پیام خطا شماره‌ی ردیف را می‌گوید', () => {
  const s = base();
  s.transactions[2].amount = 1.5;
  const r = parseState(s);
  assert.ok(r.errors[0].message.includes('تراکنش 3'), r.errors[0].message);
  assert.equal(r.errors[0].path, 'transactions[2]');
});

test('نرخ و وضعیت fx اختیاری است', () => {
  const s = base();
  delete s.fx;
  const r = parseState(s);
  assert.equal(r.ok, true);
  assert.equal(r.state.fx.lastRate, null);
  assert.equal(r.state.fx.maxAgeMinutes, 30);
});
