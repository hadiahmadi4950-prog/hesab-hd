import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validatePinFormat, createPinRecord, verifyPin, lockoutMs, normalizePin } from '../src/ui/lock.js';
import { createPrefs } from '../src/ui/prefs.js';

test('قالب PIN', () => {
  assert.equal(validatePinFormat('4827').ok, true);
  assert.equal(validatePinFormat('۴۸۲۷').pin, '4827');
  for (const bad of ['', '12', '123456789', 'abcd', '1111', '1234', '9876', '12 34x']) assert.equal(validatePinFormat(bad).ok, false, bad);
  assert.equal(normalizePin(' ۱۲ '), '12');
});

test('PIN هش می‌شود و تأیید درست/نادرست کار می‌کند', async () => {
  const rec = await createPinRecord('4827', 1000);
  assert.ok(rec.salt && rec.hash);
  assert.ok(!JSON.stringify(rec).includes('4827'));
  assert.equal(await verifyPin('4827', rec), true);
  assert.equal(await verifyPin('۴۸۲۷', rec), true);
  assert.equal(await verifyPin('4828', rec), false);
  assert.equal(await verifyPin('', rec), false);
  assert.equal(await verifyPin('4827', null), false);
  const rec2 = await createPinRecord('4827', 1000);
  assert.notEqual(rec.salt, rec2.salt); // salt تصادفی
  assert.notEqual(rec.hash, rec2.hash);
  await assert.rejects(createPinRecord('1111'));
});

test('تأخیر پس از تلاش‌های ناموفق', () => {
  assert.equal(lockoutMs(0), 0);
  assert.equal(lockoutMs(4), 0);
  assert.equal(lockoutMs(5), 30_000);
  assert.equal(lockoutMs(6), 60_000);
  assert.equal(lockoutMs(50), 15 * 60_000);
});

test('prefs: ذخیره، پیش‌فرض و خرابی storage', () => {
  const mem = new Map();
  const st = { getItem: (k) => mem.get(k) ?? null, setItem: (k, v) => mem.set(k, v) };
  const p = createPrefs(st);
  assert.equal(p.get().theme, 'auto');
  p.set({ theme: 'dark' });
  assert.equal(createPrefs(st).get().theme, 'dark');
  mem.set('hesab-hd:prefs', '{خراب');
  assert.equal(createPrefs(st).get().theme, 'auto'); // JSON خراب → پیش‌فرض
  const broken = createPrefs({ getItem() { throw new Error('x'); }, setItem() { throw new Error('x'); } });
  assert.equal(broken.set({ theme: 'light' }).theme, 'light');
  assert.equal(broken.get().theme, 'light'); // فقط در حافظه
});
