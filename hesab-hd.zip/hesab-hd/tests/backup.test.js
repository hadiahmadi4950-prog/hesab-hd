import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as L from '../src/core/ledger.js';
import * as B from '../src/core/backup.js';
import { richBook, clone, T1 } from './fixtures.js';
import { Book, makeCtx } from './helpers.js';

const NOW = '2026-10-11T09:00:00.000Z';

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = '';
  let q = false;
  const s = text.replace(/^﻿/, '');
  for (let i = 0; i < s.length; i += 1) {
    const ch = s[i];
    if (q) {
      if (ch === '"' && s[i + 1] === '"') {
        cell += '"';
        i += 1;
      } else if (ch === '"') q = false;
      else cell += ch;
    } else if (ch === '"') q = true;
    else if (ch === ',') {
      row.push(cell);
      cell = '';
    } else if (ch === '\r' && s[i + 1] === '\n') {
      row.push(cell);
      rows.push(row);
      row = [];
      cell = '';
      i += 1;
    } else cell += ch;
  }
  if (cell !== '' || row.length) {
    row.push(cell);
    rows.push(row);
  }
  return rows;
}

const throwsBackup = (fn, code) => {
  try {
    fn();
  } catch (e) {
    assert.equal(e.name, 'BackupError', `${e.name}: ${e.message}`);
    assert.equal(e.code, code);
    return e;
  }
  assert.fail('انتظار خطا بود');
};

test('crc32: بردارهای شناخته‌شده', () => {
  assert.equal(B.crc32('123456789'), 'cbf43926');
  assert.equal(B.crc32(''), '00000000');
  assert.equal(B.crc32('a'), 'e8b7be43');
  assert.notEqual(B.crc32('حساب'), B.crc32('حسان'));
});

test('خروجی JSON: قالب، شمارش و رفت‌وبرگشت کامل بدون هیچ تغییری', () => {
  const { b } = richBook();
  const text = B.exportJSON(b.state, { now: NOW, appVersion: '0.1.0' });
  const env = JSON.parse(text);
  assert.equal(env.format, 'hesab-hd-backup');
  assert.equal(env.formatVersion, 1);
  assert.equal(env.appName, 'حساب HD');
  assert.equal(env.exportedAt, NOW);
  assert.match(env.checksum.value, /^[0-9a-f]{8}$/);
  assert.deepEqual(env.counts, { accounts: 3, categories: b.state.categories.length, transactions: b.state.transactions.length, debts: 2, goals: 1, budgets: 3 });
  const r = B.parseBackup(text);
  assert.equal(r.ok, true, JSON.stringify(r.errors));
  assert.deepEqual(r.state, b.state);
  assert.equal(r.meta.exportedAt, NOW);
  assert.equal(r.meta.counts.transactions, b.state.transactions.length);
  // خروجی دوباره از داده‌ی واردشده دقیقاً همان متن است
  assert.equal(B.exportJSON(r.state, { now: NOW, appVersion: '0.1.0' }), text);
});

test('متن فارسی، ایموجی، خط جدید و کاراکترهای خاص در JSON حفظ می‌شود', () => {
  const { b, t } = richBook();
  const r = B.parseBackup(B.exportJSON(b.state, { now: NOW }));
  const food = r.state.transactions.find((x) => x.id === t.food.id);
  assert.equal(food.note, 'نان، پنیر و "سبزی"\nخط دوم');
  assert.equal(r.state.transactions.find((x) => x.id === t.fun.id).note, 'سینما 😊');
});

test('خروجی JSON از داده‌ی ناسازگار ساخته نمی‌شود', () => {
  const { b } = richBook();
  const broken = clone(b.state);
  broken.transactions[0].amount = 1.5;
  throwsBackup(() => B.exportJSON(broken, { now: NOW }), 'STATE_INVALID');
});

test('فایل خراب، ناقص یا دست‌کاری‌شده رد می‌شود', () => {
  const { b } = richBook();
  const text = B.exportJSON(b.state, { now: NOW });
  const fails = {
    'غیررشته': 12345,
    خالی: '',
    'متن بی‌ربط': 'سلام دنیا',
    'JSON ناقص (نیمه‌ی فایل)': text.slice(0, Math.floor(text.length / 2)),
    'JSON ناقص (چند نویسه‌ی آخر)': text.slice(0, -5),
    آرایه: '[]',
    'قالب دیگر': text.replace('hesab-hd-backup', 'other-app-backup'),
    'نسخه‌ی قالب جدیدتر': text.replace('"formatVersion": 1', '"formatVersion": 2'),
    'نسخه‌ی قالب نامعتبر': text.replace('"formatVersion": 1', '"formatVersion": 0'),
    'بدون checksum': JSON.stringify({ ...JSON.parse(text), checksum: undefined }),
    'checksum اشتباه': text.replace(/"value": "[0-9a-f]{8}"/, '"value": "00000000"'),
    'دستکاری مبلغ در متن': text.replace('"amount": 10000000', '"amount": 99999999'),
    'حذف داده': JSON.stringify({ ...JSON.parse(text), data: null }),
  };
  for (const [name, input] of Object.entries(fails)) {
    const r = B.parseBackup(input);
    assert.equal(r.ok, false, `باید رد می‌شد: ${name}`);
    assert.equal(r.state, null, name);
    assert.ok(r.errors.length > 0 && typeof r.errors[0].message === 'string', name);
  }
  // دستکاری ماهرانه: داده‌ی نامعتبر + checksum دوباره‌محاسبه‌شده، باز هم در اعتبارسنجی ساختار رد می‌شود
  const env = JSON.parse(text);
  env.data.transactions[0].amount = -50;
  env.checksum.value = B.crc32(JSON.stringify(env.data));
  const r2 = B.parseBackup(JSON.stringify(env));
  assert.equal(r2.ok, false);
  assert.ok(r2.errors[0].message.includes('تراکنش 1'));
  // تعداد رکوردها با محتوا نمی‌خواند
  const env2 = JSON.parse(text);
  env2.counts.transactions += 1;
  const r3 = B.parseBackup(JSON.stringify(env2));
  assert.equal(r3.ok, false);
  assert.match(r3.errors[0].message, /تعداد/);
});

test('فایل با BOM یا قالب‌بندی متفاوت (فاصله/تورفتگی) پذیرفته می‌شود', () => {
  const { b } = richBook();
  const text = B.exportJSON(b.state, { now: NOW });
  assert.equal(B.parseBackup(`﻿${text}`).ok, true);
  assert.equal(B.parseBackup(JSON.stringify(JSON.parse(text))).ok, true); // فشرده
  assert.equal(B.parseBackup(JSON.stringify(JSON.parse(text), null, 4)).ok, true);
  assert.equal(B.parseBackup(`\n\n${text}\n\n`).ok, true);
});

test('جایگزینی کامل: بدون تأیید انجام نمی‌شود و با تأیید، نسخه‌ی پشتیبان خودکار می‌سازد', () => {
  const { b } = richBook();
  const incoming = B.parseBackup(B.exportJSON(b.state, { now: NOW })).state;
  const empty = L.createEmptyState();
  const current = new Book();
  current.account('حساب جاری', { opening: 777 });
  throwsBackup(() => B.restoreReplace(current.state, incoming), 'CONFIRM_REQUIRED');
  throwsBackup(() => B.restoreReplace(current.state, incoming, { confirm: 'yes' }), 'CONFIRM_REQUIRED');
  throwsBackup(() => B.restoreReplace(current.state, incoming, { confirm: 1 }), 'CONFIRM_REQUIRED');
  assert.equal(current.state.accounts[0].name, 'حساب جاری'); // دست‌نخورده
  const r = B.restoreReplace(current.state, incoming, { confirm: true, now: NOW });
  assert.deepEqual(r.state, b.state);
  assert.equal(r.removed.accounts, 1);
  // نسخه‌ی خودکارِ داده‌ی قبلی معتبر است و قابل بازگردانی
  const back = B.parseBackup(r.safetyBackup);
  assert.equal(back.ok, true);
  assert.equal(back.state.accounts[0].name, 'حساب جاری');
  // اگر داده‌ی فعلی خالی باشد نسخه‌ی خودکار لازم نیست
  assert.equal(B.restoreReplace(empty, incoming, { confirm: true }).safetyBackup, null);
  // ورودی نامعتبر هیچ‌وقت جایگزین نمی‌شود
  const broken = clone(incoming);
  broken.transactions[0].amount = 0.5;
  throwsBackup(() => B.restoreReplace(current.state, broken, { confirm: true }), 'INCOMING_INVALID');
});

test('ادغام: وارد کردن همان فایل (یک یا چند بار) هیچ تکراری نمی‌سازد', () => {
  const { b } = richBook();
  const incoming = B.parseBackup(B.exportJSON(b.state, { now: NOW })).state;
  let r = B.mergeStates(b.state, incoming);
  assert.deepEqual(r.state, b.state);
  assert.deepEqual(r.report.added, { accounts: 0, categories: 0, transactions: 0, debts: 0, goals: 0, budgets: 0 });
  assert.equal(r.report.skippedExisting.transactions, b.state.transactions.length);
  assert.equal(r.report.skippedExisting.accounts, 3);
  r = B.mergeStates(r.state, incoming);
  assert.deepEqual(r.state, b.state);
  // ادغام در یک دفتر خالی، همه چیز را می‌آورد
  const into = B.mergeStates(L.createEmptyState(), incoming);
  assert.equal(into.state.transactions.length, b.state.transactions.length);
  assert.equal(into.state.accounts.length, 3);
  assert.equal(into.report.added.transactions, b.state.transactions.length);
  assert.deepEqual(L.totalBalances(into.state), L.totalBalances(b.state));
});

test('ادغام دو دستگاه: فقط موارد جدید، حساب جدید، و یکی‌کردن دسته‌ی هم‌نام با شناسه‌ی متفاوت', () => {
  const a = richBook();
  // دستگاه دوم: همان دفتر، اما دسته‌ی «قهوه» آنجا شناسه‌ی دیگری دارد
  const file = JSON.parse(JSON.stringify(a.b.state).replaceAll(`"${a.custom.id}"`, '"dev2-cat-1"'));
  const ctx = (id) => ({ now: () => '2026-10-12T08:00:00.000Z', id: () => id });
  let s = file;
  s = L.addTransaction(s, { type: 'expense', amount: 33_000, date: '1405-07-24', accountId: a.cash.id, categoryId: 'cat-expense-food', note: 'فقط در دستگاه دوم' }, ctx('dev2-tx-1')).state;
  s = L.addAccount(s, { name: 'نقد ۲', openingBalance: 5000 }, ctx('dev2-acc-1')).state;
  s = L.addTransaction(s, { type: 'expense', amount: 44_000, date: '1405-07-24', accountId: 'dev2-acc-1', categoryId: 'dev2-cat-1', note: 'قهوه‌ی دستگاه دوم' }, ctx('dev2-tx-2')).state;
  const parsed = B.parseBackup(B.exportJSON(s, { now: NOW }));
  assert.equal(parsed.ok, true, JSON.stringify(parsed.errors));
  const m = B.mergeStates(a.b.state, parsed.state);
  assert.equal(m.report.added.transactions, 2);
  assert.equal(m.report.added.accounts, 1);
  assert.equal(m.report.added.categories, 0); // دسته‌ی هم‌نام، یکی حساب شد
  assert.equal(m.report.mappedCategories, 1);
  assert.equal(m.state.transactions.length, a.b.state.transactions.length + 2);
  assert.equal(m.state.transactions.find((t) => t.id === 'dev2-tx-2').categoryId, a.custom.id); // ارجاع به دسته‌ی موجود منتقل شد
  assert.equal(m.state.categories.length, a.b.state.categories.length);
  assert.equal(L.accountBalance(m.state, a.cash.id), L.accountBalance(a.b.state, a.cash.id) - 33_000);
  assert.equal(L.accountBalance(m.state, 'dev2-acc-1'), 5000 - 44_000);
  // موارد فعلی دست‌نخورده‌اند
  for (const t of a.b.state.transactions) assert.deepEqual(m.state.transactions.find((x) => x.id === t.id), t);
});

test('ادغام: نام حساب و هدف هم‌نام (با شناسه‌ی متفاوت) با پسوند «واردشده» می‌آید', () => {
  const cur = new Book();
  cur.account('نقد', { opening: 100 });
  cur.goal({ name: 'سفر', targetAmount: 1000 });
  const otherCtx = (id) => ({ now: () => '2026-10-12T08:00:00.000Z', id: () => id });
  const acc = L.addAccount(L.createEmptyState(), { name: 'نقد', openingBalance: 900 }, otherCtx('other-acc'));
  let s = acc.state;
  s = L.addGoal(s, { name: 'سفر', targetAmount: 2000 }, otherCtx('other-goal')).state;
  s = L.addTransaction(s, { type: 'income', amount: 500, date: '1405-07-24', accountId: 'other-acc', categoryId: 'cat-income-salary' }, otherCtx('other-tx')).state;
  const m = B.mergeStates(cur.state, s);
  assert.deepEqual(m.report.renamed, [{ kind: 'account', from: 'نقد', to: 'نقد (واردشده)' }, { kind: 'goal', from: 'سفر', to: 'سفر (واردشده)' }]);
  assert.equal(m.state.accounts.length, 2);
  assert.equal(L.accountBalance(m.state, 'other-acc'), 1400);
  assert.equal(m.state.goals.length, 2);
  // ادغام دوباره، تکراری نمی‌سازد (شناسه‌ها یکی‌اند)
  const again = B.mergeStates(m.state, s);
  assert.equal(again.state.accounts.length, 2);
  assert.equal(again.state.transactions.length, 1);
});

test('ادغام: تراکنش هم‌محتوا با شناسه‌ی متفاوت پیش‌فرض رد می‌شود و با گزینه اضافه می‌شود', () => {
  const a = richBook();
  const incoming = clone(a.b.state);
  const orig = incoming.transactions.find((t) => t.id === a.t.salary.id);
  incoming.transactions.push({ ...clone(orig), id: 'copy-of-salary', requestId: null });
  const file = B.parseBackup(B.exportJSON(incoming, { now: NOW })).state;
  const skip = B.mergeStates(a.b.state, file);
  assert.equal(skip.report.skippedDuplicates, 1);
  assert.equal(skip.state.transactions.length, a.b.state.transactions.length);
  const keep = B.mergeStates(a.b.state, file, { skipContentDuplicates: false });
  assert.equal(keep.report.added.transactions, 1);
  assert.equal(keep.state.transactions.length, a.b.state.transactions.length + 1);
});

test('ادغام: ناسازگاری با داده‌ی فعلی، کل ادغام را رد می‌کند و داده‌ی فعلی دست‌نخورده می‌ماند', () => {
  const a = richBook();
  // دفتر فعلی ۱۰۰ هزار تومان بیشتر از بدهی پرداخته است (جمعاً ۴۰۰ هزار از ۱ میلیون)
  let cur = a.b.state;
  cur = L.addTransaction(cur, { type: 'debt_payment', amount: 100_000, date: '1405-07-23', accountId: a.bank.id, debtId: a.owe.id }, makeCtx('2026-10-13T08:00:00.000Z')).state;
  // دستگاه دوم هم ۷۰۰ هزار پرداخته (با شناسه‌ی دیگر) که به‌تنهایی معتبر است
  const other = clone(a.b.state);
  other.transactions.push({ ...clone(a.t.pay), id: 'dev2-pay', amount: 700_000, requestId: null, note: 'دستگاه دوم' });
  const file = B.parseBackup(B.exportJSON(other, { now: NOW }));
  assert.equal(file.ok, true, JSON.stringify(file.errors));
  const before = JSON.stringify(cur);
  const e = throwsBackup(() => B.mergeStates(cur, file.state), 'MERGE_INVALID');
  assert.ok(e.errors.length > 0);
  assert.equal(JSON.stringify(cur), before);
});

test('ادغام: تعارض شناسه‌ی یکسان با محتوای متفاوت → نسخه‌ی فعلی حفظ و گزارش می‌شود', () => {
  const a = richBook();
  const incoming = clone(a.b.state);
  incoming.accounts[0].openingBalance += 12345;
  incoming.debts[0].note = 'تغییر کرده';
  incoming.debts[0].principal += 1;
  const m = B.mergeStates(a.b.state, B.parseBackup(B.exportJSON(incoming, { now: NOW })).state);
  assert.deepEqual(m.state.accounts[0], a.b.state.accounts[0]);
  assert.equal(m.report.conflicts.length, 2);
  assert.ok(m.report.conflicts.every((c) => /حفظ شد/.test(c)));
});

test('ادغام بودجه: دو بودجه‌ی فعال هم‌کلید در فایل ورودی نادیده گرفته می‌شود', () => {
  const a = richBook();
  const incoming = clone(a.b.state);
  const open = incoming.budgets.find((x) => !x.effectiveTo && x.categoryId === 'cat-expense-food');
  incoming.budgets.push({ ...clone(open), id: 'other-budget', limit: 777_000 });
  const file = B.parseBackup(B.exportJSON(incoming, { now: NOW })).state;
  const m = B.mergeStates(a.b.state, file);
  assert.equal(m.report.skippedBudgetConflicts, 1);
  assert.equal(m.state.budgets.length, a.b.state.budgets.length);
});

test('پیش‌نمایش بازیابی', () => {
  const a = richBook();
  const incoming = B.parseBackup(B.exportJSON(a.b.state, { now: NOW })).state;
  const cur = new Book();
  let n = 0;
  cur.ctx.id = () => `cur-${++n}`;
  cur.account('جداگانه', { opening: 1000 });
  const p = B.previewRestore(cur.state, incoming);
  assert.equal(p.currentHasData, true);
  assert.equal(p.current.accounts, 1);
  assert.equal(p.incoming.accounts, 3);
  assert.equal(p.incoming.transactions, a.b.state.transactions.length);
  assert.deepEqual(p.incoming.dateRange, { from: '1405-07-18', to: '1405-07-23' });
  assert.equal(p.incoming.pendingUsd, a.b.state.transactions.filter((t) => t.usd.status === 'pending').length);
  assert.deepEqual(p.incoming.balances, L.totalBalances(a.b.state));
  assert.equal(p.merge.ok, true);
  assert.equal(p.merge.report.added.transactions, a.b.state.transactions.length);
  assert.equal(p.merge.result.accounts, 4);
  assert.equal(p.replace.willRemove.accounts, 1);
  assert.equal(B.previewRestore(L.createEmptyState(), incoming).currentHasData, false);
  // پیش‌نمایش هیچ‌چیز را عوض نمی‌کند
  assert.equal(cur.state.accounts.length, 1);
  // حالت ادغام ناسازگار در پیش‌نمایش خطا می‌دهد، نه exception
  const bad = clone(a.b.state);
  const curBad = L.addTransaction(a.b.state, { type: 'debt_payment', amount: 100_000, date: '1405-07-23', accountId: a.bank.id, debtId: a.owe.id }, makeCtx('2026-10-13T08:00:00.000Z')).state;
  bad.transactions.push({ ...clone(a.t.pay), id: 'dev2-pay', amount: 700_000, requestId: null, note: 'x' });
  const pv = B.previewRestore(curBad, B.parseBackup(B.exportJSON(bad, { now: NOW })).state);
  assert.equal(pv.merge.ok, false);
  assert.equal(typeof pv.merge.error, 'string');
});

test('CSV تراکنش‌ها: BOM، CRLF، ستون‌ها، فارسی، escape و امنیت فرمول', () => {
  const { b, t } = richBook();
  const csv = B.exportCSV(b.state);
  assert.equal(csv.charCodeAt(0), 0xfeff);
  assert.ok(csv.endsWith('\r\n'));
  const rows = parseCsv(csv);
  assert.equal(rows.length, b.state.transactions.length + 1);
  assert.equal(rows[0].length, 21);
  assert.equal(rows[0][0], 'شناسه');
  assert.ok(rows.every((r) => r.length === 21), 'همه‌ی ردیف‌ها ۲۱ ستون دارند');
  const byId = Object.fromEntries(rows.slice(1).map((r) => [r[0], r]));
  const col = (name) => rows[0].indexOf(name);
  // یادداشت با ویرگول، گیومه و خط جدید دقیقاً برمی‌گردد
  assert.equal(byId[t.food.id][col('یادداشت')], 'نان، پنیر و "سبزی"\nخط دوم');
  // تزریق فرمول خنثی می‌شود
  assert.equal(byId[t.coffee.id][col('یادداشت')], "'=SUM(A1:A2)");
  // ایموجی و فارسی
  assert.equal(byId[t.fun.id][col('یادداشت')], 'سینما 😊');
  // مبلغ تومان: عدد ساده‌ی لاتین بدون جداکننده و بدون ریال
  assert.equal(byId[t.salary.id][col('مبلغ')], '10000000');
  assert.equal(byId[t.salary.id][col('واحد')], 'تومان');
  assert.equal(byId[t.salary.id][col('نوع')], 'درآمد');
  assert.equal(byId[t.salary.id][col('تاریخ شمسی')], '1405-07-18');
  assert.equal(byId[t.salary.id][col('حساب')], 'بانک');
  assert.equal(byId[t.salary.id][col('دسته')], 'حقوق');
  // تراکنش دلاری: مبلغ به دلار
  assert.equal(byId[t.fun.id][col('مبلغ')], '15.99');
  assert.equal(byId[t.fun.id][col('واحد')], 'دلار');
  assert.equal(byId[t.fun.id][col('معادل دلاری (دلار)')], '15.99');
  assert.equal(byId[t.fun.id][col('وضعیت دلار')], 'بدون نیاز');
  // انتقال دو ارزی
  assert.equal(byId[t.exchange.id][col('نوع')], 'انتقال');
  assert.equal(byId[t.exchange.id][col('حساب')], 'بانک');
  assert.equal(byId[t.exchange.id][col('حساب مقصد')], 'ارزی');
  assert.equal(byId[t.exchange.id][col('مبلغ مقصد')], '10.00');
  assert.equal(byId[t.exchange.id][col('واحد مقصد')], 'دلار');
  // معادل دلاری محاسبه‌شده و نرخ و منبع
  assert.equal(byId[t.coffee.id][col('وضعیت دلار')], 'محاسبه‌شده');
  assert.equal(byId[t.coffee.id][col('معادل دلاری (دلار)')], '0.90');
  assert.equal(byId[t.coffee.id][col('نرخ دلار (تومان)')], '100000');
  assert.equal(byId[t.coffee.id][col('منبع نرخ')], 'منبع آزمایشی');
  assert.equal(byId[t.coffee.id][col('نرخ دستی')], 'خیر');
  // در انتظار
  assert.equal(byId[t.late.id][col('وضعیت دلار')], 'در انتظار');
  assert.equal(byId[t.late.id][col('معادل دلاری (دلار)')], '');
  assert.equal(byId[t.food.id][col('وضعیت دلار')], 'در انتظار'); // ویرایش‌شده
  // پرداخت بدهی با نام طرف حساب
  assert.equal(byId[t.pay.id][col('طرف بدهی/طلب')], 'علی (بدهی من)');
  assert.equal(byId[t.recv.id][col('طرف بدهی/طلب')], 'رضا (طلب من)');
  // مرتب بر اساس تاریخ صعودی
  const dates = rows.slice(1).map((r) => r[col('تاریخ شمسی')]);
  assert.deepEqual(dates, [...dates].sort());
});

test('CSV: نام حساب با نویسه‌ی فرمول هم خنثی می‌شود و CSV حساب‌ها درست است', () => {
  const b = new Book();
  const a = b.account('=HYPERLINK("x")', { opening: 5000 });
  b.account('بانک', { opening: 100, currency: 'USD', type: 'fx' });
  b.tx({ type: 'expense', amount: 1000, date: '1405-07-19', accountId: a.id, categoryId: 'cat-expense-food' });
  const rows = parseCsv(B.exportCSV(b.state));
  assert.equal(rows[1][5], "'=HYPERLINK(\"x\")");
  const acc = parseCsv(B.exportCSV(b.state, { kind: 'accounts' }));
  assert.deepEqual(acc[0], ['نام', 'نوع', 'واحد', 'موجودی اولیه', 'موجودی فعلی', 'بایگانی‌شده']);
  assert.deepEqual(acc[1], ["'=HYPERLINK(\"x\")", 'پول نقد', 'تومان', '5000', '4000', 'خیر']);
  assert.deepEqual(acc[2], ['بانک', 'حساب ارزی', 'دلار', '1.00', '1.00', 'خیر']);
  throwsBackup(() => B.exportCSV(b.state, { kind: 'x' }), 'BAD_KIND');
  // دفتر خالی: فقط سرستون
  assert.equal(parseCsv(B.exportCSV(L.createEmptyState())).length, 1);
});

test('نام فایل پشتیبان با تاریخ شمسی تهران', () => {
  assert.equal(B.backupFileName('2026-10-11T09:00:00.000Z'), 'hesab-hd-backup-1405-07-19.json');
  assert.equal(B.backupFileName('2026-10-11T21:00:00.000Z'), 'hesab-hd-backup-1405-07-20.json'); // بعد از نیمه‌شب تهران
  assert.equal(B.backupFileName('2026-10-11T09:00:00.000Z', 'csv', 'transactions'), 'hesab-hd-transactions-1405-07-19.csv');
});

test('عملکرد: ۵٬۰۰۰ تراکنش، خروجی و ورود در زمان معقول و بدون خطا', () => {
  const b = new Book();
  const a1 = b.account('الف', { opening: 1_000_000_000 });
  const a2 = b.account('ب', { opening: 5 });
  let s = b.state;
  const ctx = makeCtx();
  for (let i = 0; i < 5000; i += 1) {
    const day = J_add('1405-01-01', i % 360);
    s = L.addTransaction(s, i % 7 === 0 ? { type: 'transfer', amount: 1000 + i, date: day, fromAccountId: a1.id, toAccountId: a2.id, note: `t${i}` } : { type: i % 3 === 0 ? 'income' : 'expense', amount: 1000 + i, date: day, accountId: a1.id, categoryId: i % 3 === 0 ? 'cat-income-salary' : 'cat-expense-food', note: `n${i}` }, ctx).state;
  }
  const t0 = Date.now();
  const text = B.exportJSON(s, { now: NOW });
  const r = B.parseBackup(text);
  const ms = Date.now() - t0;
  assert.equal(r.ok, true, JSON.stringify(r.errors?.slice(0, 2)));
  assert.equal(r.state.transactions.length, 5000);
  assert.deepEqual(L.totalBalances(r.state), L.totalBalances(s));
  assert.ok(ms < 5000, `زمان ${ms}ms`);
  assert.equal(parseCsv(B.exportCSV(s)).length, 5001);
});

import { addDays as J_add } from '../src/core/jalali.js';
void T1;
