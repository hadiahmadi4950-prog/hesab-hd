import { launch, watch, check } from './lib.mjs';
import { writeFileSync, readFileSync } from 'node:fs';

const latin = (s) => s.replace(/[۰-۹]/g, (c) => String(c.charCodeAt(0) - 0x06f0)).replace(/[٬،,]/g, '');
const TMP = '/tmp/claude-0';
const L = await launch();
const ctx = await L.context({ acceptDownloads: true });
const page = await ctx.newPage();
const bag = watch(page);
await page.clock.install({ time: new Date('2026-10-12T08:00:00Z') });
await page.route('**/raw.githubusercontent.com/**', (r) => r.abort());
const main = async () => latin(await page.textContent('#main'));
const go = async (h) => { await page.evaluate((x) => { location.hash = x; }, h); await page.waitForTimeout(150); };
const toast = (t) => page.waitForSelector(`.toast:has-text("${t}")`);
const snapshot = () => page.evaluate(() => { const canon = (v) => (Array.isArray(v) ? v.map(canon) : v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canon(v[k])])) : v); const s = structuredClone(window.__hesab.store.state); delete s.fx; for (const k of ['accounts', 'categories', 'transactions', 'budgets', 'goals', 'debts']) s[k].sort((x, y) => (x.id < y.id ? -1 : 1)); return JSON.stringify(canon(s)); });

await page.goto(L.url);
await page.waitForSelector('#main');

// ---- بذر داده‌ی متنوع در چند ماه ----
await page.evaluate(async () => {
  const L = await import('./src/core/ledger.js');
  const ctx = { now: () => new Date().toISOString(), id: () => crypto.randomUUID() };
  const c = window.__hesab;
  let a, b;
  await c.commit((s) => { const r = L.addAccount(s, { name: 'بانک ملی', type: 'bank', currency: 'IRT', openingBalance: 20_000_000 }, ctx); a = r.account.id; return r.state; });
  await c.commit((s) => { const r = L.addAccount(s, { name: 'دلاری', type: 'fx', currency: 'USD', openingBalance: 50000 }, ctx); b = r.account.id; return r.state; });
  const add = (input) => c.commit((s) => L.addTransaction(s, input, ctx, { allowDuplicate: true }));
  const dates = ['1405-04-05', '1405-05-10', '1405-06-12', '1405-07-02', '1405-07-15', '1405-07-20'];
  for (const [i, d] of dates.entries()) {
    await add({ type: 'income', accountId: a, categoryId: 'cat-income-salary', amount: 8_000_000 + i * 100_000, date: d, note: `حقوق ${i}` });
    await add({ type: 'expense', accountId: a, categoryId: 'cat-expense-food', amount: 1_000_000 + i * 50_000, date: d, note: i === 0 ? '=SUM(1)' : 'خرید' });
    await add({ type: 'expense', accountId: a, categoryId: 'cat-expense-transport', amount: 300_000, date: d });
  }
  await add({ type: 'transfer', fromAccountId: a, toAccountId: b, amount: 1_000_000, toAmount: 400, date: '1405-07-10' });
  await c.commit((s) => L.addGoal(s, { name: 'سفر', currency: 'IRT', targetAmount: 50_000_000 }, ctx).state);
  await c.commit((s) => L.addDebt(s, { direction: 'owe', person: 'رضا', principal: 2_000_000, currency: 'IRT', date: '1405-07-01', dueDate: '1405-07-10' }, ctx).state);
  await c.commit((s) => L.setBudget(s, { categoryId: null, period: 'monthly', limit: 3_000_000, effectiveFrom: '1405-07-01' }, ctx).state);
});
const original = await snapshot();

// ---- گزارش‌ها ----
await go('#/reports');
await page.waitForSelector('svg[role=img]');
let t = await main();
// مهر ۱۴۰۵ سه روز تراکنش دارد: درآمد ۸٬۳۰۰٬۰۰۰+۸٬۴۰۰٬۰۰۰+۸٬۵۰۰٬۰۰۰ = ۲۵٬۲۰۰٬۰۰۰ ؛ هزینه: خوراک ۳٬۶۰۰٬۰۰۰ + رفت‌وآمد ۹۰۰٬۰۰۰ = ۴٬۵۰۰٬۰۰۰
check('درآمد این ماه = ۲۵٬۲۰۰٬۰۰۰', t.includes('25200000'));
check('هزینه این ماه = ۴٬۵۰۰٬۰۰۰ (انتقال حساب نشد)', t.includes('4500000') && !t.includes('5500000'));
check('نمودارها دارای توضیح متنی (aria-label)', (await page.locator('svg[role=img][aria-label]').count()) >= 2);
await go('#/reports?range=year');
await page.waitForSelector('svg[role=img]');
check('گزارش امسال بدون خطا', (await main()).includes('خلاصه'));
await go('#/reports?range=all');
check('گزارش «همه»', (await main()).includes('خلاصه'));
await go('#/reports?range=custom&from=1405-07-01&to=1405-07-05');
check('بازه‌ی دلخواه: فقط ۱۴۰۵/۰۷/۰۲', (await main()).includes('8300000'));
await go('#/reports?cur=USD');
check('گزارش دلاری: بدون تراکنش دلاری → پیام خالی یا خلاصه', (await main()).length > 50);
await go('#/reports?range=custom&from=bad&to=worse');
check('پارامتر نامعتبر خطا نمی‌دهد', (await main()).includes('خلاصه'));

// ---- پشتیبان JSON ----
await go('#/backup');
const [dl] = await Promise.all([page.waitForEvent('download'), page.click('[data-action=download-backup]')]);
const backupPath = `${TMP}/backup-test.json`;
await dl.saveAs(backupPath);
const env = JSON.parse(readFileSync(backupPath, 'utf8'));
check('نام فایل پشتیبان شمسی', /hesab-hd-backup-1405-07-20\.json/.test(dl.suggestedFilename()), dl.suggestedFilename());
check('ساختار پشتیبان صحیح', env.format === 'hesab-hd-backup' && env.counts.transactions === 19 && env.checksum.algo === 'crc32');
check('تاریخ آخرین پشتیبان ثبت شد', (await main()).includes('آخرین پشتیبان'));

// ---- CSV ----
const [dc] = await Promise.all([page.waitForEvent('download'), page.click('[data-action=download-csv][data-kind=transactions]')]);
await dc.saveAs(`${TMP}/tx.csv`);
const csv = readFileSync(`${TMP}/tx.csv`);
check('CSV با BOM UTF-8', csv[0] === 0xef && csv[1] === 0xbb && csv[2] === 0xbf);
check('CSV: ضد تزریق فرمول', csv.toString('utf8').includes("'=SUM(1)"));

// ---- فایل خراب/دست‌کاری‌شده رد می‌شود ----
const tampered = JSON.parse(JSON.stringify(env));
tampered.data.transactions[0].amount += 1;
writeFileSync(`${TMP}/tampered.json`, JSON.stringify(tampered));
writeFileSync(`${TMP}/garbage.json`, '{ این json نیست');
writeFileSync(`${TMP}/other.json`, JSON.stringify({ hello: 'world' }));
for (const [f, expect] of [['tampered', 'checksum'], ['garbage', 'JSON'], ['other', 'پشتیبان «حساب HD» نیست']]) {
  await page.setInputFiles('#restorefile', `${TMP}/${f}.json`);
  await page.waitForSelector('#import-result .notice.error');
  check(`فایل ${f} رد شد`, (await page.textContent('#import-result')).includes(expect), await page.textContent('#import-result'));
}
check('رد فایل خراب چیزی را تغییر نداد', (await snapshot()) === original);

// ---- ادغام با خودش: بدون تکرار ----
await page.setInputFiles('#restorefile', backupPath);
await page.waitForSelector('.sheet');
check('پیش‌نمایش محتوا نشان داده می‌شود', (await page.textContent('.sheet')).includes('بررسی فایل پشتیبان'));
await page.click('[data-choice=merge]');
await toast('ادغام شد');
check('ادغام همان فایل، تراکنش تکراری نساخت', JSON.parse(await snapshot()).transactions.length === 19);

// ---- پاک‌کردن همه (با پشتیبان خودکار) ----
await go('#/backup');
await page.click('[data-action=ask-wipe]');
await page.fill('#confirmword', 'نه');
const noDl = page.waitForEvent('download', { timeout: 800 }).then(() => true).catch(() => false);
await page.click('[data-action=sheet-yes]');
check('کلمه‌ی تأیید اشتباه: چیزی پاک نشد و دانلودی نبود', (await snapshot()) === original && !(await noDl));
await page.click('[data-action=ask-wipe]');
await page.fill('#confirmword', 'حذف');
const [safety] = await Promise.all([page.waitForEvent('download'), page.click('[data-action=sheet-yes]')]);
check('پشتیبان خودکار قبل از پاک‌کردن دانلود شد', /safety/.test(safety.suggestedFilename()));
await page.waitForSelector('.empty');
check('همه‌ی اطلاعات پاک شد', JSON.parse(await snapshot()).transactions.length === 0);

// ---- بازیابی کامل از فایل ----
await go('#/backup');
await page.setInputFiles('#restorefile', backupPath);
await page.waitForSelector('.sheet');
await page.click('[data-choice=replace]');
await toast('بازیابی شد');
const restored = await snapshot();
check('بازیابی دقیقاً همان state اصلی را برگرداند', restored === original);
await page.reload();
await page.waitForSelector('#main');
check('بازیابی پس از reload هم ماند', (await snapshot().catch(() => '')) === original);

// ---- جایگزینی کامل وقتی داده‌ی فعلی هست: تأیید دوم و پشتیبان خودکار ----
await go('#/backup');
await page.setInputFiles('#restorefile', backupPath);
await page.waitForSelector('.sheet');
await page.click('[data-choice=replace]');
await page.waitForSelector('.sheet:has-text("جایگزینی کامل؟")');
const [safe2] = await Promise.all([page.waitForEvent('download'), page.click('[data-action=sheet-yes]')]);
check('جایگزینی کامل با تأیید دوم و پشتیبان خودکار', /safety/.test(safe2.suggestedFilename()));

check('بدون خطای جاوااسکریپت/کنسول', bag.errors.filter((e) => !e.includes('ERR_FAILED') && !e.includes('Failed to load resource')).length === 0, bag.errors.join('\n'));
await L.close();
