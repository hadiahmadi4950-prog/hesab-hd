import { launch, watch, check } from './lib.mjs';

const latin = (s) => s.replace(/[۰-۹]/g, (c) => String(c.charCodeAt(0) - 0x06f0)).replace(/[٬،,]/g, '');
const L = await launch();
const ctx = await L.context();
const page = await ctx.newPage();
const bag = watch(page);
await page.clock.install({ time: new Date('2026-10-12T08:00:00Z') }); // ۲۰ مهر ۱۴۰۵
const text = async () => latin(await page.textContent('#main'));

// نرخ لحظه‌ای ساختگی (شبکه‌ی واقعی در تست استفاده نمی‌شود)
let rateHits = 0;
await page.route('**/raw.githubusercontent.com/**', (route) => {
  rateHits += 1;
  route.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify({ meta: {}, data: [{ symbol: 'USD_IRR_FREE', currency: 'IRT', price: 250000, stale: false, timestamp: '2026-10-11T20:30:00.000Z' }] }) });
});

await page.goto(L.url);
await page.waitForSelector('#main');

// ۱) ساخت حساب‌ها
await page.click('text=افزودن اولین حساب');
await page.fill('#name', 'کیف پول');
await page.fill('#openingBalance', '۱٬۰۰۰٬۰۰۰');
check('پیش‌نمایش مبلغ با ارقام فارسی', (await page.textContent('[data-preview]')).includes('۱٬۰۰۰٬۰۰۰ تومان'));
await page.click('button[type=submit]');
await page.waitForSelector('.hero');
check('موجودی کل ۱٬۰۰۰٬۰۰۰ تومان', (await text()).includes('1000000تومان'.replace(/(\d)(?=(\d{3})+$)/g, '$1')) || (await text()).includes('1000000'));

await page.goto(L.url + '#/accounts/new');
await page.fill('#name', 'حساب دلاری');
await page.selectOption('#type', 'fx');
await page.selectOption('[name=currency]', 'USD');
await page.fill('#openingBalance', '100');
await page.click('button[type=submit]');
await page.waitForSelector('.hero');
check('حساب دلاری ساخته شد', (await text()).includes('100.00') || (await text()).includes('100٫00'));

// ۲) هزینه
await page.goto(L.url + '#/add');
await page.waitForSelector('[name=amount]');
await page.fill('#amount', '250000');
await page.click('label.catpick:has-text("خوراک")');
await page.fill('#note', 'ناهار <b>تست</b>');
await page.click('button[type=submit]');
await page.waitForSelector('.toast:has-text("تراکنش ثبت شد")');
check('هزینه ثبت شد (toast)', true);

// ۳) درآمد
await page.click('label.seg-item:has-text("درآمد")');
await page.fill('#amount', '5000000');
await page.click('label.catpick:has-text("حقوق")');
await page.click('button[type=submit]');
await page.waitForSelector('.toast:has-text("تراکنش ثبت شد")');

// ۴) انتقال دو ارزی بدون مبلغ مقصد باید خطا بدهد
await page.click('label.seg-item:has-text("انتقال")');
await page.selectOption('#toAccountId', { label: 'حساب دلاری (دلار)' });
await page.fill('#amount', '600000');
await page.click('button[type=submit]');
await page.waitForSelector('.err');
check('انتقال دو ارزی بدون مبلغ مقصد خطا می‌دهد', (await page.textContent('.err')).includes('مبلغ دریافتی'));
await page.fill('#toAmount', '2');
await page.click('button[type=submit]');
await page.waitForSelector('.toast:has-text("تراکنش ثبت شد")');

// ۵) موجودی‌ها
await page.goto(L.url + '#/accounts');
const accText = await text();
check('موجودی کیف پول = ۱۰٬۰۰۰٬۰۰۰−… درست', accText.includes('5150000'), accText);   // 1,000,000 − 250,000 + 5,000,000 − 600,000
check('موجودی دلاری = ۱۰۲٫۰۰', accText.includes('102.00') || accText.includes('102٫00'), accText);

// ۶) XSS: یادداشت escape شده باشد
await page.goto(L.url + '#/transactions');
check('یادداشت HTML به‌صورت متن نمایش داده شد و اجرا نشد', (await page.textContent('#main')).includes('<b>تست</b>') && (await page.locator('#main .item b').count()) === 0);

// ۷) پایداری پس از بارگذاری مجدد
await page.reload();
await page.waitForSelector('#main');
await page.goto(L.url + '#/accounts');
check('داده پس از reload مانده', (await text()).includes('5150000'));

// ۸) هزینه‌ها همه در انتظار نرخ‌اند (نرخ هنوز ندارد) ← یا در همین لحظه محاسبه شده‌اند چون آنلاین بودیم
await page.waitForTimeout(500);
await page.goto(L.url + '#/transactions');
const t1 = await text();
check('تراکنش‌ها نمایش داده می‌شوند', t1.includes('خوراک') && t1.includes('حقوق'));
check('نرخ آنلاین دریافت شد و دلار محاسبه شد', t1.includes('≈'), t1);
check('درخواست نرخ فقط از منبع مجاز', rateHits >= 1);

// ۹) آفلاین: ثبت بدون نرخ → در انتظار؛ سپس آنلاین → خودکار محاسبه
await ctx.setOffline(true);
await page.waitForSelector('.net');
check('نوار آفلاین دیده می‌شود', true);
await page.goto(L.url + '#/add');
await page.waitForSelector('[name=amount]');
await page.fill('#amount', '125000');
await page.click('label.catpick:has-text("حمل‌ونقل")');
await page.click('button[type=submit]');
await page.waitForSelector('.toast:has-text("تراکنش ثبت شد")');
await page.goto(L.url + '#/transactions');
check('تراکنش آفلاین ثبت شد و در انتظار است', (await page.textContent('#main')).includes('در انتظار نرخ دلار'));
const hitsBefore = rateHits;
await page.route('**/raw.githubusercontent.com/**', (route) => {
  rateHits += 1;
  route.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify({ meta: {}, data: [{ symbol: 'USD_IRR_FREE', currency: 'IRT', price: 260000, stale: false, timestamp: '2026-10-11T20:30:00.000Z' }] }) });
});
await page.clock.fastForward(40 * 60 * 1000); // نرخ قبلی دیگر «لحظه‌ای» نیست
await ctx.setOffline(false);
await page.waitForFunction(() => !document.querySelector('.tag.pend'), null, { timeout: 8000 }).catch(() => {});
check('پس از اتصال دوباره، نرخ جدید دریافت و دلار محاسبه شد', !(await page.textContent('#main')).includes('در انتظار نرخ دلار') && rateHits > hitsBefore, `hits=${rateHits}`);

await page.screenshot({ path: '/tmp/claude-0/shot-list.png' });
await page.goto(L.url + '#/home');
await page.waitForSelector('.hero');
await page.screenshot({ path: '/tmp/claude-0/shot-home.png', fullPage: true });
check('بدون خطای جاوااسکریپت/کنسول', bag.errors.length === 0, bag.errors.join('\n'));
await L.close();
