import { launch } from './lib.mjs';
const L = await launch();
const ctx = await L.context({ colorScheme: process.argv[2] === 'dark' ? 'dark' : 'light' });
const page = await ctx.newPage();
await page.clock.install({ time: new Date('2026-10-12T08:00:00Z') });
await page.route('**/raw.githubusercontent.com/**', (r) => r.abort());
await page.goto(L.url);
await page.waitForSelector('#main');
await page.evaluate(async () => {
  const L = await import('./src/core/ledger.js');
  const ctx = { now: () => new Date().toISOString(), id: () => crypto.randomUUID() };
  const c = window.__hesab; let a, b;
  await c.commit((s) => { const r = L.addAccount(s, { name: 'بانک ملی', type: 'bank', currency: 'IRT', openingBalance: 20_000_000 }, ctx); a = r.account.id; return r.state; });
  await c.commit((s) => { const r = L.addAccount(s, { name: 'کیف پول', type: 'cash', currency: 'IRT', openingBalance: 500_000 }, ctx); return r.state; });
  await c.commit((s) => L.addAccount(s, { name: 'دلاری', type: 'fx', currency: 'USD', openingBalance: 50000 }, ctx).state);
  const add = (i) => c.commit((s) => L.addTransaction(s, i, ctx, { allowDuplicate: true }).state);
  const cats = ['food', 'transport', 'bills', 'fun', 'rent'];
  for (const [m, d] of [['03', '05'], ['04', '10'], ['05', '12'], ['06', '14'], ['07', '02'], ['07', '15'], ['07', '19']]) {
    await add({ type: 'income', accountId: a, categoryId: 'cat-income-salary', amount: 18_000_000, date: `1405-${m}-${d}`, note: 'حقوق' });
    for (const [i, k] of cats.entries()) await add({ type: 'expense', accountId: a, categoryId: `cat-expense-${k}`, amount: 400_000 + i * 700_000 + Number(m) * 30_000, date: `1405-${m}-${String(Number(d) + i).padStart(2, '0')}`, note: i === 0 ? 'ناهار با دوستان' : '' });
  }
  await c.commit((s) => L.setBudget(s, { categoryId: null, period: 'monthly', limit: 6_000_000, effectiveFrom: '1405-07-01' }, ctx).state);
  await c.commit((s) => L.addGoal(s, { name: 'خرید لپ‌تاپ', currency: 'IRT', targetAmount: 50_000_000 }, ctx).state);
  await c.commit((s) => L.addDebt(s, { direction: 'owe', person: 'رضا', principal: 2_000_000, currency: 'IRT', date: '1405-07-01', dueDate: '1405-07-10' }, ctx).state);
});
const suffix = process.argv[2] === 'dark' ? '-dark' : '';
for (const [name, hash] of [['home', '#/home'], ['add', '#/add'], ['reports', '#/reports'], ['list', '#/transactions'], ['more', '#/more'], ['budgets', '#/budgets'], ['debts', '#/debts']]) {
  await page.evaluate((h) => { location.hash = h; }, hash);
  await page.waitForTimeout(250);
  await page.screenshot({ path: `/tmp/claude-0/s-${name}${suffix}.png`, fullPage: name === 'reports' || name === 'home' });
}
await L.close();
