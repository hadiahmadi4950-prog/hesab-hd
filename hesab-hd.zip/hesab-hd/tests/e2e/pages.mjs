import { launch, watch, check } from './lib.mjs';

const latin = (s) => s.replace(/[۰-۹]/g, (c) => String(c.charCodeAt(0) - 0x06f0)).replace(/[٬،,]/g, '');
const L = await launch();
const ctx = await L.context();
const page = await ctx.newPage();
const bag = watch(page);
await page.clock.install({ time: new Date('2026-10-12T08:00:00Z') });
await page.route('**/raw.githubusercontent.com/**', (r) => r.abort());
const main = async () => latin(await page.textContent('#main'));
const go = async (h) => { await page.evaluate((x) => { location.hash = x; }, h); await page.waitForTimeout(120); };
const toast = (t) => page.waitForSelector(`.toast:has-text("${t}")`);

await page.goto(L.url);
await page.waitForSelector('#main');
// بذر: یک حساب با ۱۰ میلیون
await page.evaluate(async () => {
  const L = await import('./src/core/ledger.js');
  await window.__hesab.commit((s) => L.addAccount(s, { name: 'بانک', type: 'bank', currency: 'IRT', openingBalance: 10_000_000 }).state);
});

// ---- دسته‌ها ----
await go('#/categories/new?kind=expense');
await page.fill('#name', 'قهوه');
await page.click('button.emoji[data-v="☕"]');
await page.click('label.swatch:nth-child(3)');
await page.click('button[type=submit]');
await toast('دسته ساخته شد');
check('دسته‌ی جدید در فهرست', (await main()).includes('قهوه'));
check('نام تکراری رد می‌شود', await (async () => { await go('#/categories/new?kind=expense'); await page.fill('#name', 'قهوه'); await page.click('button[type=submit]'); await page.waitForSelector('.err'); return (await page.textContent('.err')).includes('وجود دارد'); })());
await go('#/add');
check('دسته‌ی جدید در فرم ثبت هست', (await main()).includes('قهوه'));
await page.fill('#amount', '30000');
await page.click('label.catpick:has-text("قهوه")');
await page.click('button[type=submit]');
await toast('تراکنش ثبت شد');
// ویرایش و حذف با انتقال تراکنش‌ها
await go('#/categories');
await page.click('a:has-text("قهوه")');
await page.fill('#name', 'کافه');
await page.click('button[type=submit]');
await toast('دسته ذخیره شد');
await go('#/categories');
await page.click('a:has-text("کافه")');
await page.click('[data-action=ask-delete-category]');
await page.waitForSelector('#reassign');
await page.selectOption('#reassign', 'cat-expense-food');
await page.click('[data-action=sheet-yes]');
await toast('دسته حذف شد');
await go('#/transactions');
check('تراکنش به دسته‌ی جایگزین منتقل شد', (await main()).includes('خوراک') && !(await main()).includes('کافه'));

// ---- بودجه ----
await go('#/budgets/new');
await page.fill('#limit', '1000000');
await page.selectOption('#warn', '80');
await page.click('button[type=submit]');
await toast('بودجه ذخیره شد');
check('بودجه‌ی کل ساخته شد', (await main()).includes('کل هزینه‌ها'));
await go('#/add');
await page.fill('#amount', '800000');
await page.click('label.catpick:has-text("قبوض")');
await page.click('button[type=submit]');
await toast('تراکنش ثبت شد');
await go('#/budgets');
check('هشدار نزدیک سقف (۸۳٪)', (await main()).includes('نزدیک سقف'), await main());
await go('#/add');
await page.fill('#amount', '300000');
await page.click('label.catpick:has-text("قبوض")');
await page.click('button[type=submit]');
await toast('تراکنش ثبت شد');
await go('#/budgets');
check('گذشتن از سقف', (await main()).includes('از سقف گذشته'));
await go('#/home');
check('بودجه در خانه نمایش داده می‌شود', (await main()).includes('بیشتر از سقف'));

// ---- هدف ----
await go('#/goals/new');
await page.fill('#name', 'لپ‌تاپ');
await page.fill('#targetAmount', '10000000');
await page.click('button[type=submit]');
await page.waitForSelector('.hero');
await page.fill('#amount', '2500000');
await page.click('button:has-text("ثبت")');
await toast('ثبت شد');
check('پیشرفت ۲۵٪', (await main()).includes('25٪') || (await main()).includes('25'));
await page.click('label.seg-item:has-text("برداشت")');
await page.fill('#amount', '9000000');
await page.click('button:has-text("ثبت")');
await page.waitForSelector('.err');
check('برداشت بیشتر از پس‌انداز رد شد', (await page.textContent('.err')).includes('بیشتر'));
await go('#/accounts');
check('پس‌انداز هدف موجودی حساب را عوض نکرد', (await main()).includes('8870000')); // ۱۰٬۰۰۰٬۰۰۰ − ۳۰٬۰۰۰ − ۸۰۰٬۰۰۰ − ۳۰۰٬۰۰۰ = ۸٬۸۷۰٬۰۰۰

// ---- بدهی ----
await go('#/debts/new?dir=owe');
await page.fill('#person', 'علی');
await page.fill('#principal', '1000000');
await page.selectOption('#accountId', { index: 1 });
await page.click('button[type=submit]');
await page.waitForSelector('.hero');
check('بدهی ثبت شد و مانده ۱٬۰۰۰٬۰۰۰', (await main()).includes('1000000'));
await go('#/accounts');
check('بدهی به حساب اضافه شد (۹٬۸۷۰٬۰۰۰)', (await main()).includes('9870000'));
const debtHash = await page.evaluate(() => window.__hesab.store.state.debts[0].id);
await go(`#/debts/${debtHash}`);
await page.fill('#amount', '400000');
await page.click('button:has-text("ثبت پرداخت")');
await toast('پرداخت ثبت شد');
check('مانده ۶۰۰٬۰۰۰', (await main()).includes('600000'));
await page.fill('#amount', '700000');
await page.click('button:has-text("ثبت پرداخت")');
await page.waitForSelector('.err');
check('پرداخت بیشتر از مانده رد شد', (await page.textContent('.err')).includes('بیشتر'));
await page.fill('#amount', '600000');
await page.click('button:has-text("ثبت پرداخت")');
await toast('پرداخت ثبت شد');
await page.waitForSelector('#main:has-text("تسویه شد")', { timeout: 3000 }).catch(() => {});
check('تسویه شد', (await main()).includes('تسویه شد'));
await go('#/home');
const homeText = await main();
check('پرداخت بدهی جزو هزینه‌ی ماه نشد (۱٬۱۳۰٬۰۰۰)', homeText.includes('1130000'), homeText);
await go('#/debts');
await page.click('a.item:has-text("علی")');
await page.click('[data-action=ask-delete-debt]');
await page.click('[data-action=sheet-yes]');
await toast('حذف شد');
await go('#/accounts');
check('حذف بدهی با پرداخت‌ها، موجودی را درست برگرداند (۸٬۸۷۰٬۰۰۰)', (await main()).includes('8870000'));

// ---- تغییر پس‌زمینه‌ای هنگام تایپ، فرم را پاک نمی‌کند ----
await go('#/add');
await page.fill('#amount', '777');
await page.fill('#note', 'نیمه‌کاره');
await page.click('label.catpick:has-text("قبوض")');
await page.focus('#note');
await page.evaluate(async () => { await window.__hesab.commit((s) => ({ ...s })); });
await page.waitForTimeout(150);
check('مقدار مبلغ بعد از تغییر پس‌زمینه‌ای مانده', (await page.inputValue('#amount')) === '777');
check('یادداشت و دسته‌ی انتخاب‌شده مانده', (await page.inputValue('#note')) === 'نیمه‌کاره' && (await page.isChecked('label.catpick:has-text("قبوض") input')));
check('فوکوس روی یادداشت مانده', (await page.evaluate(() => document.activeElement?.id)) === 'note');
await page.evaluate(() => window.dispatchEvent(new Event('offline')));
await page.waitForTimeout(150);
check('تغییر وضعیت اینترنت هم فرم را پاک نمی‌کند', (await page.inputValue('#amount')) === '777');

// ---- دکمه‌ی قرمز خروج ----
await go('#/home');
await page.evaluate(() => { window.__closeCalls = 0; window.close = () => { window.__closeCalls += 1; }; });
const accBefore = await page.evaluate(() => window.__hesab.store.state.accounts.length);
check('دکمه‌ی خروج در سربرگ هست', (await page.locator('.appbar .exitbtn').count()) === 1);
await page.click('.appbar .exitbtn');
await page.waitForSelector('.lock:has-text("اطلاعات شما ذخیره است")');
check('خروج: close فراخوانی شد و پیام امن نشان داده شد', (await page.evaluate(() => window.__closeCalls)) === 1);
check('خروج داده را پاک نکرد', (await page.evaluate(() => window.__hesab.store.state.accounts.length)) === accBefore && accBefore >= 1);
await page.click('[data-action="exit-dismiss"]');
await page.waitForSelector('#main');
check('بازگشت از صفحه‌ی خروج به برنامه', (await page.locator('.lock').count()) === 0);
await go('#/settings');
check('دکمه‌ی خروج در صفحه‌های دیگر هم هست', (await page.locator('.appbar .exitbtn').count()) === 1);

check('بدون خطای جاوااسکریپت/کنسول', bag.errors.filter((e) => !e.includes('ERR_FAILED') && !e.includes('Failed to load resource')).length === 0, bag.errors.join('\n'));
await L.close();
