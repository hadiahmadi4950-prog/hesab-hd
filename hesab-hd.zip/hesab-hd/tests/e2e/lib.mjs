// ابزار مشترک تست‌های سرتاسری (مرورگر واقعی Chromium از طریق Playwright)
import { startServer } from '../../scripts/serve.mjs';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

const PW = process.env.PLAYWRIGHT_PATH ?? '/opt/npm-tools/node_modules/playwright/index.mjs';
const root = join(fileURLToPath(import.meta.url), '..', '..', '..');

export async function launch({ build = true, port = 0 } = {}) {
  if (build) execFileSync('node', ['scripts/build.mjs'], { cwd: root, stdio: 'pipe' });
  const { chromium } = await import(PW);
  const server = await startServer(port);
  const url = `http://127.0.0.1:${server.address().port}/`;
  const browser = await chromium.launch();
  return {
    url,
    browser,
    server,
    async context(opts = {}) {
      const ctx = await browser.newContext({ locale: 'fa-IR', timezoneId: 'Asia/Tehran', viewport: { width: 390, height: 800 }, serviceWorkers: 'allow', ...opts });
      return ctx;
    },
    async close() {
      await browser.close();
      await new Promise((r) => server.close(r));
    },
  };
}

export function watch(page, bag = { errors: [], logs: [] }) {
  page.on('pageerror', (e) => bag.errors.push(`pageerror: ${e.message}`));
  page.on('console', (m) => {
    if (m.type() === 'error') bag.errors.push(`console: ${m.text()}`);
    bag.logs.push(`${m.type()}: ${m.text()}`);
  });
  return bag;
}

export function check(name, cond, extra = '') {
  const ok = Boolean(cond);
  console.log(`${ok ? '✓' : '✗'} ${name}${ok ? '' : ` ${extra}`}`);
  if (!ok) process.exitCode = 1;
  return ok;
}
