import { launch, watch, check } from './lib.mjs';
import { writeFileSync } from 'node:fs';

const latin = (s) => s.replace(/[۰-۹]/g, (c) => String(c.charCodeAt(0) - 0x06f0)).replace(/[٬،,]/g, '');
const TMP = '/tmp/claude-0';
const L = await launch();
const ctx = await L.context({ acceptDownloads: true });
const page = await ctx.newPage();
const bag = watch(page);
await page.clock.install({ time: new Date('2026-10-12T08:00:00Z') });
await page.route('**/raw.githubusercontent.com/**', (r) => r.abort());
const main = async () => latin(await page.textContent('#main'));
const go = async (h) => { await page.evaluate((x) => { location.hash = x; }, h); await page.waitForTimeout(150); };
const toast = (t) => page.waitForSelector(`.toast:has-text("${t}")`);
const seed = (n) => page.evaluate(async (n) => {
  const L = await import('./src/core/ledger.js');
  const ctx = { now: () => new Date().toISOString(), id: () => crypto.randomUUID() };
  const c = window.__hesab;
  if (!c.store.state.accounts.length) await c.commit((s) => L.addAccount(s, { name: 'کیف', type: 'cash', currency: 'IRT', openingBalance: 1_000_000 }, ctx).state);
  for (let i = 0; i < n; i += 1) await c.commit((s) => L.addTransaction(s, { type: 'expense', accountId: s.accounts[0].id, categoryId: 'cat-expense-food', amount: 1000 + i, date: '1405-07-20', note: `n${i}` }, ctx, { allowDuplicate: true }).state);
}, n);
const idbPut = (key, value) => page.evaluate(({ key, value }) => new Promise((res, rej) => {
  const r = indexedDB.open('hesab-hd', 1);
  r.onsuccess = () => { const tx = r.result.transaction('kv', 'readwrite'); tx.objectStore('kv').put(value, key); tx.oncomplete = () => { r.result.close(); res(); }; tx.onerror = () => rej(tx.error); };
}), { key, value });
const idbGet = (key) => page.evaluate((key) => new Promise((res) => {
  const r = indexedDB.open('hesab-hd', 1);
  r.onsuccess = () => { const q = r.result.transaction('kv').objectStore('kv').get(key); q.onsuccess = () => { r.result.close(); res(q.result ?? null); }; };
}), key);

await page.goto(L.url);
await page.waitForSelector('#main');

// ================= داده‌ی خراب =================
await seed(3);
await page.waitForTimeout(300);
await idbPut('state', { version: 1, accounts: 'خراب' }); // فقط نسخه‌ی اصلی خراب؛ previous سالم است
await page.reload();
await page.waitForSelector('#main');
check('نسخه‌ی اصلی خراب → بازیابی از نسخه‌ی قبلی با اعلام به کاربر', (await page.textContent('#main')).includes('از آخرین نسخه‌ی سالم قبلی بازیابی شد'));
check('داده‌ی بازیابی‌شده در دسترس است', await page.evaluate(() => window.__hesab.store.state.accounts.length === 1));

// هر دو خراب
await idbPut('state', { version: 1, accounts: 'خراب' });
await idbPut('previous', 'اصلاً json ساختاری نیست');
await page.reload();
await page.waitForSelector('#main');
check('هر دو خراب → صفحه‌ی رفع خرابی', (await page.textContent('#main')).includes('خراب است') && (await page.locator('.tabbar').count()) === 0);
check('چیزی بازنویسی نشد', JSON.stringify(await idbGet('state')) === JSON.stringify({ version: 1, accounts: 'خراب' }));
const [corruptDl] = await Promise.all([page.waitForEvent('download'), page.click('[data-action=download-corrupt]')]);
check('دانلود نسخه‌ی خراب', corruptDl.suggestedFilename().includes('corrupt'));
// تلاش برای ثبت در حالت خراب باید مسدود باشد
const blocked = await page.evaluate(async () => { try { await window.__hesab.commit((s) => s); return false; } catch (e) { return e.code; } });
check('ثبت در حالت خراب مسدود است (CORRUPT)', blocked === 'CORRUPT');
// بازیابی از فایل نامعتبر رد، و از فایل سالم قبول
writeFileSync(`${TMP}/bad.json`, '{}');
await page.setInputFiles('#restorefile2', `${TMP}/bad.json`);
await page.waitForSelector('#import-result .notice.error');
check('فایل نامعتبر در حالت خراب رد شد', true);
await page.evaluate(async () => {}); // بدون عملیات
// ساخت یک پشتیبان معتبر با یک صفحه‌ی دیگر روی همان سرور (پایگاه‌داده‌ی جدا)
const ctx2 = await L.context({ acceptDownloads: true });
const p2 = await ctx2.newPage();
await p2.goto(L.url);
await p2.waitForSelector('#main');
await p2.evaluate(async () => {
  const L = await import('./src/core/ledger.js');
  const ctx = { now: () => new Date().toISOString(), id: () => crypto.randomUUID() };
  await window.__hesab.commit((s) => L.addAccount(s, { name: 'بازیابی‌شده', type: 'cash', currency: 'IRT', openingBalance: 777_000 }, ctx).state);
});
await p2.goto(L.url + '#/backup');
const [bd] = await Promise.all([p2.waitForEvent('download'), p2.click('[data-action=download-backup]')]);
await bd.saveAs(`${TMP}/good-backup.json`);
await ctx2.close();
await page.setInputFiles('#restorefile2', `${TMP}/good-backup.json`);
await page.click('[data-action=sheet-yes]');
await toast('بازیابی شد');
await page.waitForSelector('.hero');
check('بازیابی از فایل در حالت خراب', (await main()).includes('777000'));
await page.reload();
await page.waitForSelector('.hero');
check('بعد از reload هم داده‌ی بازیابی‌شده هست', (await main()).includes('777000'));
// شروع از نو
await idbPut('state', 'خراب'); await idbPut('previous', 'خراب');
await page.reload();
await page.waitForSelector('[data-action=corrupt-fresh]');
await page.click('[data-action=corrupt-fresh]');
await page.click('[data-action=sheet-yes]');
await page.waitForSelector('.empty');
check('شروع از نو', await page.evaluate(() => window.__hesab.store.state.accounts.length === 0));

// ================= قفل PIN =================
await seed(1);
await go('#/settings');
await page.click('[data-action=open-pin-form][data-mode=set]');
await page.fill('#newpin', '1234'); await page.fill('#newpin2', '1234');
await page.click('.sheet button[type=submit]');
check('PIN ساده رد شد', (await page.textContent('#pinerr')).includes('ساده'));
await page.fill('#newpin', '4827'); await page.fill('#newpin2', '4828');
await page.click('.sheet button[type=submit]');
check('تکرار نامطابق رد شد', (await page.textContent('#pinerr')).includes('یکی نیست'));
await page.fill('#newpin', '۴۸۲۷'); await page.fill('#newpin2', '4827');
await page.click('.sheet button[type=submit]');
await toast('قفل PIN فعال شد');
const stored = await page.evaluate(() => localStorage.getItem('hesab-hd:prefs'));
check('PIN خام ذخیره نشده، فقط هش', !stored.includes('4827') && stored.includes('"hash"'));
await page.reload();
await page.waitForSelector('.lock');
check('پس از reload صفحه‌ی قفل', (await page.locator('#main').count()) === 0);
await page.fill('#pin', '0000');
await page.press('#pin', 'Enter');
await page.waitForSelector('#lockmsg:has-text("نادرست")');
check('PIN غلط رد شد', true);
for (let i = 0; i < 4; i += 1) { await page.fill('#pin', '0000'); await page.press('#pin', 'Enter'); await page.waitForTimeout(200); }
await page.waitForSelector('#lockmsg:has-text("صبر کنید")');
check('پس از ۵ تلاش ناموفق قفل موقت', await page.locator('#pin:disabled').count() === 1);
await page.clock.fastForward(31_000);
await page.waitForSelector('#pin:not([disabled])');
await page.fill('#pin', '4827');
await page.press('#pin', 'Enter');
await page.waitForSelector('#main');
check('PIN درست باز می‌کند (ارقام فارسی هم)', (await page.locator('.lock').count()) === 0);
// قفل خودکار پس از پنهان‌شدن
await page.evaluate(() => { Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'hidden' }); document.dispatchEvent(new Event('visibilitychange')); });
await page.clock.fastForward(90_000);
await page.evaluate(() => { Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'visible' }); document.dispatchEvent(new Event('visibilitychange')); });
await page.waitForSelector('.lock');
check('قفل خودکار پس از پنهان‌ماندن برنامه', true);
await page.fill('#pin', '۴۸۲۷'); await page.press('#pin', 'Enter');
await page.waitForSelector('#main');
// برداشتن قفل
await go('#/settings');
await page.click('[data-action=open-pin-form][data-mode=remove]');
await page.fill('#oldpin', '9999');
await page.click('.sheet button[type=submit]');
await page.waitForFunction(() => document.getElementById('pinerr')?.textContent.includes('درست نیست'));
check('برداشتن قفل با PIN غلط ممکن نیست', true);
await page.fill('#oldpin', '4827');
await page.click('.sheet button[type=submit]');
await toast('قفل برداشته شد');
await page.reload();
await page.waitForSelector('#main');
check('پس از برداشتن قفل، ورود مستقیم', (await page.locator('.lock').count()) === 0);

// ================= ظاهر و کنتراست =================
await go('#/settings');
await page.click('label.seg-item:has-text("تاریک")');
check('تم تاریک اعمال شد', (await page.getAttribute('html', 'data-theme')) === 'dark');
const lum = (hex) => { const c = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
const ratio = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };
const vars = async () => page.evaluate(() => { const cs = getComputedStyle(document.documentElement); const g = (n) => cs.getPropertyValue(n).trim(); return Object.fromEntries(['--bg', '--surface', '--text', '--muted', '--primary', '--primary-ink', '--pos', '--neg', '--warn', '--warn-soft', '--neg-soft'].map((n) => [n, g(n)])); });
const pairs = (v) => [['متن/پس‌زمینه', v['--text'], v['--bg']], ['متن کم‌رنگ/کارت', v['--muted'], v['--surface']], ['دکمه‌ی اصلی', v['--primary-ink'], v['--primary']], ['رنگ اصلی/کارت', v['--primary'], v['--surface']], ['درآمد/کارت', v['--pos'], v['--surface']], ['هزینه/کارت', v['--neg'], v['--surface']], ['هشدار', v['--warn'], v['--warn-soft']], ['خطا', v['--neg'], v['--neg-soft']]];
for (const theme of ['dark', 'light']) {
  await page.click(`label.seg-item:has-text("${theme === 'dark' ? 'تاریک' : 'روشن'}")`);
  const v = await vars();
  for (const [n, a, b] of pairs(v)) check(`کنتراست ${theme} – ${n} ≥ 4.5 (${ratio(a, b).toFixed(1)})`, ratio(a, b) >= 4.5);
}
await page.click('label.seg-item:has-text("خودکار")');
await page.emulateMedia({ colorScheme: 'dark' });
check('تم خودکار از حالت تاریک سیستم پیروی می‌کند', (await page.evaluate(() => getComputedStyle(document.body).backgroundColor)) === 'rgb(12, 21, 22)');
await page.emulateMedia({ colorScheme: 'light' });
check('تم خودکار در حالت روشن', (await page.evaluate(() => getComputedStyle(document.body).backgroundColor)) === 'rgb(244, 247, 247)');

// ================= آفلاین واقعی با Service Worker =================
await page.evaluate(() => navigator.serviceWorker.ready);
await page.reload();
await page.waitForFunction(() => navigator.serviceWorker.controller);
const cacheInfo = await page.evaluate(async () => { const names = await caches.keys(); const c = await caches.open(names[0]); const keys = await c.keys(); return { names, count: keys.length, hasFont: keys.some((k) => k.url.endsWith('Vazirmatn-var.woff2')), hasCore: keys.some((k) => k.url.endsWith('src/core/ledger.js')), hasIcon: keys.some((k) => k.url.endsWith('maskable-512.png')) }; });
check('همه‌ی فایل‌ها پیش‌کش شدند (فونت، هسته، آیکن)', cacheInfo.count > 30 && cacheInfo.hasFont && cacheInfo.hasCore && cacheInfo.hasIcon, JSON.stringify(cacheInfo));
await go('#/home');
await ctx.setOffline(true);
await page.reload();
await page.waitForSelector('#main');
check('بارگذاری مجدد کاملاً آفلاین کار می‌کند', (await page.title()).includes('حساب HD') && (await page.locator('.net').count()) === 1);
await go('#/add');
await page.waitForSelector('[name=amount]');
await page.fill('#amount', '4321');
await page.click('label.catpick:has-text("خوراک")');
await page.click('button[type=submit]');
await toast('تراکنش ثبت شد');
await page.reload();
await page.waitForSelector('#main');
check('تراکنش ثبت‌شده‌ی آفلاین پس از reload آفلاین ماند', await page.evaluate(() => window.__hesab.store.state.transactions.some((t) => t.amount === 4321)));
const fontOk = await page.evaluate(async () => { await document.fonts.ready; return document.fonts.check('16px Vazirmatn'); });
check('فونت وزیرمتن محلی بارگذاری شد (آفلاین)', fontOk);
await ctx.setOffline(false);
const manifest = await (await ctx.request.get(L.url + 'manifest.webmanifest')).json();
check('مانیفست PWA کامل', manifest.display === 'standalone' && manifest.dir === 'rtl' && manifest.lang === 'fa' && manifest.icons.some((i) => i.purpose === 'maskable'));
for (const i of manifest.icons) check(`آیکن ${i.src} در دسترس`, (await ctx.request.get(L.url + i.src)).ok());

check('بدون خطای جاوااسکریپت/کنسول', bag.errors.filter((e) => !/ERR_FAILED|Failed to load resource|ERR_INTERNET_DISCONNECTED/.test(e)).length === 0, bag.errors.join('\n'));
await L.close();
