import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as FX from '../src/core/fx.js';
import * as L from '../src/core/ledger.js';
import * as R from '../src/core/reports.js';
import { Book } from './helpers.js';

const FOOD = 'cat-expense-food';
const SALARY = 'cat-income-salary';
const T0 = '2026-10-11T10:00:00.000Z';
const T1 = '2026-10-11T10:10:00.000Z';
const adapter = { id: 'mock', name: 'منبع آزمایشی', market: 'بازار آزاد', url: 'https://example.test/rate', parse: (j) => ({ value: j.price }) };
const okFetch = (price) => async () => ({ ok: true, json: async () => ({ price }) });
const offlineFetch = async () => {
  throw new TypeError('fetch failed');
};

function bookWithPending() {
  const b = new Book();
  const cash = b.account('نقد', { opening: 1_000_000 });
  const t1 = b.tx({ type: 'expense', amount: 200_000, date: '1405-07-01', accountId: cash.id, categoryId: FOOD, note: 'الف' });
  const t2 = b.tx({ type: 'expense', amount: 500, date: '1405-07-19', accountId: cash.id, categoryId: FOOD, note: 'ب' });
  const t3 = b.tx({ type: 'income', amount: 3_000_000, date: '1405-07-19', accountId: cash.id, categoryId: SALARY });
  return { b, cash, t1, t2, t3 };
}

const amounts = (state) => state.transactions.map((t) => [t.id, t.amount, t.currency]);

test('ثبت تراکنش اصلاً به اینترنت یا نرخ وابسته نیست', () => {
  const realFetch = globalThis.fetch;
  let calls = 0;
  globalThis.fetch = () => {
    calls += 1;
    throw new Error('اینترنت قطع است');
  };
  try {
    const { b } = bookWithPending();
    assert.equal(b.state.transactions.length, 3);
    assert.equal(calls, 0);
    assert.ok(b.state.transactions.every((t) => t.usd.status === 'pending'));
    assert.equal(FX.pendingTransactions(b.state).length, 3);
  } finally {
    globalThis.fetch = realFetch;
  }
});

test('اعتبارسنجی نرخ و تازگی', () => {
  const ok = { value: 120_000, at: T0, source: 'x', manual: false };
  assert.equal(FX.validateRateInfo(ok).ok, true);
  for (const bad of [null, undefined, {}, { ...ok, value: 0 }, { ...ok, value: 1.5 }, { ...ok, value: '120000' }, { ...ok, value: NaN }, { ...ok, at: 'دیروز' }, { ...ok, at: undefined }, { ...ok, source: '' }, { ...ok, source: '  ' }, { ...ok, manual: 'no' }]) {
    assert.equal(FX.validateRateInfo(bad).ok, false, JSON.stringify(bad));
  }
  const t0 = Date.parse(T0);
  assert.equal(FX.isFresh(ok, t0), true);
  assert.equal(FX.isFresh(ok, t0 + FX.DEFAULT_MAX_AGE_MS), true); // دقیقاً روی مرز
  assert.equal(FX.isFresh(ok, t0 + FX.DEFAULT_MAX_AGE_MS + 1), false); // قدیمی
  assert.equal(FX.isFresh(ok, t0 - 60_000), true); // اختلاف جزئی ساعت
  assert.equal(FX.isFresh(ok, t0 - FX.CLOCK_SKEW_MS - 1), false); // نرخ «از آینده»
  assert.equal(FX.isFresh({ ...ok, value: 0 }, t0), false);
});

test('computeUsd: فقط فیلد usd عوض می‌شود و مبلغ اصلی دست‌نخورده می‌ماند', () => {
  const { b, t1 } = bookWithPending();
  const rate = { value: 100_000, at: T0, source: 'منبع آزمایشی', manual: false };
  const done = FX.computeUsd(t1, rate, T1);
  assert.equal(done.amount, 200_000);
  assert.equal(done.currency, 'IRT');
  assert.equal(done.date, t1.date);
  assert.equal(done.updatedAt, t1.updatedAt); // محاسبه‌ی دلاری «ویرایش کاربر» نیست
  assert.deepEqual({ ...done.usd, history: undefined }, { status: 'done', cents: 200, rate: 100_000, rateAt: T0, source: 'منبع آزمایشی', manual: false, computedAt: T1, history: undefined });
  assert.deepEqual(t1.usd, { status: 'pending' }); // ورودی تغییر نکرده
  // دوباره صدا زدن بدون force چیزی عوض نمی‌کند
  assert.equal(FX.computeUsd(done, { ...rate, value: 200_000 }, T1), done);
  // نرخ نامعتبر خطا می‌دهد و عدد اشتباه نمی‌سازد
  assert.throws(() => FX.computeUsd(t1, { ...rate, value: 0 }, T1), { code: 'BAD_RATE' });
  assert.throws(() => FX.computeUsd(t1, null, T1), { code: 'BAD_RATE' });
  // تراکنش دلاری نیازی به محاسبه ندارد
  const usdTx = { ...t1, currency: 'USD', usd: { status: 'not_applicable' } };
  assert.equal(FX.computeUsd(usdTx, rate, T1), usdTx);
  assert.ok(b);
});

test('بدون نرخ یا با نرخ قدیمی: همه در صف انتظار می‌مانند و چیزی ساختگی ساخته نمی‌شود', () => {
  const { b } = bookWithPending();
  const before = b.state;
  let r = FX.processPending(b.state, null, T1);
  assert.equal(r.updated, 0);
  assert.equal(r.reason, 'no_rate');
  assert.equal(r.state, before);
  r = FX.processPending(b.state, { value: 0, at: T0, source: 'x', manual: false }, T1);
  assert.equal(r.reason, 'no_rate');
  // نرخ خودکار قدیمی‌تر از ۳۰ دقیقه، «لحظه‌ای» محسوب نمی‌شود
  const stale = { value: 100_000, at: '2026-10-11T08:00:00.000Z', source: 'منبع آزمایشی', manual: false };
  r = FX.processPending(b.state, stale, T1);
  assert.equal(r.reason, 'stale_rate');
  assert.equal(r.updated, 0);
  assert.equal(r.state, before);
  assert.equal(FX.pendingTransactions(r.state).length, 3);
  assert.ok(r.state.transactions.every((t) => t.usd.status === 'pending' && t.usd.cents === undefined));
});

test('محاسبه‌ی معوق‌ها با نرخ تازه: فقط موارد در انتظار، با ثبت نرخ، زمان و منبع', () => {
  const { b } = bookWithPending();
  const rate = { value: 100_000, at: T0, source: 'منبع آزمایشی', manual: false };
  const r = FX.processPending(b.state, rate, T1);
  assert.equal(r.reason, 'ok');
  assert.equal(r.updated, 3);
  assert.deepEqual(amounts(r.state), amounts(b.state)); // مبلغ اصلی هیچ‌کدام عوض نشد
  const byId = Object.fromEntries(r.state.transactions.map((t) => [t.note || t.id, t]));
  assert.equal(byId['الف'].usd.cents, 200);
  assert.equal(byId['ب'].usd.cents, 1); // ۵۰۰ تومان = ۰٫۵ سنت → ۱ سنت (گرد کردن نیم به دورتر از صفر)
  assert.equal(r.state.transactions[2].usd.cents, 3000);
  for (const t of r.state.transactions) {
    assert.equal(t.usd.status, 'done');
    assert.equal(t.usd.rate, 100_000);
    assert.equal(t.usd.rateAt, T0);
    assert.equal(t.usd.source, 'منبع آزمایشی');
    assert.equal(t.usd.manual, false);
    assert.equal(t.usd.computedAt, T1);
  }
  assert.equal(FX.pendingTransactions(r.state).length, 0);
  // اجرای دوباره چیزی را عوض نمی‌کند (محاسبه‌ی انجام‌شده با نرخ جدید بازنویسی نمی‌شود)
  const again = FX.processPending(r.state, { ...rate, value: 150_000, at: T1 }, T1);
  assert.equal(again.reason, 'nothing_pending');
  assert.equal(again.state, r.state);
});

test('سیاست: نرخ زمان محاسبه (نه تاریخ تراکنش) ثبت می‌شود', () => {
  const { b, t1 } = bookWithPending();
  assert.equal(t1.date, '1405-07-01'); // تراکنش ۱۸ روز قبل ثبت شده
  const rate = { value: 100_000, at: T0, source: 'منبع آزمایشی', manual: false };
  const r = FX.processPending(b.state, rate, T1);
  const t = r.state.transactions.find((x) => x.id === t1.id);
  assert.equal(t.usd.rateAt, T0); // زمان دریافت نرخ؛ نه ۱۴۰۵-۰۷-۰۱
  assert.equal(t.usd.computedAt, T1);
  assert.equal(t.date, '1405-07-01'); // تاریخ تراکنش دست‌نخورده
});

test('دریافت نرخ: موفق، و همه‌ی شکست‌ها بدون exception', async () => {
  const ok = await FX.fetchLiveRate(adapter, { fetchFn: okFetch(123_000), nowIso: T0 });
  assert.deepEqual(ok, { ok: true, rate: { value: 123_000, at: T0, source: 'منبع آزمایشی', manual: false } });
  const fails = {
    'اینترنت قطع': offlineFetch,
    'پاسخ ۵۰۰': async () => ({ ok: false, status: 500 }),
    'پاسخ خالی': async () => undefined,
    'JSON خراب': async () => ({ ok: true, json: async () => { throw new SyntaxError('bad json'); } }),
    'نرخ صفر': okFetch(0),
    'نرخ منفی': okFetch(-5),
    'نرخ اعشاری': okFetch(123_456.7),
    'نرخ متنی': okFetch('123000'),
    'نرخ ناموجود': okFetch(undefined),
    'نرخ غیرعادی بزرگ': okFetch(99_999_999_999),
  };
  for (const [name, fetchFn] of Object.entries(fails)) {
    const r = await FX.fetchLiveRate(adapter, { fetchFn, nowIso: T0 });
    assert.equal(r.ok, false, name);
    assert.equal(typeof r.error, 'string', name);
    assert.ok(!('rate' in r), name);
  }
  // adapter که خودش خطا بدهد
  const bad = await FX.fetchLiveRate({ ...adapter, parse: () => { throw new Error('boom'); } }, { fetchFn: okFetch(1), nowIso: T0 });
  assert.equal(bad.ok, false);
  // نبود fetch در محیط
  const none = await FX.fetchLiveRate(adapter, { fetchFn: null, nowIso: T0 });
  assert.equal(none.ok, false);
  // مهلت زمانی: درخواستی که هرگز جواب نمی‌دهد قطع می‌شود
  const hang = (url, { signal }) => new Promise((_, reject) => signal.addEventListener('abort', () => reject(new Error('aborted'))));
  const t = Date.now();
  const timed = await FX.fetchLiveRate(adapter, { fetchFn: hang, nowIso: T0, timeoutMs: 30 });
  assert.equal(timed.ok, false);
  assert.ok(Date.now() - t < 2000);
});

test('جریان کامل: ثبت بدون نت ← ماندن در صف ← وصل شدن نت ← محاسبه‌ی خودکار', async () => {
  const { b } = bookWithPending();
  // ۱) نت قطع است
  let r = await FX.syncPending(b.state, adapter, { fetchFn: offlineFetch, nowIso: T0 });
  assert.equal(r.status, 'fetch_failed');
  assert.equal(r.updated, 0);
  assert.equal(FX.pendingTransactions(r.state).length, 3);
  assert.equal(r.state.fx.lastError.at, T0);
  assert.equal(typeof r.state.fx.lastError.message, 'string');
  assert.ok(!JSON.stringify(r.state.fx.lastError).includes('example.test')); // نشانی/جزئیات فنی در خطا نیست
  assert.deepEqual(amounts(r.state), amounts(b.state));
  // ۲) باز هم قطع: وضعیت انتظار حفظ می‌شود
  r = await FX.syncPending(r.state, adapter, { fetchFn: offlineFetch, nowIso: T1 });
  assert.equal(r.status, 'fetch_failed');
  assert.equal(FX.pendingTransactions(r.state).length, 3);
  assert.equal(r.state.fx.lastError.at, T1);
  // ۳) تراکنش جدید در همین فاصله ثبت می‌شود و آن هم در صف می‌ماند
  const cash = r.state.accounts[0];
  const added = L.addTransaction(r.state, { type: 'expense', amount: 80_000, date: '1405-07-20', accountId: cash.id, categoryId: FOOD, note: 'ج' }, b.ctx);
  assert.equal(FX.pendingTransactions(added.state).length, 4);
  // ۴) نت وصل می‌شود
  const T2 = '2026-10-11T10:20:00.000Z';
  r = await FX.syncPending(added.state, adapter, { fetchFn: okFetch(120_000), nowIso: T2 });
  assert.equal(r.status, 'ok');
  assert.equal(r.updated, 4);
  assert.equal(FX.pendingTransactions(r.state).length, 0);
  assert.equal(r.state.fx.lastError, null);
  assert.deepEqual(r.state.fx.lastRate, { value: 120_000, at: T2, source: 'منبع آزمایشی', manual: false });
  assert.equal(r.state.transactions.find((t) => t.note === 'ج').usd.cents, 67); // ۸۰٬۰۰۰ ÷ ۱۲۰٬۰۰۰ = ۰٫۶۶۶۷ دلار
  assert.deepEqual(amounts(r.state), amounts(added.state));
  // ۵) گزارش دلاری، نرخ استفاده‌شده را نشان می‌دهد
  const rep = R.usdReport(r.state);
  assert.equal(rep.pendingCount, 0);
  assert.equal(rep.rates.length, 1);
  assert.equal(rep.rates[0].rate, 120_000);
  assert.equal(rep.rates[0].manual, false);
});

test('همگام‌سازی بدون مورد در انتظار اصلاً به شبکه وصل نمی‌شود', async () => {
  const b = new Book();
  let calls = 0;
  const spy = async () => {
    calls += 1;
    return { ok: true, json: async () => ({ price: 100_000 }) };
  };
  const r = await FX.syncPending(b.state, adapter, { fetchFn: spy, nowIso: T0 });
  assert.equal(r.status, 'nothing_pending');
  assert.equal(calls, 0);
  assert.equal(r.state, b.state);
});

test('نرخ دستی: فقط روی موارد در انتظار (یا انتخاب‌شده) و با برچسب «دستی»', () => {
  const { b, t1, t2 } = bookWithPending();
  const r = FX.applyManualRate(b.state, 110_000, T1, { txIds: [t1.id, t2.id] });
  assert.equal(r.updated, 2);
  assert.deepEqual(r.rate, { value: 110_000, at: T1, source: 'دستی', manual: true });
  const done = r.state.transactions.filter((t) => t.usd.status === 'done');
  assert.equal(done.length, 2);
  for (const t of done) {
    assert.equal(t.usd.manual, true);
    assert.equal(t.usd.source, 'دستی');
    assert.equal(t.usd.rate, 110_000);
  }
  assert.equal(r.state.transactions[0].usd.cents, 182); // ۲۰۰٬۰۰۰ ÷ ۱۱۰٬۰۰۰ = ۱٫۸۱۸۲ دلار
  assert.equal(FX.pendingTransactions(r.state).length, 1); // تراکنش سوم هنوز در انتظار
  assert.deepEqual(amounts(r.state), amounts(b.state));
  // موارد انجام‌شده بدون includeDone دست‌نخورده می‌مانند
  const r2 = FX.applyManualRate(r.state, 130_000, T1);
  assert.equal(r2.updated, 1);
  assert.equal(r2.state.transactions[0].usd.rate, 110_000);
  // با includeDone بازنویسی می‌شود و نرخ قبلی در history می‌ماند
  const r3 = FX.applyManualRate(r2.state, 130_000, T1, { includeDone: true });
  assert.equal(r3.updated, 3);
  assert.equal(r3.state.transactions[0].usd.rate, 130_000);
  assert.equal(r3.state.transactions[0].usd.history.length, 1);
  assert.equal(r3.state.transactions[0].usd.history[0].rate, 110_000);
  assert.equal(r3.state.transactions[0].usd.history[0].cents, 182);
  // نرخ نامعتبر
  for (const bad of [0, -1, 1.5, NaN, '110000', null, 10_000_001]) {
    assert.throws(() => FX.applyManualRate(b.state, bad, T1), { code: 'BAD_RATE' }, String(bad));
  }
});

test('محاسبه‌ی مجدد صریح: تاریخچه‌ی نرخ قبلی حفظ می‌شود', () => {
  const { b, t1 } = bookWithPending();
  const rate1 = { value: 100_000, at: T0, source: 'منبع آزمایشی', manual: false };
  const rate2 = { value: 125_000, at: T1, source: 'منبع آزمایشی', manual: false };
  const s1 = FX.processPending(b.state, rate1, T0).state;
  const rc = FX.recalculate(s1, [t1.id], rate2, T1);
  assert.equal(rc.updated, 1);
  const t = rc.state.transactions.find((x) => x.id === t1.id);
  assert.equal(t.usd.cents, 160); // ۲۰۰٬۰۰۰ ÷ ۱۲۵٬۰۰۰
  assert.equal(t.usd.rate, 125_000);
  assert.equal(t.amount, 200_000);
  assert.equal(t.usd.history.length, 1);
  assert.deepEqual({ ...t.usd.history[0] }, { cents: 200, rate: 100_000, rateAt: T0, source: 'منبع آزمایشی', manual: false, computedAt: T0, replacedAt: T1 });
  // بقیه‌ی تراکنش‌ها دست نمی‌خورند
  assert.equal(rc.state.transactions[1].usd.rate, 100_000);
  // فقط مواردی که قبلاً محاسبه شده‌اند؛ مورد در انتظار نادیده گرفته می‌شود
  const { b: b2, t1: p } = bookWithPending();
  assert.equal(FX.recalculate(b2.state, [p.id], rate2, T1).updated, 0);
  assert.throws(() => FX.recalculate(s1, [t1.id], null, T1), { code: 'BAD_RATE' });
});

test('زنجیره‌ی کامل: محاسبه ← ویرایش مبلغ ← در انتظار ← محاسبه‌ی دوباره، با history کامل', () => {
  const { b, t1 } = bookWithPending();
  b.set(FX.processPending(b.state, { value: 100_000, at: T0, source: 'منبع آزمایشی', manual: false }, T0).state);
  b.ctx.setNow(T1);
  b.update(t1.id, { amount: 300_000 });
  let t = b.state.transactions.find((x) => x.id === t1.id);
  assert.equal(t.usd.status, 'pending');
  assert.equal(t.usd.history.length, 1);
  b.set(FX.processPending(b.state, { value: 120_000, at: T1, source: 'منبع آزمایشی', manual: false }, T1).state);
  t = b.state.transactions.find((x) => x.id === t1.id);
  assert.equal(t.usd.status, 'done');
  assert.equal(t.usd.cents, 250); // ۳۰۰٬۰۰۰ ÷ ۱۲۰٬۰۰۰ = ۲٫۵ دلار
  assert.equal(t.usd.history.length, 1); // نرخ قبلی فقط یک‌بار ثبت شده، تکراری نشده
  assert.equal(t.usd.history[0].cents, 200);
});

test('تراکنش دلاری هیچ‌وقت در صف انتظار نمی‌آید و با نرخ تغییر نمی‌کند', () => {
  const b = new Book();
  const usd = b.account('ارزی', { currency: 'USD', type: 'fx', opening: 10_000 });
  b.tx({ type: 'expense', amount: 1_599, date: '1405-07-19', accountId: usd.id, categoryId: FOOD });
  const rate = { value: 100_000, at: T0, source: 'x', manual: false };
  assert.equal(FX.pendingTransactions(b.state).length, 0);
  const r = FX.processPending(b.state, rate, T1);
  assert.equal(r.updated, 0);
  assert.equal(r.reason, 'nothing_pending');
  assert.equal(FX.applyManualRate(b.state, 100_000, T1).updated, 0);
  assert.equal(b.state.transactions[0].usd.status, 'not_applicable');
});

test('بازگشت و ادامه پس از بسته‌شدن برنامه: وضعیت انتظار در state ماندگار است', () => {
  const { b } = bookWithPending();
  // شبیه‌سازی ذخیره و بازیابی (برنامه بسته و دوباره باز می‌شود)
  const restored = JSON.parse(JSON.stringify(b.state));
  assert.equal(FX.pendingTransactions(restored).length, 3);
  const r = FX.processPending(restored, { value: 100_000, at: T0, source: 'منبع آزمایشی', manual: false }, T1);
  assert.equal(r.updated, 3);
  assert.deepEqual(amounts(r.state), amounts(b.state));
});
