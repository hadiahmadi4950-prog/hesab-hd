// IndexedDB ساختگیِ حداقلی برای تست ماژول ذخیره‌سازی (این فایل تست نیست)
// رفتارهای مهم واقعی را تقلید می‌کند: نوشتن‌ها تا پایان تراکنش بافر می‌شوند، abort همه را دور می‌ریزد،
// put مقدار را structuredClone می‌کند (DataCloneError)، تراکنش‌ها پشت‌سرهم اجرا می‌شوند و
// oncomplete فقط پس از پایان همه‌ی درخواست‌ها فراخوانی می‌شود.

const tick = () => new Promise((r) => setTimeout(r, 0));

function domErr(name, message = name) {
  const e = new Error(message);
  e.name = name;
  return e;
}

class FakeStore {
  constructor(tx, name) {
    this.tx = tx;
    this.name = name;
  }

  #req(fn) {
    const req = { result: undefined, error: null, onsuccess: null, onerror: null };
    this.tx._queue.push({ req, fn });
    return req;
  }

  get(key) {
    return this.#req(() => {
      const m = this.tx._view(this.name);
      return m.has(key) ? structuredClone(m.get(key)) : undefined;
    });
  }

  put(value, key) {
    if (this.tx.mode !== 'readwrite') throw domErr('ReadOnlyError');
    const copy = structuredClone(value); // همین‌جا و همزمان خطای DataCloneError می‌دهد
    return this.#req(() => {
      this.tx._view(this.name, true).set(key, copy);
    });
  }

  clear() {
    if (this.tx.mode !== 'readwrite') throw domErr('ReadOnlyError');
    return this.#req(() => {
      this.tx._view(this.name, true).clear();
    });
  }
}

class FakeTx {
  constructor(db, names, mode) {
    this.db = db;
    this.mode = mode;
    this.names = names;
    this._queue = [];
    this._working = new Map();
    this.error = null;
    this.oncomplete = null;
    this.onerror = null;
    this.onabort = null;
    this._finished = false;
    db._chain = db._chain.then(() => this._run());
  }

  _view(name, forWrite = false) {
    if (this._working.has(name)) return this._working.get(name);
    const base = this.db._data.stores.get(name);
    if (!forWrite) return base;
    const copy = new Map(base);
    this._working.set(name, copy);
    return copy;
  }

  objectStore(name) {
    if (!this.db._data.stores.has(name)) throw domErr('NotFoundError');
    return new FakeStore(this, name);
  }

  abort() {
    if (this._finished) throw domErr('InvalidStateError', 'تراکنش تمام شده است');
    this._abort(null);
  }

  _abort(error) {
    if (this._finished) return;
    this._finished = true;
    this._queue = [];
    this._working.clear();
    this.error = error;
    this.onabort?.();
  }

  async _run() {
    await tick();
    while (!this._finished) {
      const item = this._queue.shift();
      if (!item) break;
      try {
        item.req.result = item.fn();
      } catch (e) {
        item.req.error = e;
        item.req.onerror?.();
        this._abort(e);
        return;
      }
      try {
        item.req.onsuccess?.();
      } catch (e) {
        this._abort(e); // مثل مرورگر: استثنا در callback تراکنش را لغو می‌کند
        return;
      }
      await tick();
    }
    if (this._finished) return;
    if (this.mode === 'readwrite' && this.db._idb.failNextCommit) {
      const e = this.db._idb.failNextCommit;
      this.db._idb.failNextCommit = null;
      this._abort(e);
      return;
    }
    for (const [name, map] of this._working) this.db._data.stores.set(name, map);
    this._finished = true;
    this.oncomplete?.();
  }
}

class FakeDB {
  constructor(idb, data) {
    this._idb = idb;
    this._data = data;
    this._chain = Promise.resolve();
    this.closed = false;
    this.onversionchange = null;
    this.onclose = null;
    this.objectStoreNames = { contains: (n) => data.stores.has(n) };
  }

  createObjectStore(name) {
    this._data.stores.set(name, new Map());
  }

  transaction(names, mode = 'readonly') {
    if (this.closed) throw domErr('InvalidStateError', 'پایگاه داده بسته است');
    const list = Array.isArray(names) ? names : [names];
    for (const n of list) if (!this._data.stores.has(n)) throw domErr('NotFoundError');
    return new FakeTx(this, list, mode);
  }

  close() {
    this.closed = true;
  }
}

export function createFakeIDB() {
  const dbs = new Map();
  const idb = {
    failNextCommit: null, // خطایی که تراکنش readwrite بعدی را لغو می‌کند
    failOpen: null,
    opens: 0,
    open(name, version) {
      idb.opens += 1;
      const req = { result: null, error: null, onsuccess: null, onerror: null, onupgradeneeded: null, onblocked: null };
      setTimeout(() => {
        if (idb.failOpen) {
          const e = idb.failOpen;
          idb.failOpen = null;
          req.error = e;
          req.onerror?.();
          return;
        }
        let data = dbs.get(name);
        const isNew = !data;
        if (isNew) {
          data = { version, stores: new Map() };
          dbs.set(name, data);
        }
        const db = new FakeDB(idb, data);
        req.result = db;
        if (isNew) req.onupgradeneeded?.();
        req.onsuccess?.();
      }, 0);
      return req;
    },
    // فقط برای تست: دست‌کاری مستقیم محتوا
    _store(name = 'hesab-hd', store = 'kv') {
      return dbs.get(name)?.stores.get(store);
    },
  };
  return idb;
}
