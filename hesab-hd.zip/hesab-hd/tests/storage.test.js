import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as L from '../src/core/ledger.js';
import { createMemoryAdapter, createIndexedDBAdapter, openStore, StorageError, requestPersistence, storageEstimate } from '../src/core/storage.js';
import { createFakeIDB } from './fake-idb.js';
import { Book } from './helpers.js';
import { richBook, clone } from './fixtures.js';

// هر تست روی هر دو آداپتور اجرا می‌شود
const makers = {
  memory: () => ({ adapter: createMemoryAdapter(), reopen: null }),
  indexeddb: () => {
    const idb = createFakeIDB();
    const mk = () => createIndexedDBAdapter({ idb });
    return { adapter: mk(), idb, mk };
  },
};

function withAccount(name) {
  return (s) => L.addAccount(s, { name, type: 'cash', currency: 'IRT', openingBalance: 1000 }).state;
}
const names = (st) => st.state.accounts.map((a) => a.name);

for (const [kind, make] of Object.entries(makers)) {
  const T = (name, fn) => test(`[${kind}] ${name}`, fn);

  T('شروع خالی: وضعیت empty و چیزی ذخیره نمی‌شود', async () => {
    const { adapter } = make();
    const st = await openStore({ adapter });
    assert.equal(st.status, 'empty');
    assert.equal(st.state.accounts.length, 0);
    assert.equal(st.savedAt, null);
    assert.equal((await adapter.load()).main, null);
  });

  T('ثبت و ماندگاری پس از «راه‌اندازی مجدد»', async () => {
    const m = make();
    const st = await openStore({ adapter: m.adapter });
    await st.commit(withAccount('نقد'));
    assert.equal(st.status, 'ok');
    const adapter2 = m.mk ? m.mk() : m.adapter;
    const st2 = await openStore({ adapter: adapter2 });
    assert.equal(st2.status, 'ok');
    assert.deepEqual(names(st2), ['نقد']);
    assert.ok(st2.savedAt);
  });

  T('خطا در updater: state و ذخیره دست‌نخورده، شنونده صدا نمی‌خورد', async () => {
    const { adapter } = make();
    const st = await openStore({ adapter });
    await st.commit(withAccount('الف'));
    let calls = 0;
    st.subscribe(() => calls++);
    const before = st.state;
    await assert.rejects(st.commit(() => { throw new L.ValidationError([{ field: 'x', message: 'بد' }]); }), L.ValidationError);
    assert.equal(st.state, before);
    assert.equal(calls, 0);
    assert.equal(adapter.saves ?? 1, adapter.saves ?? 1);
    assert.deepEqual((await adapter.load()).main.accounts.map((a) => a.name), ['الف']);
  });

  T('updater که state نامعتبر برگرداند → INVALID_STATE', async () => {
    const { adapter } = make();
    const st = await openStore({ adapter });
    await assert.rejects(st.commit(() => null), (e) => e.code === 'INVALID_STATE');
    await assert.rejects(st.commit(() => ({ foo: 1 })), (e) => e.code === 'INVALID_STATE');
  });

  T('شکست ذخیره (فضای پر): state عوض نمی‌شود، سپس بازیابی', async () => {
    const m = make();
    const st = await openStore({ adapter: m.adapter });
    await st.commit(withAccount('الف'));
    let calls = 0;
    st.subscribe(() => calls++);
    const quota = Object.assign(new Error('full'), { name: 'QuotaExceededError' });
    if (m.idb) m.idb.failNextCommit = quota;
    else m.adapter.failNext = quota;
    await assert.rejects(st.commit(withAccount('ب')), (e) => e instanceof StorageError && e.code === 'QUOTA');
    assert.deepEqual(names(st), ['الف']);
    assert.equal(calls, 0);
    const disk = (await (m.mk ? m.mk() : m.adapter).load()).main;
    assert.deepEqual(disk.accounts.map((a) => a.name), ['الف']); // اتمیک: دیسک هم عوض نشده
    await st.commit(withAccount('ب')); // پس از رفع مشکل کار می‌کند
    assert.deepEqual(names(st), ['الف', 'ب']);
    assert.equal(calls, 1);
  });

  T('ثبت‌های همزمان به ترتیب اجرا می‌شوند و هیچ تغییری گم نمی‌شود', async () => {
    const { adapter } = make();
    const st = await openStore({ adapter });
    const ps = [];
    for (let i = 1; i <= 15; i++) ps.push(st.commit(withAccount(`حساب${i}`)));
    await Promise.all(ps);
    assert.equal(st.state.accounts.length, 15);
    assert.deepEqual(names(st), Array.from({ length: 15 }, (_, i) => `حساب${i + 1}`));
    assert.equal((await adapter.load()).main.accounts.length, 15);
  });

  T('یک ثبت ناموفق وسط صف، بقیه را خراب نمی‌کند', async () => {
    const { adapter } = make();
    const st = await openStore({ adapter });
    const a = st.commit(withAccount('الف'));
    const bad = st.commit(() => { throw new Error('boom'); });
    const c = st.commit(withAccount('ج'));
    await a;
    await assert.rejects(bad, /boom/);
    await c;
    assert.deepEqual(names(st), ['الف', 'ج']);
  });

  T('subscribe و unsubscribe', async () => {
    const { adapter } = make();
    const st = await openStore({ adapter });
    const seen = [];
    const off = st.subscribe((s) => seen.push(s.accounts.length));
    st.subscribe(() => { throw new Error('شنونده‌ی خراب'); });
    await st.commit(withAccount('الف'));
    off();
    await st.commit(withAccount('ب'));
    assert.deepEqual(seen, [1]);
    assert.equal(st.state.accounts.length, 2); // خطای شنونده ذخیره را خراب نکرد
  });

  T('هر ذخیره نسخه‌ی قبلی را نگه می‌دارد', async () => {
    const { adapter } = make();
    const st = await openStore({ adapter });
    await st.commit(withAccount('الف'));
    await st.commit(withAccount('ب'));
    const d = await adapter.load();
    assert.equal(d.main.accounts.length, 2);
    assert.equal(d.previous.accounts.length, 1);
  });

  T('داده‌ی اصلی خراب → بازیابی از نسخه‌ی قبلی، و نسخه‌ی قبلی با داده‌ی خراب جایگزین نمی‌شود', async () => {
    const m = make();
    const st = await openStore({ adapter: m.adapter });
    await st.commit(withAccount('الف'));
    await st.commit(withAccount('ب'));
    // خراب کردن نسخه‌ی اصلی
    if (m.idb) m.idb._store().set('state', { version: 1, accounts: 'خراب' });
    else m.adapter._raw.set('state', { version: 1, accounts: 'خراب' });
    const adapter2 = m.mk ? m.mk() : m.adapter;
    const st2 = await openStore({ adapter: adapter2 });
    assert.equal(st2.status, 'recovered');
    assert.ok(st2.recoveredNote);
    assert.deepEqual(names(st2), ['الف']);
    assert.ok(await st2.corruptedRaw()); // نسخه‌ی خراب برای بررسی نگه داشته شد
    await st2.commit(withAccount('ج'));
    assert.equal(st2.status, 'ok');
    const d = await adapter2.load();
    assert.deepEqual(d.previous.accounts.map((a) => a.name), ['الف']); // هنوز سالم
    assert.deepEqual(d.main.accounts.map((a) => a.name), ['الف', 'ج']);
  });

  T('هر دو نسخه خراب → وضعیت corrupt، ثبت مسدود، چیزی بازنویسی نمی‌شود', async () => {
    const m = make();
    const bad = { version: 1, accounts: 'x' };
    const raw = m.idb ? m.idb._store : null;
    const st0 = await openStore({ adapter: m.adapter });
    await st0.commit(withAccount('الف'));
    await st0.commit(withAccount('ب'));
    const put = (k, v) => (m.idb ? m.idb._store().set(k, v) : m.adapter._raw.set(k, v));
    put('state', bad);
    put('previous', { version: 1, goals: 5 });
    void raw;
    const adapter2 = m.mk ? m.mk() : m.adapter;
    const st = await openStore({ adapter: adapter2 });
    assert.equal(st.status, 'corrupt');
    assert.equal(st.state.accounts.length, 0);
    await assert.rejects(st.commit(withAccount('ج')), (e) => e.code === 'CORRUPT');
    assert.deepEqual((await adapter2.load()).main, bad); // دست‌نخورده
    assert.deepEqual(await st.corruptedRaw(), bad);
  });

  T('resolveCorruption: شروع از نو و بازیابی از فایل، و انتخاب نامعتبر', async () => {
    for (const action of ['startFresh', 'restore']) {
      const m = make();
      const put = (k, v) => (m.idb ? m.idb._store().set(k, v) : m.adapter._raw.set(k, v));
      if (m.idb) await m.adapter.save(L.createEmptyState()); // ساخت پایگاه داده
      put('state', { version: 1, accounts: 'x' });
      put('previous', null);
      const adapter2 = m.mk ? m.mk() : m.adapter;
      const st = await openStore({ adapter: adapter2 });
      assert.equal(st.status, 'corrupt');
      await assert.rejects(st.resolveCorruption({ action: 'نامعتبر' }), (e) => e.code === 'BAD_ACTION');
      assert.equal(st.status, 'corrupt');
      if (action === 'restore') {
        await assert.rejects(st.resolveCorruption({ action, state: { version: 1 } }), (e) => e.code === 'INVALID_STATE');
        assert.equal(st.status, 'corrupt');
        await st.resolveCorruption({ action, state: clone(richBook().b.state) });
        assert.ok(st.state.transactions.length > 5);
      } else {
        await st.resolveCorruption({ action });
        assert.equal(st.state.accounts.length, 0);
      }
      assert.equal(st.status, 'ok');
      await st.commit(withAccount('الف'));
      const st2 = await openStore({ adapter: m.mk ? m.mk() : m.adapter });
      assert.equal(st2.status, 'ok');
    }
  });

  T('validateOnCommit: تغییر ناسازگار ذخیره نمی‌شود', async () => {
    const { adapter } = make();
    const st = await openStore({ adapter, validateOnCommit: true });
    await st.commit(withAccount('الف'));
    await assert.rejects(
      st.commit((s) => ({ ...s, transactions: [{ id: 'x', type: 'expense', amount: -5 }] })),
      (e) => e.code === 'INVALID_STATE',
    );
    assert.equal(st.state.transactions.length, 0);
  });

  T('پایگاه داده‌ی بزرگ: ۵۰۰۰ تراکنش ذخیره و بازخوانی دقیق می‌شود', async () => {
    const m = make();
    const b = new Book();
    const acc = b.account('نقد', { opening: 0 });
    let state = b.state;
    const ctx = b.ctx;
    for (let i = 0; i < 5000; i++) {
      state = L.addTransaction(state, { type: 'income', accountId: acc.id, amount: 1000 + i, date: '1405-01-01', categoryId: 'cat-income-salary' }, ctx, { allowDuplicate: true }).state;
    }
    const st = await openStore({ adapter: m.adapter, validateOnCommit: true });
    await st.commit(() => state);
    const st2 = await openStore({ adapter: m.mk ? m.mk() : m.adapter });
    assert.equal(st2.status, 'ok');
    assert.equal(st2.state.transactions.length, 5000);
    assert.deepEqual(st2.state, state);
  });

  T('بدون اینترنت هم کار می‌کند (fetch در دسترس نیست)', async () => {
    const orig = globalThis.fetch;
    globalThis.fetch = () => { throw new Error('offline'); };
    try {
      const { adapter } = make();
      const st = await openStore({ adapter });
      await st.commit(withAccount('الف'));
      assert.equal(st.state.accounts.length, 1);
    } finally {
      globalThis.fetch = orig;
    }
  });
}

test('[indexeddb] داده‌ی غیرقابل‌ذخیره → SERIALIZE و state دست‌نخورده', async () => {
  const idb = createFakeIDB();
  const st = await openStore({ adapter: createIndexedDBAdapter({ idb }) });
  await st.commit(withAccount('الف'));
  await assert.rejects(st.commit((s) => ({ ...s, hack: () => 1 })), (e) => e.code === 'SERIALIZE');
  assert.deepEqual(names(st), ['الف']);
});

test('[memory] داده‌ی غیرقابل‌ذخیره → خطا و state دست‌نخورده', async () => {
  const st = await openStore({ adapter: createMemoryAdapter() });
  await st.commit(withAccount('الف'));
  await assert.rejects(st.commit((s) => ({ ...s, hack: () => 1 })));
  assert.deepEqual(names(st), ['الف']);
});

test('[indexeddb] شکست باز کردن پایگاه داده و تلاش دوباره', async () => {
  const idb = createFakeIDB();
  idb.failOpen = Object.assign(new Error('x'), { name: 'SecurityError' });
  const adapter = createIndexedDBAdapter({ idb });
  await assert.rejects(openStore({ adapter }), (e) => e.code === 'UNAVAILABLE');
  const st = await openStore({ adapter }); // دفعه‌ی بعد دوباره تلاش می‌شود
  assert.equal(st.status, 'empty');
});

test('[indexeddb] پایگاه داده‌ی بسته‌شده → دوباره باز می‌شود', async () => {
  const idb = createFakeIDB();
  const adapter = createIndexedDBAdapter({ idb });
  const st = await openStore({ adapter });
  await st.commit(withAccount('الف'));
  await adapter.close();
  await st.commit(withAccount('ب'));
  assert.deepEqual(names(st), ['الف', 'ب']);
});

test('بدون آداپتور و بدون IndexedDB', async () => {
  await assert.rejects(openStore({}), (e) => e.code === 'NO_ADAPTER');
  assert.throws(() => createIndexedDBAdapter({ idb: null }), (e) => e.code === 'UNAVAILABLE');
});

test('requestPersistence و storageEstimate', async () => {
  assert.equal(await requestPersistence({ storage: { persisted: async () => true } }), true);
  assert.equal(await requestPersistence({ storage: { persisted: async () => false, persist: async () => true } }), true);
  assert.equal(await requestPersistence({ storage: { persisted: async () => false, persist: async () => false } }), false);
  assert.equal(await requestPersistence({}), null);
  assert.equal(await requestPersistence({ storage: { persist: async () => { throw new Error('x'); } } }), null);
  assert.deepEqual(await storageEstimate({ storage: { estimate: async () => ({ usage: 5, quota: 100 }) } }), { usage: 5, quota: 100 });
  assert.equal(await storageEstimate({}), null);
});
