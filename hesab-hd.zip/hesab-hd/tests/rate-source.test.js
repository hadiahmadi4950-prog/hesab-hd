import { test } from 'node:test';
import assert from 'node:assert/strict';
import { iranMarketAdapter as A, IRAN_MARKET_URL } from '../src/core/rate-source.js';
import { fetchLiveRate } from '../src/core/fx.js';

const NOW = '2026-10-12T10:00:00.000Z';
const rec = (o = {}) => ({ symbol: 'USD_IRR_FREE', currency: 'IRT', price: 258465, stale: false, timestamp: '2026-10-11T20:30:00.000Z', ...o });
const payload = (r = rec()) => ({ meta: { unit: 'toman' }, data: [{ symbol: 'GOLD', price: 1 }, r] });
const fetchOf = (json, ok = true) => async () => ({ ok, json: async () => json });

test('نرخ سالم خوانده می‌شود و بدون تبدیل واحد', () => {
  assert.deepEqual(A.parse(payload(), { nowIso: NOW }), { value: 258465 });
});
test('پاسخ‌های نامعتبر رد می‌شوند', () => {
  for (const bad of [null, {}, { data: 'x' }, { data: [] }, payload(rec({ symbol: 'X' }))]) assert.ok(A.parse(bad, { nowIso: NOW }).error);
  for (const r of [rec({ currency: 'IRR' }), rec({ stale: true }), rec({ price: null }), rec({ price: 0 }), rec({ price: -5 }), rec({ price: 1.5 }), rec({ price: '258465' })]) {
    const out = A.parse(payload(r), { nowIso: NOW });
    assert.ok(out.error && out.value === undefined, JSON.stringify(r));
  }
});
test('قیمت چند روز کهنه رد می‌شود ولی تعطیلی آخر هفته مجاز است', () => {
  assert.ok(A.parse(payload(rec({ timestamp: '2026-10-01T20:30:00.000Z' })), { nowIso: NOW }).error);
  assert.equal(A.parse(payload(rec({ timestamp: '2026-10-09T20:30:00.000Z' })), { nowIso: NOW }).value, 258465);
});
test('یکپارچگی با fetchLiveRate: موفق، خطای منبع و پیام فارسی', async () => {
  assert.equal(A.url, IRAN_MARKET_URL);
  const ok = await fetchLiveRate(A, { fetchFn: fetchOf(payload()), nowIso: NOW });
  assert.equal(ok.ok, true);
  assert.equal(ok.rate.value, 258465);
  assert.equal(ok.rate.manual, false);
  const stale = await fetchLiveRate(A, { fetchFn: fetchOf(payload(rec({ stale: true }))), nowIso: NOW });
  assert.equal(stale.ok, false);
  assert.match(stale.error, /کهنه/);
  const http = await fetchLiveRate(A, { fetchFn: fetchOf({}, false), nowIso: NOW });
  assert.equal(http.ok, false);
});
