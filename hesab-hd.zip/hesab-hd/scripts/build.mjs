// ساخت پوشه‌ی انتشار dist/ : فایل‌های public + src، و سرویس‌ورکر با فهرست دقیق فایل‌ها و نسخه‌ی هش‌شده
import { cpSync, rmSync, mkdirSync, readdirSync, statSync, readFileSync, writeFileSync } from 'node:fs';
import { join, relative, sep } from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = join(fileURLToPath(import.meta.url), '..', '..');
const dist = join(root, 'dist');

rmSync(dist, { recursive: true, force: true });
mkdirSync(dist, { recursive: true });
cpSync(join(root, 'public'), dist, { recursive: true });
cpSync(join(root, 'src'), join(dist, 'src'), { recursive: true });

function walk(dir) {
  return readdirSync(dir).flatMap((n) => {
    const p = join(dir, n);
    return statSync(p).isDirectory() ? walk(p) : [p];
  });
}

const files = walk(dist)
  .map((p) => relative(dist, p).split(sep).join('/'))
  .filter((f) => f !== 'sw.js')
  .sort();
const hash = createHash('sha256');
for (const f of files) {
  hash.update(f);
  hash.update(readFileSync(join(dist, f)));
}
const version = hash.digest('hex').slice(0, 12);
const assets = ['./', ...files.map((f) => `./${f}`)];
const sw = readFileSync(join(dist, 'sw.js'), 'utf8').replace('__VERSION__', version).replace('__ASSETS__', JSON.stringify(assets, null, 1));
writeFileSync(join(dist, 'sw.js'), sw);
console.log(`dist ساخته شد: ${files.length} فایل، نسخه ${version}`);
